# 5-fold cross-validation: real Kepler/K2 light-curve CNN

Pooled exoTrain + exoTest: 5657 stars, 42 planets. Stratified 5-fold (random_state=42); inside each fold a stratified 15% validation slice is used only for early stopping. Decision threshold 0.5 (fixed, not tuned). Runtime 9.1 min.

| Fold | Planets in fold | Found (TP) | Missed (FN) | False alarms (FP) | Recall | Precision | Avg precision | ROC AUC | Epochs |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 9 | 1 | 8 | 6 | 0.111 | 0.143 | 0.082 | 0.772 | 12 |
| 2 | 9 | 2 | 7 | 2 | 0.222 | 0.500 | 0.287 | 0.803 | 12 |
| 3 | 8 | 1 | 7 | 1 | 0.125 | 0.500 | 0.086 | 0.663 | 12 |
| 4 | 8 | 2 | 6 | 3 | 0.250 | 0.400 | 0.351 | 0.800 | 12 |
| 5 | 8 | 2 | 6 | 7 | 0.250 | 0.222 | 0.257 | 0.933 | 12 |

## Mean ± standard deviation over the folds

* **Planet recall:** 0.192 ± 0.061 (min 0.111, max 0.250)
* **Planet precision:** 0.353 ± 0.146 (min 0.143, max 0.500)
* **Average precision:** 0.213 ± 0.109 (min 0.082, max 0.351)
* **ROC AUC:** 0.794 ± 0.086 (min 0.663, max 0.933)

Over all folds together: 8 of 42 planets found, 19 false alarms among 5615 non-planet stars.

A random guesser would get average precision of about 0.007 (the planet fraction).
