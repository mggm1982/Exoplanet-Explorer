# Real Kepler/K2 Light-Curve Evaluation Report

**Model:** Enhanced 1-D CNN with multi-scale temporal pooling and transit-injection augmentation  
**Held-out test set:** `exoTest.csv` (570 stars, 5 confirmed planets, 565 non-planets)  
**Evaluation Date:** 2026-11-03 15:26:19  

## Summary of Results

| Metric | Threshold 0.5 | Threshold 0.7 (Planet Likely) |
|---|---|---|
| **Recall** | **0.400** (2/5 planets) | **0.000** |
| **Precision** | **0.500** | **0.000** |
| **ROC AUC** | **0.9589** | **0.9589** |
| **Average Precision (PR AUC)** | **0.3936** | **0.3936** |

## Confusion Matrix (Threshold 0.5)

| | Predicted Non-Planet | Predicted Planet |
|---|---|---|
| **Actual Non-Planet** | 563 | 2 (False Alarms) |
| **Actual Planet** | 3 | 2 (True Positives) |

## Scores for the 5 Confirmed Test Planets

0.3256, 0.3868, 0.3547, 0.6896, 0.6079
