"""Command-line scripts. Run them from the project folder, e.g.
    python -m scripts.train_real_lightcurve
"""
