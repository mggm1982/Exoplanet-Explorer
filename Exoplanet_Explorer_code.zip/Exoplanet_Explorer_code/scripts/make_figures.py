"""
make_figures.py
---------------
Draw the figures used in the slides and the article, from the project's own
models and data. Nothing here trains or changes a model.

Run it with:   python -m scripts.make_figures   (from the project folder)
Output:        results/figures/*.png

Needs: models/*.keras, data/real/exoTest.csv,
       data/simulated/sample_stars.csv, results/real_lightcurve_report.md,
       results/real_lightcurve_cv_report.md
"""

import os
import re

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")  # draw straight to files
import matplotlib.pyplot as plt

from detector import cnn_predict
from detector.preprocess import preprocess_flux

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # project folder
OUT = os.path.join(HERE, "results", "figures")

# One small, fixed palette (colour-blind-safe pair + neutral greys).
BLUE = "#2a78d6"     # planets / main series
ORANGE = "#eb6834"   # second series
INK = "#0b0b0b"      # text
MUTED = "#52514e"    # secondary text, axes
GRID = "#e4e3df"     # recessive grid

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 11,
    "axes.edgecolor": MUTED,
    "axes.labelcolor": INK,
    "xtick.color": MUTED,
    "ytick.color": MUTED,
    "axes.grid": True,
    "grid.color": GRID,
    "grid.linewidth": 0.8,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 150,
})


def save(fig, name):
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, name), dpi=200, facecolor="white")
    plt.close(fig)
    print("wrote", name)


def figure_real_light_curves():
    """Three cleaned real Kepler light curves: a found planet, a missed planet, a normal star."""
    table = pd.read_csv(os.path.join(HERE, "data", "real", "exoTest.csv"))
    flux = table.drop(columns=["LABEL"]).to_numpy(float)
    model = cnn_predict._load_one("real")
    clean = preprocess_flux(flux, target_length=int(model.input_shape[1]))
    scores = model.predict(clean, verbose=0).ravel()

    labels = table["LABEL"].to_numpy()
    planets = np.where(labels == 2)[0]
    found = planets[np.argmax(scores[planets])]
    missed = planets[np.argmin(scores[planets])]
    normal = np.where(labels == 1)[0][0]

    panels = [
        (found, "Real planet star - found", BLUE),
        (missed, "Real planet star - missed", ORANGE),
        (normal, "Star without a planet", MUTED),
    ]
    fig, axes = plt.subplots(3, 1, figsize=(9, 6.5), sharex=True)
    for ax, (i, title, colour) in zip(axes, panels):
        ax.plot(clean[i, :, 0], color=colour, linewidth=0.8)
        ax.set_title(f"{title}  (exoTest row {i + 1}, CNN score {scores[i]:.3f})",
                     loc="left", fontsize=11, color=INK)
        ax.set_ylabel("cleaned flux\n(std units)")
        ax.set_ylim(-21, 11)
    axes[-1].set_xlabel("time step (about 30 minutes each)")
    save(fig, "fig_real_light_curves.png")


def figure_cv_folds():
    """Per-fold recall and average precision from the cross-validation report."""
    text = open(os.path.join(HERE, "results", "real_lightcurve_cv_report.md")).read()
    rows = re.findall(r"^\| (\d) \| (\d+) \| (\d+) \| (\d+) \| (\d+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \| ([\d.]+) \|",
                      text, flags=re.M)
    folds = [int(r[0]) for r in rows]
    recall = [float(r[5]) for r in rows]
    ap = [float(r[7]) for r in rows]

    x = np.arange(len(folds))
    width = 0.38
    fig, ax = plt.subplots(figsize=(7.5, 4))
    ax.bar(x - width / 2 - 0.01, recall, width, color=BLUE, label="Planet recall (threshold 0.5)")
    ax.bar(x + width / 2 + 0.01, ap, width, color=ORANGE, label="Average precision")
    ax.axhline(42 / 5657, color=MUTED, linestyle="--", linewidth=1,
               label="Random guess (AP = 0.007)")
    ax.set_xticks(x, [f"Fold {f}" for f in folds])
    ax.set_ylim(0, 0.45)
    ax.set_ylabel("score (0 to 1)")
    ax.set_title("5-fold cross-validation on real Kepler/K2 data (42 planets)", loc="left", color=INK)
    ax.legend(frameon=False, loc="upper left")
    ax.grid(axis="x", visible=False)
    save(fig, "fig_cv_folds.png")


def figure_simulated_vs_real():
    """How well each model finds planets on its own kind of data."""
    table = pd.read_csv(os.path.join(HERE, "data", "simulated", "sample_stars.csv"))
    sim = cnn_predict.predict_stars(table.drop(columns=["LABEL"]).to_numpy(float),
                                    table["LABEL"].tolist(), "simulated")
    sim_planets = [r for r in sim if r["true_label"] == 2]
    sim_recall = sum(r["probability"] >= 0.5 for r in sim_planets) / len(sim_planets)

    names = ["Simulated model\non simulated stars\n(6 planets)",
             "Real model\non real exoTest\n(5 planets)",
             "Real model\n5-fold CV\n(42 planets)"]
    # Real-data numbers are read from the saved reports, never typed in by hand.
    test_text = open(os.path.join(HERE, "results", "real_lightcurve_report.md")).read()
    found, total = re.search(r"\((\d+)/(\d+) planets\)", test_text).groups()
    cv_text = open(os.path.join(HERE, "results", "real_lightcurve_cv_report.md")).read()
    cv_found, cv_total = re.search(r"(\d+) of (\d+) planets found", cv_text).groups()
    values = [sim_recall, int(found) / int(total), int(cv_found) / int(cv_total)]
    fig, ax = plt.subplots(figsize=(7.5, 4))
    bars = ax.bar(names, values, color=[MUTED, BLUE, BLUE], width=0.55)
    for bar, v in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, v + 0.02, f"{v:.0%}",
                ha="center", color=INK, fontsize=12)
    ax.set_ylim(0, 1.12)
    ax.set_ylabel("planets found (recall at 0.5)")
    ax.set_title("Simulated success does not transfer to real data", loc="left", color=INK)
    ax.grid(axis="x", visible=False)
    save(fig, "fig_simulated_vs_real.png")


def figure_pipeline():
    """The exoplanet discovery and characterization pipeline."""
    fig, ax = plt.subplots(figsize=(10, 3.7))
    ax.axis("off")
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 3.6)

    def box(x, y, w, h, title, sub, colour):
        ax.add_patch(matplotlib.patches.FancyBboxPatch(
            (x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.12",
            facecolor="white", edgecolor=colour, linewidth=2))
        ax.text(x + w / 2, y + h * 0.64, title, ha="center", va="center",
                fontsize=11.5, fontweight="bold", color=INK)
        ax.text(x + w / 2, y + h * 0.28, sub, ha="center", va="center", fontsize=9.5, color=MUTED)

    ax.text(0.1, 3.15, "Stage 1 - HIGH-SENSITIVITY DETECTION:\nis there a transit signal?", fontsize=11.5, va="center", color=BLUE, fontweight="bold")
    box(0.1, 1.75, 4.2, 1.1, "Enhanced 1-D CNN Detector", "Deterministic 5-stage cleaning + multi-scale temporal pooling", BLUE)
    box(0.1, 0.35, 4.2, 1.1, "Physics-Informed Augmentation", "Kepler host injection + phase-invariant circular shifts", BLUE)
    
    ax.annotate("", xy=(5.5, 1.6), xytext=(4.5, 1.6),
                arrowprops=dict(arrowstyle="-|>", color=MUTED, linewidth=2))
    ax.text(5.0, 1.8, "candidates", ha="center", fontsize=9.5, color=MUTED)

    ax.text(5.6, 3.15, "Stage 2 - ASTROPHYSICAL VETTING:\nis the signal a real planet?", fontsize=11.5, va="center", color=ORANGE, fontweight="bold")
    box(5.6, 1.75, 4.2, 1.1, "Physical Rule-Based Vetting", "Reject eclipsing binaries (depth > 25%), period & duration checks", ORANGE)
    box(5.6, 0.35, 4.2, 1.1, "Learned False-Positive Filter", "Logistic regression on 9 physical features (7,328 real KOIs)", ORANGE)
    save(fig, "fig_pipeline.png")


def main():
    os.makedirs(OUT, exist_ok=True)
    cnn_predict.load_models()
    figure_pipeline()
    figure_real_light_curves()
    figure_cv_folds()
    figure_simulated_vs_real()


if __name__ == "__main__":
    main()
