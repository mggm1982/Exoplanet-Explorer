"""
cv_real_lightcurve.py
---------------------
Stratified 5-fold cross-validation of the real-data light-curve CNN.

Why: exoTest.csv has only 5 planets, so one test run is very noisy.
Here we pool exoTrain + exoTest (42 planets) and test on 5 different folds.
Every star is tested exactly once, by a model that never saw it in training.

Inside each fold, the training part is split again: a stratified 15% slice is
used for early stopping, exactly like train_real_lightcurve.py.
The model, preprocessing, class weights and seeds are imported from that
script, so both scripts always use the same recipe.

Run it with:   python cv_real_lightcurve.py      (about 10 minutes on an M3 CPU)
Output:        results/real_lightcurve_cv_report.md
This script does NOT save or replace any model file.
"""

import os
import time

import numpy as np

from detector.preprocess import preprocess_flux
from scripts.train_real_lightcurve import (DECISION_THRESHOLD, RESULTS_DIR, SEED,
                                   TEST_CSV, TRAIN_CSV, VALIDATION_FRACTION,
                                   load_kepler_csv, score_predictions,
                                   train_one_model)

N_FOLDS = 5
REPORT_OUT = os.path.join(RESULTS_DIR, "real_lightcurve_cv_report.md")


def main():
    from sklearn.model_selection import StratifiedKFold, train_test_split

    os.makedirs(RESULTS_DIR, exist_ok=True)

    flux_a, y_a = load_kepler_csv(TRAIN_CSV)
    flux_b, y_b = load_kepler_csv(TEST_CSV)
    x_raw = np.concatenate([flux_a, flux_b])
    y = np.concatenate([y_a, y_b])
    print(f"Pooled data: {len(y)} stars, {int(y.sum())} planets")

    folds = StratifiedKFold(n_splits=N_FOLDS, shuffle=True, random_state=SEED)
    rows = []
    start = time.time()

    for fold_number, (train_idx, test_idx) in enumerate(folds.split(x_raw, y), start=1):
        x_tr, x_val, y_tr, y_val = train_test_split(
            x_raw[train_idx], y[train_idx],
            test_size=VALIDATION_FRACTION,
            stratify=y[train_idx],
            random_state=SEED,
        )
        model, history = train_one_model(x_tr, y_tr, x_val, y_val, verbose=0)

        x_test_proc = preprocess_flux(x_raw[test_idx], target_length=3197)
        p = model.predict(x_test_proc, verbose=0).ravel()
        m = score_predictions(y[test_idx], p, DECISION_THRESHOLD)
        m["fold"] = fold_number
        m["test_planets"] = int(y[test_idx].sum())
        m["epochs"] = len(history.history["loss"])
        rows.append(m)
        print(f"Fold {fold_number}: recall {m['recall']:.3f}  precision {m['precision']:.3f}  "
              f"AP {m['average_precision']:.3f}  ({m['tp']}/{m['test_planets']} planets found, "
              f"{m['fp']} false alarms)")

    minutes = (time.time() - start) / 60
    write_report(rows, len(y), int(y.sum()), minutes)
    print(f"Wrote {REPORT_OUT} ({minutes:.1f} min)")


def write_report(rows, n_stars, n_planets, minutes):
    """Per-fold table plus mean and standard deviation of each metric."""
    lines = [
        "# 5-fold cross-validation: real Kepler/K2 light-curve CNN",
        "",
        f"Pooled exoTrain + exoTest: {n_stars} stars, {n_planets} planets. "
        f"Stratified {N_FOLDS}-fold (random_state={SEED}); inside each fold a stratified "
        f"{int(VALIDATION_FRACTION * 100)}% validation slice is used only for early stopping. "
        f"Decision threshold {DECISION_THRESHOLD} (fixed, not tuned). Runtime {minutes:.1f} min.",
        "",
        "| Fold | Planets in fold | Found (TP) | Missed (FN) | False alarms (FP) | Recall | Precision | Avg precision | ROC AUC | Epochs |",
        "|---|---|---|---|---|---|---|---|---|---|",
    ]
    for m in rows:
        lines.append(
            f"| {m['fold']} | {m['test_planets']} | {m['tp']} | {m['fn']} | {m['fp']} | "
            f"{m['recall']:.3f} | {m['precision']:.3f} | {m['average_precision']:.3f} | "
            f"{m['roc_auc']:.3f} | {m['epochs']} |"
        )

    lines += ["", "## Mean ± standard deviation over the folds", ""]
    for key, name in [("recall", "Planet recall"), ("precision", "Planet precision"),
                      ("average_precision", "Average precision"), ("roc_auc", "ROC AUC")]:
        values = np.array([m[key] for m in rows])
        lines.append(f"* **{name}:** {values.mean():.3f} ± {values.std():.3f} "
                     f"(min {values.min():.3f}, max {values.max():.3f})")

    total_tp = sum(m["tp"] for m in rows)
    total_fp = sum(m["fp"] for m in rows)
    lines += [
        "",
        f"Over all folds together: {total_tp} of {n_planets} planets found, "
        f"{total_fp} false alarms among {n_stars - n_planets} non-planet stars.",
        "",
        "A random guesser would get average precision of about "
        f"{n_planets / n_stars:.3f} (the planet fraction).",
        "",
    ]
    with open(REPORT_OUT, "w") as f:
        f.write("\n".join(lines))


if __name__ == "__main__":
    main()
