"""
train_real_lightcurve.py
------------------------
Train the enhanced light-curve CNN on real Kepler/K2 data with physics-informed
data augmentation and realistic transit injection. Evaluated honestly on the
held-out test set (exoTest.csv).

Run it with:   python train_real_lightcurve.py

Run    : python -m scripts.train_real_lightcurve   (from the project folder)
Inputs : data/real/exoTrain.csv, data/real/exoTest.csv
Outputs: models/exoplanet_model_real.keras           (the trained model)
         results/real_lightcurve_report.md     (metrics and confusion matrix)
         results/real_lightcurve_pr_curve.png  (precision-recall curve)
"""

import os
import time
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import (
    recall_score, precision_score, roc_auc_score,
    average_precision_score, confusion_matrix, precision_recall_curve
)
import keras
from keras import layers

from detector.preprocess import preprocess_flux
from research.inject import inject, random_transit_parameters

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # project folder
TRAIN_CSV = os.path.join(HERE, "data", "real", "exoTrain.csv")
TEST_CSV = os.path.join(HERE, "data", "real", "exoTest.csv")
MODEL_OUT = os.path.join(HERE, "models", "exoplanet_model_real.keras")
RESULTS_DIR = os.path.join(HERE, "results")
REPORT_OUT = os.path.join(RESULTS_DIR, "real_lightcurve_report.md")
PLOT_OUT = os.path.join(RESULTS_DIR, "real_lightcurve_pr_curve.png")

SEED = 42
VALIDATION_FRACTION = 0.15
DECISION_THRESHOLD = 0.5
APP_PLANET_LIKELY = 0.7


def load_kepler_csv(path):
    table = pd.read_csv(path)
    y = (table["LABEL"].to_numpy() == 2).astype(np.int32)
    flux = table.drop(columns=["LABEL"]).to_numpy(dtype=np.float64)
    return flux, y


def build_enhanced_model(length=3197):
    """
    Enhanced 1-D CNN with multi-scale feature representation, Batch Normalization,
    dual pooling (Average + Max), and dropout regularization.
    """
    inp = layers.Input(shape=(length, 1))

    # Stage 1: Local transit edge detection
    c1 = layers.Conv1D(32, 7, padding="same", activation="relu")(inp)
    c1 = layers.BatchNormalization()(c1)
    p1 = layers.MaxPooling1D(4)(c1)

    # Stage 2: Ingress/egress and transit bottom shape
    c2 = layers.Conv1D(64, 5, padding="same", activation="relu")(p1)
    c2 = layers.BatchNormalization()(c2)
    p2 = layers.MaxPooling1D(4)(c2)

    # Stage 3: Broad orbital profile
    c3 = layers.Conv1D(128, 5, padding="same", activation="relu")(p2)
    c3 = layers.BatchNormalization()(c3)

    # Dual temporal pooling: captures both peak dip depth (max) and duration (avg)
    gap = layers.GlobalAveragePooling1D()(c3)
    gmp = layers.GlobalMaxPooling1D()(c3)
    merged = layers.concatenate([gap, gmp])

    d1 = layers.Dense(128, activation="relu")(merged)
    d1 = layers.Dropout(0.4)(d1)
    d2 = layers.Dense(32, activation="relu")(d1)
    out = layers.Dense(1, activation="sigmoid")(d2)

    model = keras.Model(inputs=inp, outputs=out)
    model.compile(
        optimizer=keras.optimizers.Adam(learning_rate=1e-3),
        loss="binary_crossentropy",
        metrics=["accuracy"]
    )
    return model


def prepare_augmented_training_data(X_train_raw, y_train_raw, rng, n_injections=1200):
    """
    Augment real confirmed Kepler planets via circular rolling shifts and
    inject realistic physical trapezoid transits into quiet Kepler host stars.
    """
    planet_indices = np.where(y_train_raw == 1)[0]
    nonplanet_indices = np.where(y_train_raw == 0)[0]

    # 1. Circular phase shifts of confirmed planets
    aug_planets = []
    for idx in planet_indices:
        row = X_train_raw[idx]
        aug_planets.append(row)
        for shift in [50, 150, 300, 500, 750, 1000, 1300, 1600, 1900, 2200, 2500, 2800]:
            aug_planets.append(np.roll(row, shift))
    aug_planets = np.array(aug_planets)

    # 2. Physics-based transit injection into real host stars
    times = np.arange(3197) * (29.42 / (60 * 24.0))  # 65.3-day Kepler baseline
    injected_planets = []
    sample_nonplanets = rng.choice(nonplanet_indices, size=n_injections, replace=False)
    for idx in sample_nonplanets:
        base_flux = X_train_raw[idx].copy()
        med = np.median(base_flux)
        if med <= 0:
            med = 1.0
        norm_flux = base_flux / med

        depth = rng.uniform(0.001, 0.01)  # 0.1% to 1.0% transit depth
        params = random_transit_parameters(times, depth, rng, min_period=1.5, max_period=20.0)
        inj_flux = inject(times, norm_flux, params["period"], params["t0"], params["duration"], params["depth"])
        injected_planets.append(inj_flux * med)
    injected_planets = np.array(injected_planets)

    all_positives = np.vstack([aug_planets, injected_planets])
    all_negatives = X_train_raw[nonplanet_indices]

    X_train_combined = np.vstack([all_positives, all_negatives])
    y_train_combined = np.array([1] * len(all_positives) + [0] * len(all_negatives))

    perm = rng.permutation(len(y_train_combined))
    return X_train_combined[perm], y_train_combined[perm]


def score_predictions(y_true, y_probs, threshold=DECISION_THRESHOLD):
    y_pred = (y_probs >= threshold).astype(int)
    cm = confusion_matrix(y_true, y_pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    return {
        "recall": float(recall_score(y_true, y_pred, zero_division=0)),
        "precision": float(precision_score(y_true, y_pred, zero_division=0)),
        "average_precision": float(average_precision_score(y_true, y_probs)),
        "roc_auc": float(roc_auc_score(y_true, y_probs)),
        "tp": int(tp), "fn": int(fn), "fp": int(fp), "tn": int(tn),
    }


def train_one_model(x_tr_raw, y_tr_raw, x_val_raw, y_val_raw, verbose=0):
    rng = np.random.RandomState(SEED)
    X_tr_aug, y_tr_aug = prepare_augmented_training_data(x_tr_raw, y_tr_raw, rng, n_injections=800)
    X_tr_proc = preprocess_flux(X_tr_aug, target_length=3197)
    X_val_proc = preprocess_flux(x_val_raw, target_length=3197)

    model = build_enhanced_model(length=3197)
    callbacks = [
        keras.callbacks.EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True),
        keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=2, min_lr=1e-5)
    ]
    history = model.fit(
        X_tr_proc, y_tr_aug,
        batch_size=64,
        epochs=12,
        validation_data=(X_val_proc, y_val_raw),
        callbacks=callbacks,
        verbose=verbose
    )
    return model, history


def main():
    rng = np.random.RandomState(SEED)
    keras.utils.set_random_seed(SEED)

    os.makedirs(RESULTS_DIR, exist_ok=True)

    print("Loading Kepler training and testing data...")
    X_train_raw, y_train_raw = load_kepler_csv(TRAIN_CSV)
    X_test_raw, y_test = load_kepler_csv(TEST_CSV)

    print("Generating physics-informed augmented training dataset...")
    X_train_aug, y_train_aug = prepare_augmented_training_data(X_train_raw, y_train_raw, rng, n_injections=1200)
    print(f"Total training set size: {len(y_train_aug)} ({np.sum(y_train_aug)} positive, {np.sum(y_train_aug == 0)} negative)")

    print("Executing deterministic 5-stage preprocessing...")
    X_train_proc = preprocess_flux(X_train_aug, target_length=3197)
    X_test_proc = preprocess_flux(X_test_raw, target_length=3197)

    print("Building and training enhanced 1-D CNN...")
    model = build_enhanced_model(length=3197)

    callbacks = [
        keras.callbacks.EarlyStopping(monitor="val_loss", patience=5, restore_best_weights=True),
        keras.callbacks.ReduceLROnPlateau(monitor="val_loss", factor=0.5, patience=2, min_lr=1e-5)
    ]

    model.fit(
        X_train_proc, y_train_aug,
        batch_size=64,
        epochs=15,
        validation_split=0.15,
        callbacks=callbacks,
        verbose=1
    )

    print(f"Saving trained model to {MODEL_OUT}...")
    model.save(MODEL_OUT)

    print("Evaluating on held-out test set (exoTest.csv)...")
    test_preds = model.predict(X_test_proc, verbose=0).ravel()
    test_binary = (test_preds >= DECISION_THRESHOLD).astype(int)

    rec = recall_score(y_test, test_binary)
    prec = precision_score(y_test, test_binary, zero_division=0)
    auc = roc_auc_score(y_test, test_preds)
    ap = average_precision_score(y_test, test_preds)
    cm = confusion_matrix(y_test, test_binary)

    # Stricter app threshold
    app_binary = (test_preds >= APP_PLANET_LIKELY).astype(int)
    app_rec = recall_score(y_test, app_binary)
    app_prec = precision_score(y_test, app_binary, zero_division=0)

    print("\n" + "=" * 50)
    print("FINAL RESULTS ON UNTOUCHED exoTest.csv")
    print("=" * 50)
    print(f"ROC-AUC:               {auc:.4f}")
    print(f"Average Precision (AP): {ap:.4f} (baseline random = {y_test.mean():.4f})")
    print(f"Recall (threshold 0.5): {rec:.4f} ({cm[1,1]}/{cm[1,0]+cm[1,1]} planets)")
    print(f"Precision (thr 0.5):   {prec:.4f}")
    print(f"Confusion Matrix:\n{cm}")
    print(f"Individual Planet Scores: {np.round(test_preds[y_test == 1], 4)}")

    # Plot Precision-Recall Curve
    precision_curve, recall_curve, _ = precision_recall_curve(y_test, test_preds)
    plt.figure(figsize=(6, 5))
    plt.plot(recall_curve, precision_curve, color="#2b6cb0", lw=2.5, label=f"Enhanced CNN (AP = {ap:.3f})")
    plt.axhline(y_test.mean(), color="gray", linestyle="--", label=f"Random Baseline ({y_test.mean():.3f})")
    plt.xlabel("Recall", fontsize=11)
    plt.ylabel("Precision", fontsize=11)
    plt.title("Precision-Recall Curve on Held-Out Kepler Test Data", fontsize=12, fontweight="bold")
    plt.grid(True, alpha=0.3)
    plt.legend(loc="upper right")
    plt.tight_layout()
    plt.savefig(PLOT_OUT, dpi=200)
    plt.close()
    print(f"Saved PR curve plot to {PLOT_OUT}")

    # Write evaluation report
    report = f"""# Real Kepler/K2 Light-Curve Evaluation Report

**Model:** Enhanced 1-D CNN with multi-scale temporal pooling and transit-injection augmentation  
**Held-out test set:** `exoTest.csv` (570 stars, 5 confirmed planets, 565 non-planets)  
**Evaluation Date:** {time.strftime('%Y-%m-%d %H:%M:%S')}  

## Summary of Results

| Metric | Threshold 0.5 | Threshold 0.7 (Planet Likely) |
|---|---|---|
| **Recall** | **{rec:.3f}** ({cm[1,1]}/5 planets) | **{app_rec:.3f}** |
| **Precision** | **{prec:.3f}** | **{app_prec:.3f}** |
| **ROC AUC** | **{auc:.4f}** | **{auc:.4f}** |
| **Average Precision (PR AUC)** | **{ap:.4f}** | **{ap:.4f}** |

## Confusion Matrix (Threshold 0.5)

| | Predicted Non-Planet | Predicted Planet |
|---|---|---|
| **Actual Non-Planet** | {cm[0,0]} | {cm[0,1]} (False Alarms) |
| **Actual Planet** | {cm[1,0]} | {cm[1,1]} (True Positives) |

## Scores for the 5 Confirmed Test Planets

{', '.join(str(s) for s in np.round(test_preds[y_test == 1], 4))}
"""
    with open(REPORT_OUT, "w") as f:
        f.write(report)
    print(f"Saved evaluation report to {REPORT_OUT}")


if __name__ == "__main__":
    main()
