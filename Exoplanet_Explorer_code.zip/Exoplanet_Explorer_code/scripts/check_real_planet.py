"""
check_real_planet.py
--------------------
An independent check that this project works on real data.

It downloads real Kepler photometry of the star Kepler-8 from NASA's MAST
archive, runs it through our own detrending and Box Least Squares search,
and compares the period we measure against the published value.

Nothing about the planet is given to the code. The period is measured
from the brightness measurements alone.

Run it with:   python -m scripts.check_real_planet   (from the project folder)
"""

import numpy as np

from research.bls import bls_search
from research.detrend import detrend, estimate_noise
from research.kepler_data import get_light_curve

# Kepler-8 b. The published values come from the NASA Exoplanet Archive and
# are used ONLY to score ourselves at the end.
KIC = 6922244
PUBLISHED_PERIOD_DAYS = 3.52254
PUBLISHED_RADIUS_RATIO = 0.0966

print("Downloading real Kepler photometry for KIC %d ..." % KIC)
times, flux, provenance = get_light_curve(KIC, max_quarters=2)

print()
print("WHAT WE DOWNLOADED (real telescope data)")
print("  source           :", provenance["source"])
print("  files            :", len(provenance["files"]), "quarterly FITS files")
print("  raw cadences     :", provenance["n_raw_cadences"])
print("  removed as NaN   :", provenance["n_removed_nan"], "(gaps in the data)")
print("  removed as flagged:", provenance["n_removed_quality_flagged"],
      "(cosmic rays, thruster firings)")
print("  usable points    :", provenance["n_used"])
print("  time span        : %.1f days" % provenance["time_span_days"])
print("  cadence          : %.1f minutes" % provenance["cadence_minutes"])

flattened = detrend(flux, "median")
print()
print("  noise after detrending: %.4f%%" % (estimate_noise(flattened) * 100))

print()
print("Searching for a repeating transit (no period supplied) ...")
result = bls_search(flattened, times=times, n_periods=3000)

measured_ratio = float(np.sqrt(max(result["depth"], 0.0)))
period_error = abs(result["period"] - PUBLISHED_PERIOD_DAYS) / PUBLISHED_PERIOD_DAYS * 100

print()
print("RESULT")
print("  %-18s %12s %12s %10s" % ("quantity", "we measured", "published", "error"))
print("  %-18s %12.5f %12.5f %9.2f%%"
      % ("period (days)", result["period"], PUBLISHED_PERIOD_DAYS, period_error))
print("  %-18s %12.4f %12.4f %10s"
      % ("radius ratio", measured_ratio, PUBLISHED_RADIUS_RATIO, ""))
print("  %-18s %12.3f %12s %10s"
      % ("depth (%)", result["depth"] * 100, "-", ""))
print("  %-18s %12.2f %12s %10s"
      % ("duration (hours)", result["duration"] * 24, "-", ""))
print("  %-18s %12.1f %12s %10s"
      % ("SDE", result["sde"], "> 8 is strong", ""))

print()
if period_error < 1.0 and result["sde"] > 8:
    print("PASS - the pipeline independently recovered a real published planet")
    print("       to within %.2f%% of its catalogued period." % period_error)
else:
    print("FAIL - period error %.2f%%, SDE %.1f" % (period_error, result["sde"]))
