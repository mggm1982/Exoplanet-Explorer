# Exoplanet Transit Detector

A small web app that looks for **transits** — the tiny dip in a star's
brightness that happens when a planet passes in front of it.

It has three tools:

| Tab | Input | Method |
|-----|-------|--------|
| **Light-Curve Detector** | a CSV of light curves | an enhanced 1-D convolutional neural network with physics-informed augmentation |
| **Research & Validation** | real NASA data | three studies: noise removal, false-positive rejection (7,328 KOIs), single transits |
| **Molecular Composition** | a transmission spectrum CSV | physical band matching for H2O, CH4, CO2, CO, SO2, Na, K (no ML) |

> ⚠️ **Screening tool only — not a confirmed discovery.** The CSV tool can use a
> model trained on real Kepler/K2 data or one trained on simulated data; see
> [Data & sources](#data--sources) for exactly what is real and what is simulated.

---

## Setup

You need Python 3.10 or newer.

```bash
# 1. make a virtual environment (keeps these packages separate from your system)
python3 -m venv venv
source venv/bin/activate          # on Windows: venv\Scripts\activate

# 2. install everything
pip install -r requirements.txt
```

TensorFlow is a large download (about 500 MB), so the first install takes a
few minutes.

## How to run

```bash
uvicorn app:app --reload
```

Then open <http://127.0.0.1:8000> in your browser.

The `--reload` flag restarts the server automatically when you edit a file,
which is handy while you are working on it.

## How to use

### CSV tab

1. Choose a model in the **Model** dropdown: *real Kepler/K2 data* (the default
   when `models/exoplanet_model_real.keras` exists) or *simulated data*. Use the
   simulated model for `data/simulated/sample_stars.csv`, which is simulated 1500-point data.
   The results always say which model answered ("Model trained on: …").
   Each model's input length is read from the model itself (1500 for simulated,
   3197 for real); shorter rows are edge-padded and longer rows trimmed.
2. Drag `data/simulated/sample_stars.csv` onto the drop box (or click it and choose a file).
3. You get one row per star with a probability and a verdict.
4. Click any row, or use the dropdown, to see that star's cleaned light curve.

Your CSV needs **one star per row** and its brightness measurements spread
across the columns. A column called `LABEL` is optional:

* it is **removed before the model sees anything**, so it cannot cheat
* it is shown in the table as the "True label" (`2` = planet, `1` = no planet)
* rows where the model disagrees with the label are tinted red

---

## How it works, in simple words

### The CSV tab

A star's measured brightness wobbles for lots of boring reasons, so the raw
numbers are cleaned first. **These five steps are copied exactly from the
training script.** If you change them, the model's answers stop meaning
anything.

1. **Fill in the gaps.** Any missing value becomes the median of every value
   in the file.
2. **Flatten the slow drift.** Compute a running median over a window of 101
   points and subtract it. Slow changes vanish; short sharp dips survive.
3. **Put every star on the same scale.** Divide each star by its own standard
   deviation, so a bright star and a faint star look comparable.
4. **Cut off the extremes.** Clip everything to the range −20 to 10, so a
   single bad pixel cannot dominate.
5. **Make every star the same length.** Trim or pad to the model's input
   length (3197 points for the real model, 1500 for the simulated one).

The cleaned curve goes into the neural network, which returns one number
between 0 and 1:

| Probability | Verdict |
|-------------|---------|
| 0.70 and above | **Planet likely** |
| 0.30 to 0.70 | **Borderline** |
| below 0.30 | **No planet** |

The real-data network has three convolution layers (32, 64 and 128 filters)
that learn what a dip looks like, then average- and max-pooling over time and
two dense layers that make the decision. (The older simulated-data model is
smaller: 16, 32 and 64 filters.) Convolution is a good fit here because a transit looks the same
whether it happens near the start or the end of the recording.

---

## The Molecular Composition tab

Upload a **transmission spectrum** (column 1 = wavelength in µm, column 2 =
transit depth, optional column 3 = uncertainty), or click one of the four
bundled example spectra (these are **simulated**, in `data/simulated/spectra/`).

For H2O, CH4, CO2, CO, SO2, Na and K, `research/composition.py` compares the
mean depth inside the molecule's absorption band with the nearby continuum
and reports how many noise units (σ) it stands out by: ≥ 5σ = strong feature,
≥ 3σ = possible feature. **There is no neural network and no training here.**
It is physical band matching, not a full atmospheric retrieval, so a
"feature" means "deeper at that band", not proof the molecule is present.
Bands that overlap badly (H2O/CO2 near 2.7 µm) are not scored, and known
overlaps (e.g. CH4 near 1.4 µm) are flagged in the report.

## The Research tab

The Research tab runs on **real NASA data**: Kepler light curves
from MAST and the vetted Kepler Objects of Interest table. Three studies:

1. **Detecting weak signals in noisy data** — which noise-removal method
   finds the shallowest transits without inventing false ones? Measured by
   injecting transits of known depth into a real Kepler light curve.
2. **Rejecting false positives** — a two-stage system (physical rules, then
   a hand-written logistic regression) on 7,328 real vetted signals.
3. **Single transits** — finding and ranking planets that transit only once,
   where the period cannot be measured at all.

Full write-up, results and limitations: **[docs/RESEARCH.md](docs/RESEARCH.md)**.
Where every number comes from: **[docs/data_provenance.md](docs/data_provenance.md)**.

The Idea 1 experiment takes about ten minutes, so its results are computed
ahead of time and cached:

```bash
python -m research.run_all
```

## Project layout

```
exoplanet/
├── app.py                 FastAPI server: serves the web page and the API (run: uvicorn app:app)
├── requirements.txt       Python libraries
├── pytest.ini             test settings
├── detector/              the light-curve CNN tool
│   ├── preprocess.py      the 5 cleaning steps (same code in training and in the app)
│   └── cnn_predict.py     loads both models once, predicts, assigns verdicts
├── research/              the three real-data studies (hand-written numpy)
│   ├── datasources.py     NASA Exoplanet Archive: confirmed planets + the KOI table
│   ├── kepler_data.py     real Kepler light curves from MAST (FITS via astropy)
│   ├── detrend.py         the four noise-removal methods being compared
│   ├── wavelet.py         a hand-written Haar wavelet denoiser
│   ├── bls.py             Box Least Squares transit search
│   ├── inject.py          planting fake transits of known depth
│   ├── experiment.py      Idea 1: injection-recovery experiment
│   ├── vetting.py         Idea 2: physical checks that catch impostors
│   ├── pipeline.py        Idea 2: two-stage system + logistic regression
│   ├── single_transit.py  Idea 3: matched filter and candidate ranking
│   ├── composition.py     molecular composition report (band matching, no ML)
│   └── run_all.py         regenerates the cached results
├── scripts/               run from the project folder with  python -m scripts.<name>
│   ├── train_real_lightcurve.py   trains models/exoplanet_model_real.keras
│   ├── cv_real_lightcurve.py      5-fold cross-validation of that recipe
│   ├── make_figures.py            redraws results/figures/ from the saved models
│   └── check_real_planet.py       measures Kepler-8 b's period from real photometry
├── models/
│   ├── exoplanet_model_real.keras the real Kepler/K2 model
│   └── exoplanet_model.keras      the older simulated-data model
├── data/
│   ├── real/              Kaggle Kepler data: exoTrain.csv, exoTest.csv
│   ├── simulated/         exoTrain_data.csv, sample_stars.csv, spectra/ (4 example spectra)
│   └── cache/             NASA downloads + saved research results (results/idea1.json, idea2.json)
├── results/               reports and figures written by the scripts
├── docs/
│   ├── RESEARCH.md        full write-up of the three studies
│   └── data_provenance.md where every number comes from
├── static/                the web page (index.html, style.css, main.js)
└── tests/                 pytest suite (66 tests)
```

### API endpoints

| Method | Path | Takes | Returns |
|--------|------|-------|---------|
| `GET` | `/health` | — | whether the server is up, which light-curve models are loaded, and the default |
| `POST` | `/api/predict-csv` | `file` (multipart) + optional `model` (`real` / `simulated`) | a probability, verdict and cleaned curve per star, plus `model_trained_on` |
| `GET` | `/api/research/sources` | — | where every dataset comes from, with citations |
| `GET` | `/api/research/idea1` | — | the detrending comparison |
| `GET` | `/api/research/idea2` | — | the false-positive study |
| `POST` | `/api/research/idea3` | `file` + `detrend_method` | single-transit candidates |
| `GET` | `/api/composition/examples` | — | the bundled example spectra |
| `GET` | `/api/composition/example/{id}` | — | composition report for one example |
| `POST` | `/api/composition` | `file` (spectrum CSV) | composition report: verdict and σ per molecule |

## Data & sources

**Real data**

* **Kaggle, "Kepler Labelled Time Series Data"** (`exoTrain.csv`, `exoTest.csv`):
  real Kepler/K2 brightness measurements, 3197 points per star, labelled
  2 = planet, 1 = no planet. Used to train and test `exoplanet_model_real.keras`.
  The files go in `data/real/`; download them yourself from Kaggle (no login is
  done by this project).
* **NASA Exoplanet Archive**, Kepler cumulative KOI table and confirmed planets
  (Research tab), and **MAST** Kepler light curves (FITS).

**Simulated**

* `exoplanet_model.keras`, the original light-curve model, trained on simulated
  light curves (and `sample_stars.csv` is simulated too).

**Acknowledgement** (text requested by the NASA Exoplanet Archive):

> This research has made use of the NASA Exoplanet Archive, which is operated
> by the California Institute of Technology, under contract with the National
> Aeronautics and Space Administration under the Exoplanet Exploration Program.

## Real-data light-curve model

```bash
python -m scripts.train_real_lightcurve   # about 1 minute on an Apple M3 CPU
python -m scripts.cv_real_lightcurve      # about 10 minutes
```

Full results: `results/real_lightcurve_report.md` and
`results/real_lightcurve_cv_report.md`. Honest summary:

| | Held-out exoTest (570 stars, 5 planets) | 5-fold CV (5657 stars, 42 planets) |
|---|---|---|
| ROC AUC | 0.959 | 0.794 ± 0.086 |
| Average precision | 0.394 | 0.213 ± 0.109 |
| Planet recall at 0.5 | 0.40 (2 of 5) | 0.192 ± 0.061 (8 of 42 overall) |
| Planet precision at 0.5 | 0.50 (2 false alarms) | 0.353 ± 0.146 (19 false alarms) |

The model **ranks** planets above most non-planets (AUC well above 0.5, average
precision 30x better than random), but at a 0.5 threshold it **misses most
planets**. Accuracy is not reported: always saying "no planet" scores ~99%.

## Tests

```bash
pytest
```

66 tests covering the composition report, the cleaning steps, the CSV endpoint, the real model, the
expected answers for the sample CSV, a pile of bad uploads,
and the whole research package — including regression tests for four real
bugs that were found and fixed during development (see docs/RESEARCH.md).

The research tests are offline: they use synthetic signals with known
answers, so the suite runs fast and passes with no internet.

## Look and feel

The colours are sampled from the reference animation video: a dark forest
green background (`#16382A`), near-white text (`#FBFBFB`) and a bright green
accent (`#32C010`). They are all defined as CSS variables at the top of
`static/style.css`, so changing the palette means editing one block.

While the server is working, a **thinking sphere** appears: a glowing green
ball with three rings orbiting it. It is built entirely from CSS — no images,
no JavaScript animation loop and no extra library. Three flat circles are
tilted back with `rotateX`, spaced apart with `rotateY`, and each carries a
dot on its edge, so spinning the circle makes the dot orbit the ball. The code
is in the "THE THINKING SPHERE" section of `static/style.css` and it honours
`prefers-reduced-motion` for anyone who finds movement uncomfortable.

## Limitations — please read

* **The real-data CNN misses most planets at a 0.5 threshold** (19% recall in
  cross-validation). It is a ranking aid, not a stand-alone detector.
* **The simulated model was trained on simulated light curves.** Do not point
  it at real Kepler or TESS data and believe the answer.
* **Inputs are trimmed or padded** to the model's length, which can distort
  the shape of the curve.
* **A dip is not a planet.** Eclipsing binary stars, starspots and instrument
  faults all make dips. Confirming a real exoplanet takes follow-up
  observations by other methods.
* **The verdict thresholds (0.3 / 0.7) are hand-picked**, not tuned on test data.
* **No upload is stored.** Files are processed in memory (or a temporary file
  that is deleted straight after) and never saved.
