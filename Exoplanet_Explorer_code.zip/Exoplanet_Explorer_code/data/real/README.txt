Put the real Kaggle Kepler files here:
  exoTrain.csv  (copy of 'training data/exoTrain_real_kepler.csv')
  exoTest.csv   (copy of 'testing data/exoTest_real_kepler.csv')
