sample_stars.csv and spectra/ are included. Put exoTrain_data.csv here (copy of 'training data/exoTrain_simulated.csv') if you need the simulated training set.
