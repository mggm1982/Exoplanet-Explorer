"""
cnn_predict.py
--------------
Loads the trained CNN once and uses it to score light curves.

The model is NOT retrained and NOT modified here. We only load it and call
predict() on data that has already been through preprocess.py.
"""

import os
import numpy as np

from detector.preprocess import preprocess_flux

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # project folder

# The two light-curve models the app knows about.
#   "simulated" - the original model, trained on simulated light curves (1500 points)
#   "real"      - trained on real Kepler/K2 data by train_real_lightcurve.py (3197 points)
MODEL_FILES = {
    "simulated": os.path.join(HERE, "models", "exoplanet_model.keras"),
    "real": os.path.join(HERE, "models", "exoplanet_model_real.keras"),
}

# Text shown next to the results so the user knows which model answered.
MODEL_TRAINED_ON = {
    "simulated": "simulated data",
    "real": "real Kepler/K2 data (Kaggle)",
}

# Kept for older code: the path of the simulated model.
MODEL_PATH = MODEL_FILES["simulated"]

# Probability thresholds for turning a number into words.
PLANET_THRESHOLD = 0.7      # >= this  -> "Planet likely"
NO_PLANET_THRESHOLD = 0.3   # <  this  -> "No planet"
                            # in between -> "Borderline"

# Loaded models are kept here (name -> model) so each is loaded only once.
_models = {}


class ModelLoadError(Exception):
    """Raised when a .keras file cannot be loaded at all."""


def _load_one(name):
    """Load one model file by name ("simulated" or "real") and remember it."""
    if name in _models:
        return _models[name]

    path = MODEL_FILES[name]
    if not os.path.exists(path):
        raise ModelLoadError("Model file not found: " + path)

    # Import keras here, not at the top, so that importing this module is fast
    # and the other science modules do not need TensorFlow installed.
    import keras

    try:
        _models[name] = keras.models.load_model(path)
    except Exception as error:
        raise ModelLoadError(
            "Could not load " + os.path.basename(path) + ": " + str(error)
        )
    return _models[name]


def load_models():
    """
    Load every light-curve model at startup.
    The simulated model is required (an error is raised if it fails).
    The real model is optional: if its file does not exist we simply skip it.
    Returns the list of model names that are ready.
    """
    _load_one("simulated")
    if os.path.exists(MODEL_FILES["real"]):
        _load_one("real")
    return available_models()


def load_model():
    """Older name, kept so existing code still works: loads all models."""
    load_models()
    return _models["simulated"]


def available_models():
    """Names of the models that are loaded, real first if it is there."""
    return [name for name in ("real", "simulated") if name in _models]


def default_model_name():
    """The real model if it is loaded, otherwise the simulated one."""
    return "real" if "real" in _models else "simulated"


def expected_length(name):
    """How many points per star this model wants: read from the model itself."""
    return int(_load_one(name).input_shape[1])


def verdict_for_probability(probability):
    """Turn a probability between 0 and 1 into a short plain-English verdict."""
    if probability >= PLANET_THRESHOLD:
        return "Planet likely"
    if probability >= NO_PLANET_THRESHOLD:
        return "Borderline"
    return "No planet"


def predict_stars(flux, labels=None, model_name="simulated"):
    """
    Score a batch of stars.

    Input:
      flux   - 2-D array, one row per star, raw flux values.
      labels - optional list of true labels (2 = planet, 1 = no planet),
               one per star. Used only for display, never for prediction.
      model_name - "simulated" or "real": which model to use.

    Output: a list of dictionaries, one per star, each containing:
      star_index, probability, verdict, true_label, curve
    """
    model = _load_one(model_name)

    # Each model was trained on a fixed number of points; ask the model itself.
    length = int(model.input_shape[1])

    # Clean the data exactly the way the training script did.
    clean = preprocess_flux(flux, target_length=length)

    # Ask the model for one probability per star.
    probabilities = model.predict(clean, verbose=0).ravel()

    results = []
    for i in range(clean.shape[0]):
        probability = float(probabilities[i])

        # The label is only shown to the user; it never touches the model.
        true_label = None
        if labels is not None and i < len(labels):
            true_label = labels[i]

        results.append({
            "star_index": i + 1,
            "probability": round(probability, 4),
            "verdict": verdict_for_probability(probability),
            "true_label": true_label,
            # The cleaned curve, rounded and flattened, so the browser can plot it.
            "curve": [round(float(v), 4) for v in clean[i].reshape(length)],
        })

    return results
