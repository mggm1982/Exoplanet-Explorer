"""Light-curve detector: the 5-step cleaning (preprocess) and the CNN models (cnn_predict)."""
