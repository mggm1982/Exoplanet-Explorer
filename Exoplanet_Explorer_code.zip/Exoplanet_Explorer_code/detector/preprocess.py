"""
preprocess.py
-------------
Turns raw flux numbers from a CSV into the exact shape the CNN was trained on.

The five steps below are the same ones used during training, in the same order.
If you change them, the model's predictions stop being meaningful.
"""

import numpy as np
from scipy.ndimage import median_filter

# The SIMULATED-data CNN was trained on light curves of exactly this length.
# (The real-data CNN uses a different length; callers pass it in as
#  target_length, read from model.input_shape[1].)
POINTS_PER_STAR = 1500

# Window of the running median, in data points. Must match training.
RUNNING_MEDIAN_WINDOW = 101

# After dividing by the standard deviation, very extreme values are cut off
# so that one bad point cannot dominate the whole light curve.
CLIP_LOW = -20.0
CLIP_HIGH = 10.0


def preprocess_flux(flux, target_length=POINTS_PER_STAR):
    """
    Clean a batch of light curves.

    Input:  flux - a 2-D numpy array, one row per star, one column per time step.
                   Rows may have any length and may contain NaN.
            target_length - how many points each star should end up with.
                   Defaults to 1500 (the simulated model). Steps (a)-(d)
                   are the same whatever this number is.
    Output: a 3-D float32 array of shape (n_stars, target_length, 1).
    """
    # Work on a float copy so we never modify the caller's array.
    data = np.asarray(flux, dtype=np.float64).copy()

    # Guard against a 1-D array (a single star) being passed in.
    if data.ndim == 1:
        data = data.reshape(1, -1)

    # --- (a) fill NaN with the global median -----------------------------
    # The median of every finite number in the whole batch, not per star.
    finite_values = data[np.isfinite(data)]
    if finite_values.size == 0:
        # Every value is missing. Fall back to zeros rather than crashing.
        global_median = 0.0
    else:
        global_median = float(np.median(finite_values))
    data[~np.isfinite(data)] = global_median

    # --- (b) subtract a running median along the time axis ---------------
    # This removes slow drifts in brightness and leaves the short dips.
    # axis=1 is the time axis; "nearest" repeats the edge value at the ends.
    smooth = median_filter(
        data,
        size=(1, RUNNING_MEDIAN_WINDOW),
        mode="nearest",
    )
    data = data - smooth

    # --- (c) divide each star by its own standard deviation --------------
    # Now every star is on the same scale, whatever its real brightness was.
    for i in range(data.shape[0]):
        star_std = data[i].std()
        if star_std > 0:
            data[i] = data[i] / star_std
        # If the std is 0 the row is perfectly flat, so leave it as zeros.

    # --- (d) clip to [-20, 10] -------------------------------------------
    data = np.clip(data, CLIP_LOW, CLIP_HIGH)

    # --- (e) trim or edge-pad each star to exactly target_length points ---
    data = _fix_length(data, target_length)

    # The CNN expects one "channel" at the end, like a 1-pixel-tall image.
    return data.reshape(data.shape[0], target_length, 1).astype(np.float32)


def _fix_length(data, target_length):
    """
    Make every row exactly target_length long.
    Too long  -> keep the first target_length points.
    Too short -> repeat the last value until it fits ("edge" padding).
    """
    current_length = data.shape[1]

    if current_length == target_length:
        return data

    if current_length > target_length:
        return data[:, :target_length]

    # Too short: pad on the right only, repeating the edge value.
    missing = target_length - current_length
    return np.pad(data, ((0, 0), (0, missing)), mode="edge")
