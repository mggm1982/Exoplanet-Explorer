# Research

Three studies that go beyond the demo app. All three run on **real NASA
data**, not on the simulated CSVs in this folder. See `data_provenance.md` (in this docs folder)
for where every number comes from.

Run them from the web app's **Research** tab, or regenerate the saved
results with:

```bash
python -m research.run_all      # takes about 10 minutes
```

---

## Idea 1 — Detecting weak signals in noisy data

**Research question.** Can a noise-aware pipeline find shallower transits
without also inventing transits that are not there?

**Why both halves matter.** A method that flags everything will "recover"
every injected planet and look brilliant, until you check how often it
fires on pure noise. So the experiment measures both.

**Method.**
1. Take a **real** Kepler light curve of a star with no known planet
   (KIC 8425723 — checked: it is not a Kepler Object of Interest, and a
   blind search of it returns SDE 4.1, below any sensible threshold).
2. Inject a trapezoid transit of known depth, period and duration.
3. Detrend with each of four methods, then search with Box Least Squares.
4. Count it as recovered if the found period matches the injected one, or
   a harmonic of it, and the peak reaches SDE ≥ 8.
5. Separately, shuffle the flux — which keeps the noise identical but
   destroys any coherent signal — and count how often each method claims a
   detection anyway.

**The design detail that mattered most.** The orbits are drawn **once** and
reused for every depth and every method. Without this pairing, a method can
look better purely because it was handed easier periods, and the recovery
curve jumps around instead of falling smoothly. The first run of this
experiment produced recovery rates of 88, 96, 48, 96, 68, 76 % as depth
*decreased* — physically impossible, and a clear sign the measurement was
dominated by luck rather than depth.

### Results

Host: real Kepler photometry, 1787 points over 44.4 days, point-to-point
noise 0.0144 %. 25 injections per cell. Earth across the Sun is 0.0084 %.

| Method | 50 % limit | False-alarm rate | Null SDE | Depth kept |
|---|---|---|---|---|
| none (baseline) | 0.05 % | 0 % | 4.36 | 0.99 |
| running median | **0.02 %** | 4 % | 4.92 | 0.99 |
| Savitzky–Golay | **0.02 %** | 0 % | 4.44 | 0.97 |
| Haar wavelet | 0.10 % | **48 %** | 7.33 | **0.41** |

### What this says

1. **Wavelet denoising is actively harmful here, and the reason is
   visible in the numbers.** It keeps only 41 % of an injected transit's
   depth at 0.1 %, falling to 7 % at 0.003 % — the soft threshold cannot
   tell a shallow transit from noise, so it removes it. At the same time it
   inflates the null SDE from ~4.5 to 7.3, so it fires on pure noise 48 %
   of the time. Worse sensitivity *and* more false alarms.
2. **Running median and Savitzky–Golay are indistinguishable** at 25
   trials. Both reach 0.02 %. Savitzky–Golay keeps very slightly less depth
   (0.97 vs 0.99), consistent with it being a least-squares fit that gets
   pulled down by the transit, where a median does not.
3. **Detrending barely beat doing nothing on this star** (0.02 % vs
   0.05 %). That is an honest result and a limitation: this star is unusually
   quiet, so there was little trend to remove. A fair test needs several
   hosts with a range of stellar variability.

### Honest limitations

* One host star. The conclusions may not generalise.
* 25 trials per cell gives roughly ±10 % on each recovery rate, so the
  median-vs-Savitzky–Golay difference is not significant.
* "Depth kept" is only meaningful at high signal-to-noise. At the faintest
  depths it measures scatter, not filter loss — the `none` method shows
  0.70 there despite doing no filtering at all.

---

## Idea 2 — An intelligent false-positive rejection system

**Research question.** Can we reject false positives while keeping the
genuine planets?

**Data.** The real Kepler cumulative KOI table: 9,564 transit-like signals,
each dispositioned by the Kepler team. After dropping CANDIDATE rows (whose
answer nobody knows) and rows with missing measurements, 7,328 remain —
2,746 confirmed planets and 4,582 real, vetted false positives.

**Method.** Two stages:
1. **Physical rules.** Depth too deep for a planet, implied radius larger
   than any planet, a dip occupying too much of the orbit, a duration far
   longer than physics allows. These need no training.
2. **A logistic regression**, written by hand in numpy, on nine physical
   features of the signal.

Then both combined: a signal is called a planet only if it passes both.

**Two design choices that keep the result honest.**

* **No leakage.** The `koi_fpflag_*` columns are the Kepler team's own
  verdict. Feeding them to the classifier would be asking it to copy the
  answer. They are excluded, and used only as a reference point. There is a
  test that fails if they ever appear as a feature.
* **Split by star, not by signal.** One star can host several KOIs, which
  share systematics. Splitting by signal would let the model recognise the
  star rather than learn the physics.

### Results (test set: 2,178 signals from 1,927 unseen stars)

| Approach | Precision | Recall | FP rejected | Accuracy | Planets lost |
|---|---|---|---|---|---|
| Physical rules only | 0.542 | **0.996** | 0.500 | 0.685 | 3 |
| Learned model only | 0.696 | 0.891 | 0.769 | 0.815 | 88 |
| **Two-stage** | **0.700** | 0.891 | **0.773** | **0.817** | 88 |
| Official Kepler flags | 0.985 | 0.991 | 0.991 | 0.991 | 7 |

### What this says

1. **The answer to the research question is yes, partly.** The two-stage
   system rejects 77 % of real false positives while keeping 89 % of real
   planets, against a rules-only baseline that rejects only 50 %.
2. **Combining helps, but only slightly** (0.773 vs 0.769). The rules catch
   a handful of physically impossible cases the model waves through, which
   is worth having because those failures are the embarrassing kind.
3. **The official Kepler flags beat us comprehensively, and that is the
   most interesting result here.** They reach 0.99 on everything. They are
   not magic: they come from centroid analysis, pixel-level images and human
   inspection. Our nine summary numbers simply do not contain that
   information. The gap quantifies *how much* of false-positive vetting
   depends on data beyond the light curve — which is itself a finding, and
   points at what to do next.
4. The model leans hardest on **duty cycle** (−2.01) and **implied planet
   radius** (−1.55): a dip that lasts too long a fraction of its orbit, or
   implies too large an object, is a binary star. That matches the physics
   the hand-written rules encode, which is reassuring.

---

## Idea 3 — Detecting exoplanets with only one observed transit

**Research question.** Can we pick out promising candidates from a single
dip, with no repeat to confirm it?

**Why it is hard.** BLS searches for a *repeating* box. With one event there
is nothing to repeat, so the period cannot be measured at all — only bounded
from below, because a shorter period would have produced a second transit.

**Method.** A matched filter slides trapezoid templates of several durations
along the curve and reports the signal-to-noise of the best fit at each
position. Candidates are then judged on shape, because with one event shape
is the only evidence there is:

* **enough points** — a cosmic ray hits one or two cadences, not twenty
* **symmetry** — ingress and egress should take the same time
* **shape score** — fit both a flat-bottomed trapezoid and a V, and see
  which explains the data better. A real transit has a flat bottom; a
  grazing binary comes to a point.
* **depth** — too deep is a star
* **edges** — an event cut off by the start or end has unknown depth

### A measurement that had to be rebuilt

The first version of the shape test compared the depth at the centre of the
event with the depth at its edges. It did not work: the template duration is
rarely the true duration, so the "edges" were often measured *inside* the
event. Measured over 18 synthetic cases each way, flat-bottomed transits
scored 0.604–0.849 and V-shaped eclipses 0.524–0.914 — **overlapping
ranges, so no threshold could separate them.**

Fitting two whole shapes and asking which fits better, each given its own
choice of width, separates them properly:

| Injected shape | min | median | max |
|---|---|---|---|
| flat-bottomed transit | +0.020 | **+0.168** | +0.303 |
| V-shaped grazing eclipse | −0.876 | **−0.544** | +0.190 |

The one V that leaked positive is the faintest case. Shape discrimination
degrades exactly with signal-to-noise, as it must:

| V-shaped eclipse at | S/N | median shape score |
|---|---|---|
| 0.4 % depth | 42.7 | −0.810 |
| 0.2 % depth | 21.1 | −0.544 |
| 0.1 % depth | 10.4 | −0.167 |

So the shape rule is only applied above S/N 15. Below that the code says it
cannot tell, rather than guessing. **Knowing when a measurement is not
usable is part of the measurement.**

### Verified behaviour

On a real quiet Kepler light curve with one transit injected:

| Injected | Found at | S/N | Depth recovered |
|---|---|---|---|
| 0.400 % | 0.24 h off | 102.5 | 0.365 % |
| 0.100 % | 0.24 h off | 25.7 | 0.092 % |
| 0.040 % | 0.24 h off | 10.4 | 0.037 % |

The untouched curve yields **zero** candidates. Depth comes out ~8 % low
because the best-fitting template is slightly wider than the true event,
which dilutes it.

### Honest limitations

* The ranking score is a *triage* number for ordering follow-up, not a
  probability. It has not been calibrated against real single-transit
  candidates, because confirmed ones are rare.
* Only injected events have been tested, never a real catalogued
  single-transit planet.
* With no period, nothing here can confirm a planet. The honest output is a
  ranked shortlist, which is what the real surveys produce too.

---

## What a marker should take from this

The three studies share one habit worth more than any individual number:
**every result was checked for whether it could be true before it was
believed.** A non-monotonic recovery curve, a shape metric whose two classes
overlapped, a matched filter that searched for transits a fraction of a data
point wide, a host star that turned out not to be quiet — each of these
looked like a result until it was interrogated. Three of them were caught
only because the numbers were plotted and read, not just computed.
