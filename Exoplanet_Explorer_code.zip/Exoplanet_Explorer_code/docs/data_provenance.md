# Where the data comes from

This file answers one question: **for every number this project produces,
where did the input come from?** Keep it up to date — a result whose source
you cannot name is not a result.

---

## Summary table

| Data | Real or simulated? | Source | Loaded by |
|---|---|---|---|
| `exoTrain_data.csv` | **SIMULATED** | generated for this project | `research/experiment.py`, notebooks |
| `sample_stars.csv` | **SIMULATED** | generated for this project | `tests/test_csv_api.py`, the CSV tab |
| `exoplanet_model.keras` | **trained on simulated data** | trained in Colab on `exoTrain_data.csv` | `cnn_predict.py` line 52 |
| NASA confirmed planets | **REAL** | NASA Exoplanet Archive | `research/datasources.py` |
| Kepler KOI table | **REAL** | NASA Exoplanet Archive, `cumulative` table | `research/datasources.py` |
| Kepler light curves | **REAL** | MAST (FITS) | `research/kepler_data.py` |

---

## Source 1 — NASA Exoplanet Archive (real)

The only real, peer-reviewed data in the project.

* **What** Planetary Systems (`ps`) table — every confirmed exoplanet, with
  the published measurement the archive considers best (`default_flag = 1`).
* **Endpoint** `https://exoplanetarchive.ipac.caltech.edu/TAP/sync`
* **Protocol** TAP, returns CSV. No account, no API key.
* **Column reference** <https://exoplanetarchive.ipac.caltech.edu/docs/API_PS_columns.html>
* **Loaded by** `research/datasources.py` →
  `fetch_confirmed_transiting_planets()`
* **Cached at** `data/cache/nasa_confirmed_transiting.csv`, with a sidecar
  `…provenance.json` recording the exact query, the full URL, the UTC
  download time and the row count.
* **Rows returned** 482 confirmed transiting planets that have a published
  period, depth *and* radius ratio.

The exact query is stored as `CONFIRMED_TRANSITING_QUERY` in
`research/datasources.py`. Paste it into the archive's own web form and you
will get the same rows back — that is the point of keeping it as a constant.

**Citation (use this in any write-up):**

> This research has made use of the NASA Exoplanet Archive, which is
> operated by the California Institute of Technology, under contract with
> the National Aeronautics and Space Administration under the Exoplanet
> Exploration Program. DOI: 10.26133/NEA12

---

## Source 2 — the local CSV files (simulated)

`exoTrain_data.csv` (2500 × 1500, 238 planets) and `sample_stars.csv`
(12 × 1500, 6 planets) are **simulated**. The evidence:

1. **Not a single NaN** in 3,750,000 values. Real photometry always has
   gaps — spacecraft safe modes, cosmic-ray hits, downlink windows, momentum
   dumps. A gapless light curve is a generated one.
2. **Already normalised** to about 1.0. Raw telescope photometry is in
   electrons per second and runs to thousands.
3. **Uniform 5-decimal rounding** across every value in both files.
4. **Not the Kaggle "Exoplanet Hunting in Deep Space" set**, which people
   often assume. That file is 5087 × 3198 with raw unnormalised flux and 37
   planets. Ours is 2500 × 1500, normalised, with 238.
5. **9.5% of the stars have planets.** Real transit surveys find well under
   1%. This file has been deliberately balanced to make training work.

### Why this matters for the results

Measured against the real catalogue, the simulated transits are **easy**:

| | Simulated (`exoTrain_data.csv`) | Real (NASA, n=482) |
|---|---|---|
| Median transit depth | **0.45 %** | **0.15 %** |
| 10th percentile depth | 0.22 % | 0.025 % |
| Median Earth-sized depth | — | 0.043 % |
| Fraction of stars with a planet | 9.5 % | ≪ 1 % |

The simulated transits are about **three times deeper** than the median real
one, and roughly **ten times deeper** than a real Earth-sized transit. The
class balance is about **ten times** more favourable than reality.

**Consequence:** every accuracy figure the CNN produces is an optimistic
upper bound. It says the model can do this task on this simulator. It does
not say the model would find a real Earth-sized planet, and the project
should not claim that it does.

---

## Source 1b — Kepler Objects of Interest (real)

* **What** The `cumulative` KOI table: 9,564 transit-like signals Kepler's
  pipeline flagged, each dispositioned CONFIRMED (2,748), FALSE POSITIVE
  (4,839) or CANDIDATE (1,977).
* **Same endpoint and citation** as Source 1.
* **Loaded by** `research/datasources.py` → `fetch_koi_table()`
* **Cached at** `data/cache/kepler_koi_cumulative.csv`
* **Used for** Idea 2. This is real, human-vetted ground truth for false
  positives — we do not have to simulate any.
* **Warning** The `koi_fpflag_*` columns are the Kepler team's own verdict.
  They are never used as classifier inputs; a test enforces this.

## Source 1c — Kepler light curves from MAST (real)

* **What** Real photometry, one FITS file per quarter per star.
* **Archive** MAST (STScI). Search `https://mast.stsci.edu/api/v0/invoke`,
  download `https://mast.stsci.edu/api/v0.1/Download/file?uri=...`
* **Loaded by** `research/kepler_data.py` → `get_light_curve(kic)`
* **Cached at** `data/cache/kepler/`
* **Used for** Ideas 1 and 3, as a realistic test bed.
* **Citation** "Data collected by the NASA Kepler mission, obtained from the
  MAST archive at the Space Telescope Science Institute (STScI)."

How real this data is, in numbers — one quarter of KIC 6922244:

| | |
|---|---|
| raw cadences | 4,354 |
| NaN (gaps) | 284 (6.5 %) |
| quality-flagged (cosmic rays, thruster firings) | 964 |
| usable | 3,390 |
| flux units | ~50,000 electrons/second, **not** normalised |

The bundled CSVs have **zero** of any of that. That is the difference.

### Validation: the pipeline recovers a published planet

Run on real Kepler-8 photometry (KIC 6922244), the detrending + BLS
pipeline returns a period of **3.5176 days** against the published
**3.52254** — an error of **0.14 %** — with Rp/Rs 0.085 against a published
0.097. Nothing about that planet was supplied to the code; it was measured
from the photometry.


## Rule for this project

Anything downloaded goes through `research/datasources.py` and lands in
`data/cache/` with a provenance JSON beside it. If you add a new source, add
it there and add a row to the summary table above — do not scatter download
code across the project.
