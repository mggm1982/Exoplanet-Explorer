"""Tests for the CSV endpoint, which uses the trained CNN.

sample_stars.csv is simulated 1500-point data, so every test here asks for
the SIMULATED model explicitly. Real-model tests live in test_real_model.py.
"""

import os
from conftest import project_file


def test_health_says_the_model_is_loaded(client):
    response = client.get("/health")
    assert response.status_code == 200

    body = response.json()
    assert body["status"] == "ok"
    assert body["model_loaded"] is True, "the model failed to load: " + str(body["model_error"])


def test_sample_stars_returns_twelve_rows(client):
    """sample_stars.csv has 12 stars, so we expect 12 results."""
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        response = client.post(
            "/api/predict-csv",
            files={"file": ("sample_stars.csv", handle, "text/csv")},
            data={"model": "simulated"},  # sample_stars.csv is 1500-point simulated data
        )

    assert response.status_code == 200
    body = response.json()

    assert body["n_stars"] == 12
    assert len(body["results"]) == 12
    assert body["has_labels"] is True
    # The LABEL column must not be counted as flux.
    assert body["n_flux_columns"] == 1500


def test_most_planets_are_found(client):
    """At least 4 of the 6 real planets should score 0.5 or more."""
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        response = client.post(
            "/api/predict-csv",
            files={"file": ("sample_stars.csv", handle, "text/csv")},
            data={"model": "simulated"},  # sample_stars.csv is 1500-point simulated data
        )

    results = response.json()["results"]

    planets = [row for row in results if row["true_label"] == 2]
    assert len(planets) == 6

    found = [row for row in planets if row["probability"] >= 0.5]
    assert len(found) >= 4, "only " + str(len(found)) + " of 6 planets scored >= 0.5"


def test_every_row_has_what_the_chart_needs(client):
    """Each result must carry a probability, a verdict and a 1500-point curve."""
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        response = client.post(
            "/api/predict-csv",
            files={"file": ("sample_stars.csv", handle, "text/csv")},
            data={"model": "simulated"},  # sample_stars.csv is 1500-point simulated data
        )

    for row in response.json()["results"]:
        assert 0.0 <= row["probability"] <= 1.0
        assert row["verdict"] in ("Planet likely", "Borderline", "No planet")
        assert len(row["curve"]) == 1500


def test_verdict_matches_the_probability(client):
    """Check the 0.7 / 0.3 thresholds are applied correctly."""
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        response = client.post(
            "/api/predict-csv",
            files={"file": ("sample_stars.csv", handle, "text/csv")},
            data={"model": "simulated"},  # sample_stars.csv is 1500-point simulated data
        )

    for row in response.json()["results"]:
        probability = row["probability"]
        if probability >= 0.7:
            assert row["verdict"] == "Planet likely"
        elif probability >= 0.3:
            assert row["verdict"] == "Borderline"
        else:
            assert row["verdict"] == "No planet"
