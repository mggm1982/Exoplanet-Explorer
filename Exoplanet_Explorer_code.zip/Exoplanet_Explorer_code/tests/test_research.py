"""
Tests for the research package.

These are deliberately offline: they use synthetic signals with known
answers rather than hitting NASA's servers, so the suite runs fast and
still passes with no internet. The tests that genuinely need the network
are in test_real_data.py and skip themselves when it is unavailable.
"""

import numpy as np
import pytest

from research.bls import bls_search, fold
from research.detrend import METHODS, detrend, estimate_noise
from research.inject import inject, trapezoid_transit
from research.single_transit import find_single_transits
from research.vetting import build_features, expected_duration_hours, physical_rules
from research.wavelet import denoise, haar_forward, haar_inverse


# ----------------------------- wavelets ------------------------------

def test_haar_transform_round_trips_exactly():
    """Transforming and untransforming must give back the original."""
    signal = np.random.default_rng(0).normal(0, 1, 1024)
    smooth, details = haar_forward(signal, 4)
    assert np.allclose(haar_inverse(smooth, details), signal)


def test_denoise_keeps_length_and_reduces_noise():
    rng = np.random.default_rng(1)
    clean = np.zeros(1500)
    clean[600:700] = -1.0
    noisy = clean + rng.normal(0, 0.3, 1500)

    out = denoise(noisy)

    assert len(out) == 1500
    assert np.std(out - clean) < np.std(noisy - clean)


# ---------------------------- detrending -----------------------------

def test_every_method_flattens_a_trend():
    """After detrending, the curve should sit around zero."""
    t = np.arange(1500)
    flux = 1000 + 30 * np.sin(2 * np.pi * t / 700)

    for method in METHODS:
        if method == "none":
            continue  # "none" cannot remove a trend; that is the point of it
        flattened = detrend(flux, method)
        assert abs(np.median(flattened)) < 0.01, method


def test_detrending_preserves_a_short_transit():
    """A filter must not eat the very thing we are looking for."""
    rng = np.random.default_rng(2)
    t = np.arange(1500)
    flux = 1000 + 10 * np.sin(2 * np.pi * t / 600) + rng.normal(0, 2, 1500)
    flux[600:616] *= 0.99  # a 1% transit, 16 points long

    for method in ["median", "savgol"]:
        flattened = detrend(flux, method)
        recovered = -np.median(flattened[602:614])
        # Keep at least half the depth.
        assert recovered > 0.005, method


def test_unknown_method_is_rejected():
    with pytest.raises(ValueError):
        detrend(np.ones(200), "not-a-real-method")


def test_estimate_noise_is_about_right():
    rng = np.random.default_rng(3)
    noise = estimate_noise(rng.normal(0, 0.01, 5000))
    assert 0.008 < noise < 0.012


# ------------------------------ injection -----------------------------

def test_trapezoid_has_sloping_edges():
    """A real transit is not a box: it has ingress and egress."""
    t = np.arange(0, 10, 0.0005)
    signal = trapezoid_transit(t, period=5.0, t0=2.0, duration=0.2, depth=0.01)

    on_edge = signal[(signal < -1e-6) & (signal > -0.00999)]
    assert len(on_edge) > 50
    assert signal.min() == pytest.approx(-0.01, abs=1e-9)


def test_injection_multiplies_rather_than_adds():
    t = np.arange(0, 10, 0.01)
    flux = np.full(len(t), 2.0)
    out = inject(t, flux, period=5.0, t0=2.0, duration=0.2, depth=0.01)
    # A 1% transit on a flux of 2.0 removes 0.02, not 0.01.
    assert out.min() == pytest.approx(2.0 * 0.99)


# -------------------------------- BLS ---------------------------------

def test_bls_finds_a_known_period():
    rng = np.random.default_rng(4)
    n = 1500
    y = rng.normal(0, 0.001, n)
    for k in range(10):
        start = 50 + k * 180
        if start + 14 < n:
            y[start:start + 14] -= 0.004

    result = bls_search(y)

    assert abs(result["period"] - 180) / 180 < 0.05
    assert result["sde"] > 8


def test_bls_on_pure_noise_has_a_low_sde():
    """The threshold only means something if noise scores below it."""
    rng = np.random.default_rng(5)
    result = bls_search(rng.normal(0, 0.001, 1500))
    assert result["sde"] < 8


def test_bls_accepts_a_real_time_axis_with_gaps():
    """
    Real data is unevenly spaced. BLS must cope.

    A harmonic counts as a hit. Folding at half the true period still lines
    every transit up - they just land in alternate cycles - so BLS settling
    on P/2 is a real detection, not a miss. Astronomers treat it that way
    too, because the folded curve makes the true period obvious at a glance.
    """
    from research.experiment import period_matches

    rng = np.random.default_rng(6)
    times = np.sort(rng.choice(np.arange(0, 60, 0.02), size=2000, replace=False))
    y = rng.normal(0, 0.0005, len(times))

    phase = np.mod(times, 4.0)
    y[phase < 0.12] -= 0.005

    result = bls_search(y, times=times)

    assert period_matches(result["period"], 4.0), result["period"]
    assert result["sde"] > 8


def test_fold_returns_phase_in_range():
    y = np.zeros(500)
    phase, flux = fold(y, period=50.0)
    assert len(phase) == len(flux) == 500
    assert phase.min() >= -0.5 and phase.max() <= 0.5


# ----------------------------- single transit --------------------------

def _single_transit_curve(depth, seed=7, shape="flat"):
    rng = np.random.default_rng(seed)
    times = np.arange(0, 40, 1.0 / 48)          # 30-minute cadence
    flux = np.ones(len(times)) + rng.normal(0, 0.0002, len(times))
    middle = 20.0

    if shape == "flat":
        flux = inject(times, flux, period=1e6, t0=middle,
                      duration=8.0 / 24, depth=depth)
    else:  # a V-shaped grazing eclipse
        half = (8.0 / 24) / 2
        v = np.clip(1 - np.abs(times - middle) / half, 0, None)
        flux = flux * (1 - depth * v)

    return times, detrend(flux, "median"), middle


def test_duration_units_must_match_the_time_axis():
    """
    A regression test for a real bug. The templates are hours-converted-to-
    days, which is right when `times` is in days but nonsense when `times`
    is a row index: every template then comes out under one data point wide
    and nothing is ever found. Passing durations in the right units fixes it.
    """
    rng = np.random.default_rng(11)
    flux = 1.0 + rng.normal(0, 0.0003, 1200)
    flux[600:625] *= 0.997

    flattened = detrend(flux, "median")
    times = np.arange(len(flattened), dtype=float)

    # Wrong units (days-sized templates on a cadence axis): finds nothing.
    assert find_single_transits(times, flattened) == []

    # Right units (durations in data points): finds it.
    candidates = find_single_transits(
        times, flattened, durations=[4.0, 7.0, 11.0, 17.0, 25.0, 40.0, 60.0])
    assert len(candidates) >= 1
    assert abs(candidates[0]["time"] - 612) < 30


def test_finds_a_single_injected_transit():
    times, flattened, middle = _single_transit_curve(0.002)
    candidates = find_single_transits(times, flattened)

    assert len(candidates) >= 1
    best = candidates[0]
    assert abs(best["time"] - middle) < 0.2
    assert best["snr"] > 7


def test_finds_nothing_in_pure_noise():
    rng = np.random.default_rng(8)
    times = np.arange(0, 40, 1.0 / 48)
    flattened = detrend(1 + rng.normal(0, 0.0002, len(times)), "median")

    assert len(find_single_transits(times, flattened)) == 0


def test_flat_bottomed_transit_is_preferred_over_a_v():
    """
    The shape score must point the right way round: a real transit has a
    flat bottom, so the trapezoid should fit better and the score should be
    POSITIVE. Getting this backwards would reject every genuine planet.
    """
    times, flattened, _ = _single_transit_curve(0.004)
    best = find_single_transits(times, flattened)[0]

    assert best["shape_score"] > 0
    assert best["verdict"].startswith("Promising")


def test_v_shaped_eclipse_is_flagged():
    """A grazing binary comes to a point, and should be caught as such."""
    times, flattened, _ = _single_transit_curve(0.004, shape="v")
    candidates = find_single_transits(times, flattened)

    assert len(candidates) >= 1
    best = candidates[0]
    assert best["shape_score"] < 0
    assert len(best["caveats"]) > 0


def test_shape_is_not_used_when_the_event_is_too_faint():
    """
    Below about S/N 15 a V and a flat bottom are not separable. The code
    must say so instead of pretending to know.
    """
    from research.single_transit import MIN_SNR_FOR_SHAPE

    times, flattened, _ = _single_transit_curve(0.0008, shape="v")
    candidates = find_single_transits(times, flattened)

    if not candidates:
        pytest.skip("nothing detected at this depth, which is also fine")

    best = candidates[0]
    if best["snr"] < MIN_SNR_FOR_SHAPE:
        assert any("too faint" in c.lower() for c in best["caveats"])


def test_very_deep_event_is_not_called_a_planet():
    times, flattened, _ = _single_transit_curve(0.12)
    best = find_single_transits(times, flattened)[0]

    assert not best["verdict"].startswith("Promising")
    assert any("planet" in c for c in best["caveats"])


# -------------------------------- vetting ------------------------------

def test_expected_duration_grows_with_period():
    assert expected_duration_hours(365.25) > expected_duration_hours(3.0)


def test_rules_reject_a_star_sized_object():
    reasons, verdict = physical_rules({
        "koi_ror": 0.6, "koi_prad": 80.0, "koi_model_snr": 500.0,
        "koi_period": 3.0, "koi_duration": 3.0,
    })
    assert verdict == "reject"
    assert len(reasons) >= 1


def test_rules_pass_a_plausible_planet():
    reasons, verdict = physical_rules({
        "koi_ror": 0.02, "koi_prad": 2.1, "koi_model_snr": 40.0,
        "koi_period": 9.5, "koi_duration": 3.0,
    })
    assert verdict == "pass"
    assert reasons == []


def test_weak_signal_is_uncertain_not_rejected():
    """A faint signal is unproven, which is different from being wrong."""
    _, verdict = physical_rules({
        "koi_ror": 0.02, "koi_prad": 2.0, "koi_model_snr": 3.0,
        "koi_period": 9.5, "koi_duration": 3.0,
    })
    assert verdict == "uncertain"


def test_feature_builder_never_sees_the_answer():
    """
    The koi_fpflag_* columns are the Kepler team's own verdict. If they
    ever reached the classifier the scores would be meaningless.
    """
    import pandas as pd

    from research.vetting import FEATURE_NAMES

    table = pd.DataFrame({
        "koi_period": [10.0], "koi_depth": [500.0], "koi_duration": [3.0],
        "koi_prad": [2.0], "koi_ror": [0.02], "koi_model_snr": [30.0],
        "koi_impact": [0.3],
        "koi_fpflag_nt": [1], "koi_fpflag_ss": [1],
        "koi_fpflag_co": [1], "koi_fpflag_ec": [1],
    })

    features = build_features(table)

    assert features.shape == (1, len(FEATURE_NAMES))
    assert not any("fpflag" in name for name in FEATURE_NAMES)
