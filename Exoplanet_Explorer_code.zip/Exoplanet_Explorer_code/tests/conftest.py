"""
Shared test setup.

Adds the project folder to the import path so the tests can import app.py,
detector/, research/ and so on, and builds one FastAPI test client that every test
can share (the model is then only loaded once for the whole test run).
"""

import os
import sys

import pytest
from fastapi.testclient import TestClient

# The folder above tests/ is the project folder.
PROJECT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, PROJECT_DIR)

from app import app  # noqa: E402  (import must come after the path change)


@pytest.fixture(scope="session")
def client():
    """A fake browser that can call the endpoints without a real server."""
    with TestClient(app) as test_client:
        yield test_client


def project_file(name):
    """Full path to a file in the project folder, e.g. data/simulated/sample_stars.csv."""
    return os.path.join(PROJECT_DIR, name)
