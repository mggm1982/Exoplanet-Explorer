"""
Tests for the molecular composition report (research/composition.py and
the /api/composition endpoints). Synthetic spectra with known answers.
"""

import numpy as np

from research.composition import analyse_spectrum


def make_spectrum(bumps=(), noise=0.002, seed=0):
    """A flat 1.2% spectrum from 0.5 to 5 um with optional Gaussian bumps."""
    rng = np.random.default_rng(seed)
    wavelength = np.linspace(0.5, 5.0, 300)
    depth = 1.2 + rng.normal(0, noise, wavelength.size)
    for centre, height in bumps:
        depth += height * np.exp(-0.5 * ((wavelength - centre) / 0.06) ** 2)
    return wavelength, depth


def verdicts(report):
    return {m["molecule"]: m["verdict"] for m in report["molecules"]}


def test_flat_spectrum_has_no_strong_features():
    report = analyse_spectrum(*make_spectrum())
    assert "Strong feature" not in verdicts(report).values()


def test_co2_bump_is_found_and_only_co2_is_strong():
    report = analyse_spectrum(*make_spectrum(bumps=[(4.3, 0.05)]))
    found = verdicts(report)
    assert found["CO2"] == "Strong feature"
    assert found["H2O"] != "Strong feature"
    assert found["CH4"] != "Strong feature"


def test_band_outside_the_range_is_not_covered():
    wavelength = np.linspace(1.1, 1.7, 40)
    depth = 1.2 + 0.03 * np.exp(-0.5 * ((wavelength - 1.4) / 0.05) ** 2)
    found = verdicts(analyse_spectrum(wavelength, depth))
    assert found["CO2"] == "Not covered"
    assert found["Na"] == "Not covered"


def test_nanometres_are_converted():
    wavelength, depth = make_spectrum(bumps=[(4.3, 0.05)])
    report = analyse_spectrum(wavelength * 1000, depth)
    assert report["range_um"][1] < 10
    assert verdicts(report)["CO2"] == "Strong feature"


def test_uncertainty_column_is_used():
    wavelength, depth = make_spectrum(bumps=[(4.3, 0.05)])
    # Huge error bars: the same bump is no longer significant.
    report = analyse_spectrum(wavelength, depth, np.full(depth.size, 1.0))
    assert report["noise_source"] == "uncertainty column in the file"
    assert verdicts(report)["CO2"] == "No feature"


def test_example_endpoints(client):
    listing = client.get("/api/composition/examples").json()
    assert len(listing["examples"]) == 4
    body = client.get("/api/composition/example/jwst_H2O_CO2").json()
    assert verdicts(body)["CO2"] == "Strong feature"
    assert "SIMULATED" in body["data_warning"]
    assert client.get("/api/composition/example/../../app.py").status_code == 404


def test_upload_endpoint_rejects_one_column(client):
    csv = "wavelength\n" + "\n".join(str(x) for x in range(10))
    response = client.post("/api/composition",
                           files={"file": ("bad.csv", csv, "text/csv")})
    assert response.status_code == 400
