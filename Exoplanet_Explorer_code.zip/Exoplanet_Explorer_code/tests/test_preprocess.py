"""Tests for the cleaning steps in preprocess.py (no model needed)."""

import numpy as np

from conftest import PROJECT_DIR  # noqa: F401  (makes sure the path is set up)
from detector.preprocess import preprocess_flux, POINTS_PER_STAR, CLIP_LOW, CLIP_HIGH


def test_output_shape_is_always_1500():
    """Whatever length goes in, (n, 1500, 1) comes out."""
    for length in [800, 1500, 2400]:
        flux = np.random.normal(100.0, 1.0, size=(3, length))
        result = preprocess_flux(flux)
        assert result.shape == (3, POINTS_PER_STAR, 1)


def test_nan_values_are_filled():
    """No NaN should survive the cleaning."""
    flux = np.random.normal(100.0, 1.0, size=(2, 1500))
    flux[0, 10] = np.nan
    flux[1, 500] = np.nan

    result = preprocess_flux(flux)

    assert np.isfinite(result).all()


def test_values_are_clipped():
    """A huge spike must be cut down to the clip range."""
    flux = np.random.normal(100.0, 1.0, size=(1, 1500))
    flux[0, 700] = 100000.0

    result = preprocess_flux(flux)

    assert result.min() >= CLIP_LOW
    assert result.max() <= CLIP_HIGH


def test_short_rows_are_edge_padded():
    """A short row is padded by repeating its last value, not with zeros."""
    flux = np.ones((1, 1000)) * 50.0
    # Make the end distinctive so we can check what was copied.
    flux[0, -1] = 50.0

    result = preprocess_flux(flux).reshape(1, POINTS_PER_STAR)

    # The padded part at the end should all be the same value.
    padded_part = result[0, 1000:]
    assert np.allclose(padded_part, padded_part[0])


def test_a_single_1d_star_is_accepted():
    """Passing one star as a flat array should still work."""
    result = preprocess_flux(np.random.normal(100.0, 1.0, size=1500))
    assert result.shape == (1, POINTS_PER_STAR, 1)


def test_flat_star_does_not_crash():
    """A perfectly flat row has zero standard deviation. It must not divide by zero."""
    result = preprocess_flux(np.ones((1, 1500)) * 42.0)
    assert np.isfinite(result).all()
