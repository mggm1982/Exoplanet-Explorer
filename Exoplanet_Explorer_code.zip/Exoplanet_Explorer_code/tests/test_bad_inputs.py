"""
Tests for bad uploads.

The rule is always the same: a clear message in an "error" field,
and never a crash or a stack trace.
"""

import io


def assert_friendly_error(response):
    """Every rejection must be a readable sentence, not a traceback."""
    assert response.status_code in (400, 413, 422, 500, 503)

    body = response.json()
    assert "error" in body, "no 'error' field in: " + response.text

    message = body["error"]
    assert len(message) > 10
    assert "Traceback" not in message


# ----------------------------- CSV endpoint -----------------------------

def test_empty_csv_file(client):
    response = client.post(
        "/api/predict-csv",
        files={"file": ("empty.csv", io.BytesIO(b""), "text/csv")},
    )
    assert_friendly_error(response)


def test_txt_file_sent_to_csv_endpoint(client):
    response = client.post(
        "/api/predict-csv",
        files={"file": ("notes.txt", io.BytesIO(b"hello world"), "text/plain")},
    )
    assert_friendly_error(response)


def test_csv_with_no_numeric_columns(client):
    content = b"name,colour\nVega,blue\nSirius,white\n"
    response = client.post(
        "/api/predict-csv",
        files={"file": ("words.csv", io.BytesIO(content), "text/csv")},
    )
    assert_friendly_error(response)


def test_csv_with_a_header_but_no_rows(client):
    content = b"FLUX.1,FLUX.2,FLUX.3\n"
    response = client.post(
        "/api/predict-csv",
        files={"file": ("headeronly.csv", io.BytesIO(content), "text/csv")},
    )
    assert_friendly_error(response)


def test_csv_with_too_few_columns(client):
    content = b"FLUX.1,FLUX.2\n100,101\n102,103\n"
    response = client.post(
        "/api/predict-csv",
        files={"file": ("tiny.csv", io.BytesIO(content), "text/csv")},
    )
    assert_friendly_error(response)


def test_garbled_bytes_sent_as_csv(client):
    content = bytes([0x00, 0xFF, 0xFE, 0x01] * 100)
    response = client.post(
        "/api/predict-csv",
        files={"file": ("broken.csv", io.BytesIO(content), "text/csv")},
    )
    assert_friendly_error(response)


# ------------------------------ the page --------------------------------

def test_the_home_page_loads(client):
    response = client.get("/")
    assert response.status_code == 200
    assert "Exoplanet Explorer" in response.text
    # The warning must be on the page.
    assert "Screening tool only" in response.text
