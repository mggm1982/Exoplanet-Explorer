"""
Tests for the light-curve model trained on REAL Kepler/K2 data.

These tests are SKIPPED automatically when the files they need are missing:
  * exoplanet_model_real.keras  (made by train_real_lightcurve.py)
  * data/real/exoTest.csv           (Kaggle "Kepler Labelled Time Series Data")
So the test suite still passes on a computer that only has the simulated model.
"""

import io
import os

import numpy as np
import pandas as pd
import pytest

from conftest import project_file
from detector.preprocess import preprocess_flux

REAL_MODEL = project_file(os.path.join("models", "exoplanet_model_real.keras"))
EXO_TEST = project_file(os.path.join("data", "real", "exoTest.csv"))

needs_real_model = pytest.mark.skipif(
    not os.path.exists(REAL_MODEL),
    reason="exoplanet_model_real.keras not found (run python -m scripts.train_real_lightcurve)",
)
needs_kepler_data = pytest.mark.skipif(
    not os.path.exists(EXO_TEST),
    reason="data/exoTest.csv not found (Kaggle Kepler dataset)",
)


def post_csv(client, csv_bytes, name="stars.csv", model=None):
    """Send CSV bytes to the CSV endpoint, optionally choosing a model."""
    data = {} if model is None else {"model": model}
    return client.post(
        "/api/predict-csv",
        files={"file": (name, io.BytesIO(csv_bytes), "text/csv")},
        data=data,
    )


# ------------------------------------------------------------------------
# No files needed: the preprocessing length can be changed.
# ------------------------------------------------------------------------

def test_preprocess_accepts_a_target_length():
    """Same cleaning steps, different final length (used by the real model)."""
    flux = np.random.normal(100.0, 1.0, size=(3, 3197))
    assert preprocess_flux(flux, target_length=3197).shape == (3, 3197, 1)
    assert preprocess_flux(flux).shape == (3, 1500, 1)  # default unchanged

    # Steps a-d do not depend on the length: the first 1500 points match.
    long_version = preprocess_flux(flux, target_length=3197)[:, :1500, 0]
    short_version = preprocess_flux(flux, target_length=1500)[:, :, 0]
    assert np.allclose(long_version, short_version)


# ------------------------------------------------------------------------
# Need the real model.
# ------------------------------------------------------------------------

@needs_real_model
def test_health_lists_both_models_and_defaults_to_real(client):
    body = client.get("/health").json()
    assert "real" in body["lightcurve_models"]
    assert "simulated" in body["lightcurve_models"]
    assert body["default_lightcurve_model"] == "real"


@needs_real_model
def test_real_model_reads_its_length_from_the_model(client):
    """sample_stars.csv has 1500 points; the real model wants 3197, so it is edge-padded."""
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        response = post_csv(client, handle.read(), "sample_stars.csv", model="real")
    assert response.status_code == 200
    body = response.json()
    assert body["model"] == "real"
    assert body["model_trained_on"] == "real Kepler/K2 data (Kaggle)"
    assert body["model_length"] == 3197
    assert all(len(row["curve"]) == 3197 for row in body["results"])


@needs_real_model
def test_no_model_field_means_the_real_model(client):
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        body = post_csv(client, handle.read(), "sample_stars.csv").json()
    assert body["model"] == "real"


def test_simulated_model_label(client):
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        body = post_csv(client, handle.read(), "sample_stars.csv", model="simulated").json()
    assert body["model"] == "simulated"
    assert body["model_trained_on"] == "simulated data"
    assert body["model_length"] == 1500


def test_unknown_model_name_gives_a_friendly_error(client):
    with open(project_file(os.path.join("data", "simulated", "sample_stars.csv")), "rb") as handle:
        response = post_csv(client, handle.read(), "sample_stars.csv", model="banana")
    assert response.status_code == 400
    assert "error" in response.json()


# ------------------------------------------------------------------------
# Need the real model AND the Kaggle data.
# ------------------------------------------------------------------------

@needs_real_model
@needs_kepler_data
def test_real_model_on_kepler_test_file(client):
    """
    Upload the whole real test file (570 stars, 5 planets) through the app.
    We check ranking quality (ROC AUC), not exact probabilities: on average
    planets must score higher than non-planets. The training report measured
    0.93; we only require > 0.8 so the test is not fragile.
    """
    from sklearn.metrics import roc_auc_score

    with open(EXO_TEST, "rb") as handle:
        response = post_csv(client, handle.read(), "exoTest.csv", model="real")
    assert response.status_code == 200
    body = response.json()
    assert body["n_stars"] == 570
    assert body["n_flux_columns"] == 3197

    truth = [1 if row["true_label"] == 2 else 0 for row in body["results"]]
    scores = [row["probability"] for row in body["results"]]
    assert sum(truth) == 5
    assert roc_auc_score(truth, scores) > 0.8


@needs_real_model
@needs_kepler_data
def test_app_and_training_preprocessing_agree():
    """The app and train_real_lightcurve.py must produce identical model inputs."""
    from scripts import train_real_lightcurve as training

    flux, _ = training.load_kepler_csv(EXO_TEST)
    from_training = preprocess_flux(flux, target_length=flux.shape[1])

    # What the app does: read the CSV with pandas, drop LABEL, keep numbers.
    table = pd.read_csv(EXO_TEST).drop(columns=["LABEL"]).select_dtypes(include="number")
    from_app = preprocess_flux(table.to_numpy(dtype=float), target_length=3197)
    assert np.array_equal(from_training, from_app)
