"""
Tests for the research endpoints.

The data-source and Idea 1/2 endpoints read cached results, so they work
offline once `python -m research.run_all` has been run at least once.
Tests skip themselves rather than fail when the cache is missing.
"""

import io
import os

import numpy as np
import pytest

from conftest import PROJECT_DIR

RESULTS_DIR = os.path.join(PROJECT_DIR, "data", "cache", "results")


def _needs(name):
    if not os.path.exists(os.path.join(RESULTS_DIR, name + ".json")):
        pytest.skip("run `python -m research.run_all` to generate " + name)


def test_sources_endpoint_names_real_and_simulated_data(client):
    response = client.get("/api/research/sources")
    assert response.status_code == 200

    body = response.json()
    assert len(body["real_sources"]) >= 3
    # Every real source must carry a citation and an endpoint.
    for source in body["real_sources"]:
        assert source["citation"]
        assert source["endpoint"].startswith("https://")

    # The simulated files must be labelled as simulated, not quietly listed.
    for source in body["simulated_sources"]:
        assert "SIMULATED" in source["origin"].upper()

    assert "simulated" in body["warning"].lower()


def test_idea1_returns_a_sensitivity_curve(client):
    _needs("idea1")
    response = client.get("/api/research/idea1")
    assert response.status_code == 200

    body = response.json()
    assert "methods" in body
    for name, method in body["methods"].items():
        assert len(method["by_depth"]) >= 3
        for entry in method["by_depth"]:
            assert 0.0 <= entry["recovery_rate"] <= 1.0
        assert 0.0 <= method["false_alarm"]["false_alarm_rate"] <= 1.0

    # It must say which real star it used.
    assert body["host_provenance"]["kic"]
    assert "REAL" in body["host_provenance"]["note"].upper()


def test_idea1_recovery_falls_as_transits_get_shallower(client):
    """
    Physics check on our own experiment. Deeper transits must be easier.
    The paired design makes this hold; without it the curve jumps about and
    the experiment is not measuring what it claims to.
    """
    _needs("idea1")
    body = client.get("/api/research/idea1").json()

    for name, method in body["methods"].items():
        rates = [entry["recovery_rate"] for entry in method["by_depth"]]
        # depths are listed deepest first, so recovery should not increase
        assert rates[0] >= rates[-1], name


def test_idea2_beats_the_rules_on_false_positives(client):
    _needs("idea2")
    response = client.get("/api/research/idea2")
    assert response.status_code == 200

    body = response.json()
    results = body["results"]

    for name in ["rules_only", "model_only", "two_stage", "official_kepler_flags"]:
        assert name in results
        assert 0.0 <= results[name]["precision"] <= 1.0
        assert 0.0 <= results[name]["recall"] <= 1.0

    # The learned model should reject more false positives than blunt rules.
    assert (results["two_stage"]["fp_rejection_rate"]
            > results["rules_only"]["fp_rejection_rate"])

    # Trained and tested on different stars.
    assert body["dataset"]["n_test_stars"] > 0
    assert "by star" in body["dataset"]["split"]


def test_idea2_never_uses_the_answer_as_a_feature(client):
    """The Kepler pipeline's own verdict flags must not be model inputs."""
    _needs("idea2")
    body = client.get("/api/research/idea2").json()
    for weight in body["feature_weights"]:
        assert "fpflag" not in weight["feature"]


def _single_transit_csv():
    """A CSV holding one light curve with a single injected transit."""
    rng = np.random.default_rng(11)
    flux = 1.0 + rng.normal(0, 0.0003, 1200)
    flux[600:625] *= 0.997            # one transit, 25 points long

    header = ",".join("FLUX.%d" % (i + 1) for i in range(len(flux)))
    row = ",".join("%.6f" % v for v in flux)
    return (header + "\n" + row + "\n").encode()


def test_idea3_finds_an_injected_single_transit(client):
    response = client.post(
        "/api/research/idea3",
        files={"file": ("one_dip.csv", io.BytesIO(_single_transit_csv()), "text/csv")},
        data={"detrend_method": "median"},
    )
    assert response.status_code == 200, response.text

    body = response.json()
    assert body["n_candidates"] >= 1

    best = body["candidates"][0]
    # The transit was centred on point 612.
    assert abs(best["time"] - 612) < 30
    assert best["snr"] > 7
    assert "Period unknown" in best["period_note"]
    # Durations must be in data points for a CSV, not hours.
    assert body["duration_units"] == "data points"
    assert 4 <= best["duration"] <= 60


def test_idea3_rejects_a_non_csv(client):
    response = client.post(
        "/api/research/idea3",
        files={"file": ("notes.txt", io.BytesIO(b"hello"), "text/plain")},
        data={"detrend_method": "median"},
    )
    assert response.status_code == 400
    assert "error" in response.json()


def test_idea3_rejects_an_unknown_detrending_method(client):
    response = client.post(
        "/api/research/idea3",
        files={"file": ("x.csv", io.BytesIO(_single_transit_csv()), "text/csv")},
        data={"detrend_method": "magic"},
    )
    assert response.status_code == 400
    assert "error" in response.json()


def test_idea3_rejects_a_too_short_curve(client):
    content = b"a,b,c\n1,2,3\n"
    response = client.post(
        "/api/research/idea3",
        files={"file": ("tiny.csv", io.BytesIO(content), "text/csv")},
        data={"detrend_method": "median"},
    )
    assert response.status_code == 400
    assert "error" in response.json()
