"""
run_all.py
----------
Runs the three studies and saves their results to data/cache/results/.

The Idea 1 experiment takes a few minutes, which is far too long for a web
request to wait, so the web app serves these saved results instead of
recomputing them. Re-run this script whenever you change a method:

    python -m research.run_all

Every result file records the settings it was produced with, so a number in
the web app can always be traced back to the run that made it.
"""

import json
import os
import time

from research.datasources import fetch_koi_table
from research.experiment import check_host_is_quiet, run_comparison
from research.kepler_data import get_light_curve
from research.pipeline import run_idea2

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RESULTS_DIR = os.path.join(HERE, "data", "cache", "results")

# The host star for the injection-recovery experiment. KIC 8425723 is a
# real Kepler star that is NOT a Kepler Object of Interest, so it has no
# known transit of its own to interfere with the planets we inject.
DEFAULT_HOST_KIC = 8425723


def save(name, payload):
    os.makedirs(RESULTS_DIR, exist_ok=True)
    path = os.path.join(RESULTS_DIR, name + ".json")
    with open(path, "w") as handle:
        json.dump(payload, handle, indent=1)
    print("saved", path)
    return path


def run_idea1(kic=DEFAULT_HOST_KIC, n_trials=25, n_null_trials=25,
              n_periods=500, seed=7):
    """Idea 1: compare noise-removal methods by injection and recovery."""
    times, flux, provenance = get_light_curve(kic, max_quarters=2)
    quiet = check_host_is_quiet(times, flux)

    started = time.time()
    result = run_comparison(times, flux, n_trials=n_trials,
                            n_null_trials=n_null_trials,
                            n_periods=n_periods, seed=seed)
    result["host_provenance"] = provenance
    result["host_quiet_check"] = quiet
    result["runtime_seconds"] = round(time.time() - started, 1)
    result["generated_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    return result


def main():
    print("Idea 1: injection-recovery on a real Kepler light curve ...")
    save("idea1", run_idea1())

    print("Idea 2: false-positive rejection on the real Kepler KOI table ...")
    idea2 = run_idea2(fetch_koi_table())
    idea2["generated_utc"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    save("idea2", idea2)

    print("done")


if __name__ == "__main__":
    main()
