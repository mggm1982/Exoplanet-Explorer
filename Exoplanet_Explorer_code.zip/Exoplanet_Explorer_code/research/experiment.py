"""
experiment.py
-------------
IDEA 1: which noise-removal method finds the shallowest transits, without
inventing transits that are not there?

The experiment has two halves, and you need both. A method that flags
everything will "recover" every injected planet and look brilliant, until
you check how often it fires on pure noise.

  RECOVERY     Inject a transit of known depth into a real light curve, run
               the method, and see whether the search finds it. Repeat at
               several depths to build a sensitivity curve.

  FALSE ALARM  Destroy any real signal by shuffling the data, run exactly
               the same method with the same threshold, and count how often
               it claims a detection anyway.

The honest comparison is at a *matched false-alarm rate*: whichever method
recovers more planets while firing on noise equally often is the better one.
"""

import numpy as np

from research.bls import bls_search
from research.detrend import detrend, estimate_noise, METHODS
from research.inject import inject, random_transit_parameters

# A detection counts as real if the BLS peak stands this far above the rest
# of its own power spectrum.
DEFAULT_SDE_THRESHOLD = 8.0

# How close the recovered period must be to the injected one, as a fraction.
PERIOD_TOLERANCE = 0.02

# A transit search often locks onto a multiple or a fraction of the true
# period. Astronomers count these as recoveries, because a human looking at
# the folded light curve would immediately spot the right answer.
ALLOWED_HARMONICS = [1.0, 2.0, 0.5, 3.0, 1.0 / 3.0]


def period_matches(found, true_period):
    """Is the found period the true one, or one of its usual harmonics?"""
    for harmonic in ALLOWED_HARMONICS:
        expected = true_period * harmonic
        if abs(found - expected) / expected < PERIOD_TOLERANCE:
            return True
    return False


def check_host_is_quiet(times, flux, n_periods=600):
    """
    Before injecting anything, check the host star has no obvious transit of
    its own. A strong existing signal would compete with the injected one
    and make every method look worse than it really is.
    """
    flattened = detrend(flux, "median")
    result = bls_search(flattened, times=times, n_periods=n_periods)
    return {
        "sde": round(result["sde"], 2),
        "period": round(result["period"], 5),
        "depth": round(result["depth"], 6),
        "is_quiet": bool(result["sde"] < DEFAULT_SDE_THRESHOLD),
    }


def run_single_trial(times, flux, method, depth, rng, n_periods, sde_threshold,
                     parameters=None):
    """
    Inject one planet, run one method, report whether it was found.

    If `parameters` is given we use that exact orbit instead of drawing a
    new one. That is what makes the comparison paired - see run_comparison.
    """
    if parameters is None:
        parameters = random_transit_parameters(times, depth, rng)
    else:
        # Reuse the orbit but set the depth we are testing at.
        parameters = dict(parameters)
        parameters["depth"] = float(depth)

    injected_flux = inject(times, flux,
                           parameters["period"], parameters["t0"],
                           parameters["duration"], parameters["depth"])

    flattened = detrend(injected_flux, method)
    result = bls_search(flattened, times=times, n_periods=n_periods)

    found = (result["sde"] >= sde_threshold
             and period_matches(result["period"], parameters["period"]))

    return {
        "recovered": bool(found),
        "sde": float(result["sde"]),
        "true_period": parameters["period"],
        "found_period": float(result["period"]),
        # How much of the injected depth survived the filter. Measured at
        # the ephemeris we injected, NOT at the one BLS found, so that it
        # isolates what detrending did from what the search did.
        "depth_preserved": measure_depth_preserved(times, flattened, parameters),
    }


def measure_depth_preserved(times, flattened, parameters):
    """
    What fraction of an injected transit is still present after detrending?

    We know exactly where we put the transit, so we can compare the points
    inside it with the points outside it. 1.0 means the filter left the
    transit alone; 0.5 means it swallowed half of it.

    This matters because a filter that removes the trend by also removing
    the transit will quietly destroy the very thing you are looking for.
    """
    period = parameters["period"]
    t0 = parameters["t0"]
    duration = parameters["duration"]
    depth = parameters["depth"]

    if depth <= 0:
        return 0.0

    # Distance from the nearest transit centre.
    phase = np.mod(times - t0 + period / 2.0, period) - period / 2.0
    distance = np.abs(phase)

    # Use the flat middle of the transit only, avoiding the sloping edges.
    in_transit = distance < (duration / 2.0) * 0.6
    # Compare against points well clear of any transit.
    out_of_transit = distance > duration

    if in_transit.sum() < 3 or out_of_transit.sum() < 10:
        return float("nan")

    measured = float(np.mean(flattened[out_of_transit])
                     - np.mean(flattened[in_transit]))

    return measured / depth


def run_false_alarm_trials(times, flux, method, rng, n_trials, n_periods,
                           sde_threshold):
    """
    How often does this method claim a detection when nothing is there?

    We shuffle the flux values, which keeps the noise level exactly the same
    but destroys any coherent signal, then run the identical search.
    """
    false_alarms = 0
    sde_values = []

    for _ in range(n_trials):
        shuffled = rng.permutation(flux)
        flattened = detrend(shuffled, method)
        result = bls_search(flattened, times=times, n_periods=n_periods)

        sde_values.append(float(result["sde"]))
        if result["sde"] >= sde_threshold:
            false_alarms += 1

    return {
        "false_alarm_rate": false_alarms / n_trials if n_trials else 0.0,
        "median_null_sde": round(float(np.median(sde_values)), 2) if sde_values else 0.0,
        "max_null_sde": round(float(np.max(sde_values)), 2) if sde_values else 0.0,
        "n_trials": n_trials,
    }


def run_comparison(times, flux, depths=None, methods=None, n_trials=5,
                   n_null_trials=5, n_periods=600,
                   sde_threshold=DEFAULT_SDE_THRESHOLD, seed=0):
    """
    The full Idea 1 experiment.

    Input:  times, flux - a REAL light curve to use as the host
            depths      - transit depths to test, as fractions (0.001 = 0.1%)
    Output: a dictionary with, for each method, the recovery rate at each
            depth plus its false-alarm rate.
    """
    if depths is None:
        # 0.1% is a small Neptune; 0.0084% (84 ppm) is Earth across the Sun.
        # We go down to 0.003% so the experiment actually reaches the limit
        # instead of recovering everything.
        depths = [0.001, 0.0005, 0.0002, 0.0001, 0.00005, 0.00003]

    if methods is None:
        methods = list(METHODS)

    rng = np.random.default_rng(seed)

    flux = np.asarray(flux, dtype=np.float64)
    baseline_noise = estimate_noise(detrend(flux, "median"))

    # Draw the orbits ONCE and reuse them for every depth and every method.
    #
    # This is a paired experiment. If each cell drew its own random orbits,
    # a method could look better simply because it happened to be handed
    # easier periods. Reusing the same orbits everywhere removes that luck
    # entirely, so a difference between two methods is a real difference.
    # It also makes the recovery curve fall smoothly as depth decreases,
    # instead of jumping around.
    orbits = [random_transit_parameters(times, 1.0, rng) for _ in range(n_trials)]

    results = {}

    for method in methods:
        per_depth = []

        for depth in depths:
            trials = [
                run_single_trial(times, flux, method, depth, rng,
                                 n_periods, sde_threshold, parameters=orbit)
                for orbit in orbits
            ]

            recovered = sum(1 for t in trials if t["recovered"])
            per_depth.append({
                "depth": depth,
                "depth_percent": round(depth * 100, 4),
                "recovery_rate": recovered / n_trials,
                "n_trials": n_trials,
                "median_sde": round(float(np.median([t["sde"] for t in trials])), 2),
                "median_depth_preserved": _safe_median(
                    [t["depth_preserved"] for t in trials]),
            })

        false_alarm = run_false_alarm_trials(times, flux, method, rng,
                                             n_null_trials, n_periods,
                                             sde_threshold)

        results[method] = {
            "by_depth": per_depth,
            "false_alarm": false_alarm,
            "sensitivity_limit_percent": _sensitivity_limit(per_depth),
        }

    return {
        "methods": results,
        "settings": {
            "depths": depths,
            "n_trials_per_depth": n_trials,
            "n_null_trials": n_null_trials,
            "sde_threshold": sde_threshold,
            "n_periods_searched": n_periods,
            "period_tolerance": PERIOD_TOLERANCE,
        },
        "orbits": [
            {"period_days": round(o["period"], 4),
             "duration_hours": round(o["duration"] * 24, 3)}
            for o in orbits
        ],
        "host": {
            "n_points": int(len(times)),
            "baseline_days": round(float(np.max(times) - np.min(times)), 3),
            "noise_percent": round(baseline_noise * 100, 5),
        },
    }


def _safe_median(values):
    """Median that ignores trials where the measurement was not possible."""
    usable = [v for v in values if np.isfinite(v)]
    if not usable:
        return None
    return round(float(np.median(usable)), 3)


def _sensitivity_limit(per_depth):
    """
    The shallowest tested depth recovered at least half the time.
    This single number is the fairest one-line summary of a method.
    """
    best = None
    for entry in per_depth:
        if entry["recovery_rate"] >= 0.5:
            if best is None or entry["depth"] < best:
                best = entry["depth"]
    return round(best * 100, 4) if best is not None else None
