"""
research/
---------
The three research directions for this project, kept separate from the
main app so each one can be read, tested and written up on its own.

  detrend.py        Idea 1 - the noise-removal methods being compared
  wavelet.py        Idea 1 - a small hand-written Haar wavelet denoiser
  bls.py            Box Least Squares: the transit search used by Ideas 1-3
  inject.py         Idea 1 - planting fake transits of known depth
  experiment.py     Idea 1 - the injection-recovery experiment
  vetting.py        Idea 2 - the checks that catch false positives
  pipeline.py       Idea 2 - the two-stage detect-then-classify system
  single_transit.py Idea 3 - finding and ranking lone transits

Nothing here needs a package beyond numpy and scipy.
"""
