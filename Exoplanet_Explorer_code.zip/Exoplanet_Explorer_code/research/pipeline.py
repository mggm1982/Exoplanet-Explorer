"""
pipeline.py
-----------
IDEA 2: the two-stage false-positive rejection system.

  STAGE 1  DETECT.  Find transit-like signals. On a light curve this is the
           BLS search in bls.py. On the Kepler KOI table the detection has
           already been done for us by NASA's pipeline, which is why that
           table is such a good place to study stage 2 on its own.

  STAGE 2  CLASSIFY.  Decide whether each signal is a planet, a false
           positive, or too uncertain to call. This file does that two ways
           and then compares them:

             a) hand-written physical rules (vetting.physical_rules)
             b) a logistic regression trained on real labelled KOIs

           and then combines them, because they fail differently: the rules
           are blunt but never fooled by anything unphysical, the learned
           model picks up patterns nobody wrote down.

RESEARCH QUESTION
  Can we reject false positives while keeping genuine planets? The number
  that matters is recall on CONFIRMED planets - how many real planets
  survive - at a given false-positive rejection rate. Throwing away
  real planets to look precise is not progress.

NO LEAKAGE
  The koi_fpflag_* columns are the Kepler team's own verdict. They are
  never given to the classifier. They are used only as a reference point,
  to see how close an independent system can get to the official one.

The logistic regression is written out by hand in numpy. It is about thirty
lines, it is easy to read, and it keeps the project free of scikit-learn.
"""

import numpy as np

from research.vetting import FEATURE_NAMES, build_features, physical_rules


class LogisticRegression:
    """
    Plain logistic regression, fitted by gradient descent.

    It predicts the probability that a signal is a real planet. "Logistic"
    just means we squash a weighted sum of the features through a curve
    that turns any number into a probability between 0 and 1.
    """

    def __init__(self, learning_rate=0.5, n_steps=4000, l2_penalty=0.01):
        self.learning_rate = learning_rate
        self.n_steps = n_steps
        # The L2 penalty discourages huge weights, which stops the model
        # leaning its whole decision on one feature.
        self.l2_penalty = l2_penalty

        self.weights = None
        self.bias = 0.0
        # Feature scaling, remembered from training and reapplied later.
        self.means = None
        self.scales = None

    def _standardise(self, X):
        """Put every feature on the same scale so one cannot dominate."""
        return (X - self.means) / self.scales

    def fit(self, X, y):
        X = np.asarray(X, dtype=np.float64)
        y = np.asarray(y, dtype=np.float64)

        self.means = X.mean(axis=0)
        self.scales = X.std(axis=0)
        # A constant feature would give divide-by-zero.
        self.scales[self.scales < 1e-12] = 1.0

        Xs = self._standardise(X)
        n_samples, n_features = Xs.shape

        self.weights = np.zeros(n_features)
        self.bias = 0.0

        for _ in range(self.n_steps):
            predictions = self._sigmoid(Xs @ self.weights + self.bias)
            error = predictions - y

            # Gradient of the average cross-entropy loss, plus the penalty.
            gradient_w = (Xs.T @ error) / n_samples + self.l2_penalty * self.weights
            gradient_b = float(np.mean(error))

            self.weights -= self.learning_rate * gradient_w
            self.bias -= self.learning_rate * gradient_b

        return self

    @staticmethod
    def _sigmoid(z):
        """Squash any number into (0, 1), without overflowing on large z."""
        return np.where(z >= 0,
                        1.0 / (1.0 + np.exp(-np.clip(z, -500, 500))),
                        np.exp(np.clip(z, -500, 500)) / (1.0 + np.exp(np.clip(z, -500, 500))))

    def predict_proba(self, X):
        Xs = self._standardise(np.asarray(X, dtype=np.float64))
        return self._sigmoid(Xs @ self.weights + self.bias)


def prepare_labelled_data(koi_table):
    """
    Keep only the rows we have a definite answer for.

    CANDIDATE rows are dropped: nobody knows what they are yet, so they
    cannot be used to measure whether we are right. They are exactly the
    rows a finished system would be pointed at.
    """
    labelled = koi_table[
        koi_table["koi_disposition"].isin(["CONFIRMED", "FALSE POSITIVE"])
    ].copy()

    features = build_features(labelled)

    # Drop rows with a missing measurement rather than guessing a value.
    usable = np.isfinite(features).all(axis=1)

    labelled = labelled.loc[usable].reset_index(drop=True)
    features = features[usable]
    labels = (labelled["koi_disposition"] == "CONFIRMED").to_numpy(dtype=np.float64)

    return labelled, features, labels


def split_by_star(labelled, features, labels, test_fraction=0.3, seed=0):
    """
    Split into training and test sets *by star*, not by signal.

    This matters. One star can host several KOIs, and signals from the same
    star share systematics. If some of a star's signals were in training and
    others in test, the model could recognise the star rather than learn the
    physics, and the score would be flattering nonsense.
    """
    rng = np.random.default_rng(seed)

    star_ids = labelled["kepid"].to_numpy()
    unique_stars = np.unique(star_ids)
    rng.shuffle(unique_stars)

    n_test = int(len(unique_stars) * test_fraction)
    test_stars = set(unique_stars[:n_test].tolist())

    is_test = np.array([sid in test_stars for sid in star_ids])

    return {
        "train_features": features[~is_test],
        "train_labels": labels[~is_test],
        "test_features": features[is_test],
        "test_labels": labels[is_test],
        "test_rows": labelled.loc[is_test].reset_index(drop=True),
        "n_train_stars": len(unique_stars) - n_test,
        "n_test_stars": n_test,
    }


def evaluate(predicted_planet, true_planet):
    """
    Score a set of yes/no predictions.

      precision - of the things we called planets, how many really were
      recall    - of the real planets, how many did we keep
      fp_rejection_rate - of the real false positives, how many did we throw out
    """
    predicted_planet = np.asarray(predicted_planet, dtype=bool)
    true_planet = np.asarray(true_planet, dtype=bool)

    true_positive = int(np.sum(predicted_planet & true_planet))
    false_positive = int(np.sum(predicted_planet & ~true_planet))
    false_negative = int(np.sum(~predicted_planet & true_planet))
    true_negative = int(np.sum(~predicted_planet & ~true_planet))

    precision = true_positive / (true_positive + false_positive) if (true_positive + false_positive) else 0.0
    recall = true_positive / (true_positive + false_negative) if (true_positive + false_negative) else 0.0
    f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
    rejection = true_negative / (true_negative + false_positive) if (true_negative + false_positive) else 0.0

    return {
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(f1, 4),
        "fp_rejection_rate": round(rejection, 4),
        "accuracy": round((true_positive + true_negative) / len(true_planet), 4),
        "confusion": {
            "planets_kept": true_positive,
            "planets_lost": false_negative,
            "false_positives_let_through": false_positive,
            "false_positives_rejected": true_negative,
        },
    }


def rules_only_predictions(rows):
    """Run the hand-written physical rules over a table of signals."""
    keep = []
    for _, row in rows.iterrows():
        _, verdict = physical_rules(row)
        # "uncertain" is not a rejection, so it stays in the planet pile.
        keep.append(verdict != "reject")
    return np.array(keep, dtype=bool)


def official_flag_predictions(rows):
    """
    The Kepler pipeline's own verdict, as a reference point. A signal with
    no false-positive flag set is one the official pipeline kept.
    """
    flags = rows[["koi_fpflag_nt", "koi_fpflag_ss",
                  "koi_fpflag_co", "koi_fpflag_ec"]].to_numpy()
    return ~(flags.sum(axis=1) > 0)


def choose_threshold(probabilities, labels, min_recall=0.90):
    """
    Pick the probability cut-off.

    We do not want the cut that maximises raw accuracy, because most planets
    are outnumbered by false positives and "reject everything" would score
    well. Instead we insist on keeping at least `min_recall` of the real
    planets, and among the cuts that manage that we take the one that
    rejects the most false positives.
    """
    best_threshold = 0.5
    best_rejection = -1.0

    for threshold in np.linspace(0.02, 0.98, 97):
        predicted = probabilities >= threshold
        scores = evaluate(predicted, labels)
        if scores["recall"] >= min_recall and scores["fp_rejection_rate"] > best_rejection:
            best_rejection = scores["fp_rejection_rate"]
            best_threshold = float(threshold)

    return best_threshold


def two_stage_predictions(probabilities, rows, threshold):
    """
    The combined system.

    A signal is only called a planet if it passes BOTH the physical rules
    and the learned model. Anything the rules call physically impossible is
    rejected no matter how confident the model is - a model should not be
    allowed to overrule arithmetic.
    """
    model_says_planet = probabilities >= threshold
    rules_say_planet = rules_only_predictions(rows)
    return model_says_planet & rules_say_planet


def run_idea2(koi_table, test_fraction=0.3, seed=0, min_recall=0.90):
    """
    The whole Idea 2 study: train, test and compare all four approaches.
    """
    labelled, features, labels = prepare_labelled_data(koi_table)
    split = split_by_star(labelled, features, labels, test_fraction, seed)

    model = LogisticRegression().fit(split["train_features"], split["train_labels"])

    train_probabilities = model.predict_proba(split["train_features"])
    threshold = choose_threshold(train_probabilities, split["train_labels"],
                                 min_recall=min_recall)

    test_probabilities = model.predict_proba(split["test_features"])
    test_rows = split["test_rows"]
    test_labels = split["test_labels"]

    results = {
        "rules_only": evaluate(rules_only_predictions(test_rows), test_labels),
        "model_only": evaluate(test_probabilities >= threshold, test_labels),
        "two_stage": evaluate(
            two_stage_predictions(test_probabilities, test_rows, threshold),
            test_labels),
        "official_kepler_flags": evaluate(
            official_flag_predictions(test_rows), test_labels),
    }

    weights = sorted(
        zip(FEATURE_NAMES, model.weights.tolist()),
        key=lambda pair: -abs(pair[1]),
    )

    return {
        "results": results,
        "threshold": round(threshold, 3),
        "feature_weights": [
            {"feature": name, "weight": round(value, 3)} for name, value in weights
        ],
        "dataset": {
            "n_labelled_signals": int(len(labels)),
            "n_confirmed": int(labels.sum()),
            "n_false_positive": int(len(labels) - labels.sum()),
            "n_train": int(len(split["train_labels"])),
            "n_test": int(len(test_labels)),
            "n_train_stars": split["n_train_stars"],
            "n_test_stars": split["n_test_stars"],
            "split": "by star, so no star appears in both halves",
        },
        "min_recall_target": min_recall,
    }
