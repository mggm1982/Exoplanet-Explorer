"""
composition.py
--------------
A molecular composition report for a transmission spectrum.

WHAT IT DOES
During a transit, some starlight passes through the planet's atmosphere.
Each molecule absorbs at its own wavelengths, so at those wavelengths the
planet blocks a little more light and the transit looks slightly DEEPER.
This module checks, for each molecule, whether the spectrum is deeper
inside that molecule's absorption band than in the nearby "continuum"
(wavelengths where no molecule in the list absorbs).

WHAT IT IS NOT
There is no neural network and no training here. This is simple, physical
feature matching. It is NOT a full atmospheric retrieval: it does not fit
temperatures, abundances or clouds, and overlapping bands can fool it.
A "feature" means "the spectrum is deeper here", not "this molecule is
proven to be present".

Input : wavelength (micrometres) and transit depth (any unit, e.g. %),
        optionally a per-point uncertainty in the same unit as the depth.
Output: one result per molecule, plus an overall summary.
"""

import numpy as np

# Absorption bands: (centre in um, half-width in um). Positions are the
# standard band centres used in exoplanet transmission spectroscopy.
# Bands that badly overlap another molecule (e.g. H2O/CO2 near 2.7 um,
# CH4/CO near 2.3 um) are left out on purpose, so a bump is not counted twice.
MOLECULE_BANDS = {
    "H2O": [(1.15, 0.05), (1.40, 0.08), (1.90, 0.10)],
    "CH4": [(3.30, 0.12)],
    "CO2": [(4.30, 0.12)],
    "CO":  [(4.65, 0.10)],
    "SO2": [(4.05, 0.06)],
    "Na":  [(0.589, 0.015)],
    "K":   [(0.767, 0.015)],
}

# Known overlaps the user should be warned about (shown next to the result).
OVERLAP_NOTES = {
    "H2O": "CH4 also absorbs near 1.15 and 1.4 um, so in a methane-rich spectrum this may be methane.",
    "CO":  "CO2 absorbs just next to this band (4.3 um); a strong CO2 feature can spill into it.",
    "SO2": "Sits between the CH4 and CO2 bands; check that neighbouring features are not spilling over.",
}

# Plain-English names for the report.
MOLECULE_NAMES = {
    "H2O": "Water vapour", "CH4": "Methane", "CO2": "Carbon dioxide",
    "CO": "Carbon monoxide", "SO2": "Sulfur dioxide",
    "Na": "Sodium", "K": "Potassium",
}

# How many "sigma" (noise units) a band must stand out by.
STRONG_SIGMA = 5.0
POSSIBLE_SIGMA = 3.0

# How far either side of a band to look for continuum points, in um.
CONTINUUM_WINDOW_UM = 0.35


def _in_any_band(wavelength):
    """True for each wavelength that falls inside ANY molecule's band."""
    inside = np.zeros(len(wavelength), dtype=bool)
    for bands in MOLECULE_BANDS.values():
        for centre, half in bands:
            inside |= np.abs(wavelength - centre) <= half
    return inside


def estimate_noise(depth_continuum):
    """
    Point-to-point scatter of the continuum, robust to outliers.

    Neighbouring points differ by noise (the real spectrum changes slowly),
    so the spread of the differences, divided by sqrt(2), is the noise of
    one point. The median absolute deviation (x 1.4826) ignores outliers.
    """
    if len(depth_continuum) < 3:
        return None
    steps = np.diff(depth_continuum)
    mad = np.median(np.abs(steps - np.median(steps)))
    return float(1.4826 * mad / np.sqrt(2.0))


def _check_band(wavelength, depth, sigma, out_of_band, centre, half):
    """Compare the mean depth inside one band with its local continuum."""
    in_band = np.abs(wavelength - centre) <= half
    n_in = int(in_band.sum())
    result = {"centre_um": centre, "half_width_um": half, "n_points": n_in,
              "covered": n_in > 0, "excess": None, "significance": None}
    if n_in == 0:
        return result

    # Continuum: nearby points that are outside every band.
    near = (np.abs(wavelength - centre) <= half + CONTINUUM_WINDOW_UM) & out_of_band
    if near.sum() < 3:
        near = out_of_band  # fall back to the whole spectrum's continuum
    if near.sum() < 2:
        return result

    excess = float(depth[in_band].mean() - np.median(depth[near]))
    # Uncertainty of (mean in band - continuum level).
    err_in = np.sqrt(np.sum(sigma[in_band] ** 2)) / n_in
    err_cont = np.sqrt(np.sum(sigma[near] ** 2)) / near.sum()
    error = float(np.sqrt(err_in ** 2 + err_cont ** 2))
    result["excess"] = excess
    result["significance"] = excess / error if error > 0 else None
    return result


def _verdict(band):
    """Turn one band's numbers into words."""
    if not band["covered"]:
        return "Not covered"
    s = band["significance"]
    if s is None:
        return "Not enough data"
    if s >= STRONG_SIGMA:
        return "Strong feature"
    if s >= POSSIBLE_SIGMA:
        return "Possible feature"
    return "No feature"


def analyse_spectrum(wavelength_um, depth, uncertainty=None):
    """
    Build the composition report.

    wavelength_um : 1-D array of wavelengths (um). Values above 100 are
                    assumed to be nanometres and converted.
    depth         : 1-D array of transit depths, same length (any unit).
    uncertainty   : optional 1-D array of per-point errors (same unit as
                    depth). If missing, the noise is estimated from the
                    continuum scatter.
    """
    wavelength = np.asarray(wavelength_um, dtype=float)
    depth = np.asarray(depth, dtype=float)
    if wavelength.shape != depth.shape or wavelength.ndim != 1:
        raise ValueError("wavelength and depth must be 1-D and the same length")

    keep = np.isfinite(wavelength) & np.isfinite(depth)
    if uncertainty is not None:
        uncertainty = np.asarray(uncertainty, dtype=float)
        keep &= np.isfinite(uncertainty) & (uncertainty > 0)
    wavelength, depth = wavelength[keep], depth[keep]
    if uncertainty is not None:
        uncertainty = uncertainty[keep]
    if len(wavelength) < 5:
        raise ValueError("need at least 5 valid points in the spectrum")

    if np.median(wavelength) > 100:  # looks like nanometres
        wavelength = wavelength / 1000.0

    order = np.argsort(wavelength)
    wavelength, depth = wavelength[order], depth[order]

    out_of_band = ~_in_any_band(wavelength)
    if uncertainty is not None:
        sigma = uncertainty[order]
        noise_source = "uncertainty column in the file"
    else:
        noise = estimate_noise(depth[out_of_band])
        if noise is None or noise <= 0:
            # Too few continuum points, or a perfectly smooth model spectrum.
            noise = estimate_noise(depth) or 0.0
        noise = max(noise, 1e-6 * float(np.median(np.abs(depth))))
        sigma = np.full(len(depth), noise)
        noise_source = "estimated from the continuum scatter"

    molecules = []
    for name, bands in MOLECULE_BANDS.items():
        checked = [_check_band(wavelength, depth, sigma, out_of_band, c, h)
                   for c, h in bands]
        for band in checked:
            band["verdict"] = _verdict(band)
        # The molecule's verdict comes from its strongest covered band.
        covered = [b for b in checked if b["significance"] is not None]
        best = max(covered, key=lambda b: b["significance"]) if covered else checked[0]
        molecules.append({
            "molecule": name,
            "name": MOLECULE_NAMES[name],
            "verdict": _verdict(best),
            "best_band_um": best["centre_um"],
            "excess": best["excess"],
            "significance": best["significance"],
            "bands": checked,
            "note": OVERLAP_NOTES.get(name, ""),
        })

    strong = [m["molecule"] for m in molecules if m["verdict"] == "Strong feature"]
    possible = [m["molecule"] for m in molecules if m["verdict"] == "Possible feature"]
    if strong or possible:
        summary = "Absorption features found: " + ", ".join(strong + possible) + "."
    elif any(m["verdict"] != "Not covered" for m in molecules):
        summary = ("No feature stands out. The spectrum is flat within the noise, "
                   "which can mean high clouds or hazes, or features too weak to see.")
    else:
        summary = "The spectrum does not cover any of the molecular bands checked."

    return {
        "wavelength_um": wavelength.round(5).tolist(),
        "depth": depth.round(6).tolist(),
        "range_um": [float(wavelength.min()), float(wavelength.max())],
        "n_points": int(len(wavelength)),
        "noise_per_point": float(np.median(sigma)),
        "noise_source": noise_source,
        "thresholds_sigma": {"strong": STRONG_SIGMA, "possible": POSSIBLE_SIGMA},
        "molecules": molecules,
        "summary": summary,
        "caveat": ("Band matching only, not a full atmospheric retrieval. A feature "
                   "means the spectrum is deeper at that molecule's band, not proof "
                   "that the molecule is present."),
    }
