"""
inject.py
---------
Planting fake transits of known depth into a real light curve.

This is how you measure a detection pipeline honestly. Real data gives you
the real noise, real gaps and real stellar wobble; the injected transit
gives you a known right answer. Run the pipeline and see whether it finds
what you put in. Astronomers call this injection-recovery, and it is the
standard way to state "this survey is sensitive to planets down to X".

The transit shape used here is a trapezoid: the planet takes a little while
to slide onto the star's disc (ingress), sits fully in front of it for a
while, then slides off (egress). A plain box ignores ingress and egress; a
trapezoid is much closer to the truth and costs three lines of code.
"""

import numpy as np


def trapezoid_transit(times, period, t0, duration, depth, ingress_fraction=0.15):
    """
    Build a transit signal to add to a light curve.

    Input:  times    - observation times
            period   - how often the transit repeats, same units as times
            t0       - the time of the middle of one transit
            duration - total length of the transit, first to last contact
            depth    - fraction of light blocked at the bottom (0.01 = 1%)
            ingress_fraction - how much of the duration is spent sliding on
    Output: an array the same length as times, 0 outside transit and
            -depth at the bottom of the transit.
    """
    times = np.asarray(times, dtype=np.float64)

    # How far is each point from the nearest transit centre?
    phase = np.mod(times - t0 + period / 2.0, period) - period / 2.0
    distance = np.abs(phase)

    half = duration / 2.0
    # Where the flat bottom begins.
    flat_half = half * (1.0 - ingress_fraction)

    signal = np.zeros(len(times))

    # Fully in transit: the whole planet is in front of the star.
    signal[distance <= flat_half] = -depth

    # On the sloping edges: the planet is partly on the disc.
    on_edge = (distance > flat_half) & (distance < half)
    if np.any(on_edge):
        # Linear ramp from 0 at the outer edge to -depth at the flat part.
        fraction = (half - distance[on_edge]) / (half - flat_half)
        signal[on_edge] = -depth * fraction

    return signal


def inject(times, flux, period, t0, duration, depth):
    """
    Add a transit to a *normalised* light curve (one that sits around 1.0).

    We multiply rather than add, because a transit blocks a fraction of the
    star's light. If the star happens to be brighter than usual at that
    moment, the transit removes proportionally more light.
    """
    signal = trapezoid_transit(times, period, t0, duration, depth)
    return np.asarray(flux, dtype=np.float64) * (1.0 + signal)


def random_transit_parameters(times, depth, rng, min_period=None, max_period=None):
    """
    Pick a sensible random period, epoch and duration for an injected planet.

    The duration is derived from the period with a rough physical scaling:
    for a planet on a circular orbit round a Sun-like star, the transit
    lasts about 13 hours times the cube root of the period in years. That
    keeps the injected planets physically plausible instead of letting a
    3-day planet have a 20-hour transit.
    """
    baseline = float(np.max(times) - np.min(times))

    if min_period is None:
        min_period = 0.5
    if max_period is None:
        # Insist on at least three transits inside the data, so the search
        # has a fair chance of finding a repeating signal.
        max_period = baseline / 3.0

    if max_period <= min_period:
        raise ValueError("The light curve is too short to inject into.")

    # Uniform in log period, because periods span orders of magnitude.
    log_low, log_high = np.log10(min_period), np.log10(max_period)
    period = float(10 ** rng.uniform(log_low, log_high))

    # The physical duration scaling, in days.
    duration = (13.0 / 24.0) * (period / 365.25) ** (1.0 / 3.0)
    # Impact parameter makes real transits shorter than the central case.
    duration = float(duration * rng.uniform(0.5, 1.0))

    t0 = float(np.min(times) + rng.uniform(0, period))

    return {
        "period": period,
        "t0": t0,
        "duration": duration,
        "depth": float(depth),
    }
