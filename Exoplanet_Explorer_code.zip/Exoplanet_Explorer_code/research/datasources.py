"""
datasources.py
--------------
WHERE THE DATA COMES FROM.

This file is the single place where the project reaches outside itself for
data. Nothing else downloads anything. If you want to know where a number
came from, start here.

--------------------------------------------------------------------------
SOURCE 1 (real, external)  NASA Exoplanet Archive - Planetary Systems table
--------------------------------------------------------------------------
  What it is : the official catalogue of every confirmed exoplanet, kept by
               NASA/IPAC at Caltech. One row per planet per published
               reference; `default_flag=1` picks the reference the archive
               considers best for that planet.
  Used for   : real, peer-reviewed values of orbital period, transit depth,
               transit duration and planet/star radius ratio. We use them to
               check that the numbers our own code produces are physically
               sensible, and to show a student what real planets look like.
  Served by  : a TAP (Table Access Protocol) endpoint that returns CSV.
  Endpoint   : https://exoplanetarchive.ipac.caltech.edu/TAP/sync
  Docs       : https://exoplanetarchive.ipac.caltech.edu/docs/TAP/usingTAP.html
  Table docs : https://exoplanetarchive.ipac.caltech.edu/docs/API_PS_columns.html
  Access     : free, no account, no API key.
  Citation   : "This research has made use of the NASA Exoplanet Archive,
               which is operated by the California Institute of Technology,
               under contract with the National Aeronautics and Space
               Administration under the Exoplanet Exploration Program."
               DOI: 10.26133/NEA12

--------------------------------------------------------------------------
SOURCE 2 (simulated, local)  the CSV files in this folder
--------------------------------------------------------------------------
  exoTrain_data.csv  2500 stars x 1500 points, 238 labelled as planets
  sample_stars.csv     12 stars x 1500 points,   6 labelled as planets

  These are SIMULATED, not telescope data. See data_provenance.md in the
  project root for the evidence. The CNN in exoplanet_model.keras was
  trained on them, so every CNN probability this app produces is a
  statement about simulated light curves.

--------------------------------------------------------------------------
Everything downloaded is cached in data/cache/ so that repeated runs do not
hammer NASA's servers, and so the project still works offline once the
cache exists.
"""

import json
import os
import ssl
import time
import urllib.parse
import urllib.request

import pandas as pd

# Where cached downloads and their provenance records are kept.
HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DIR = os.path.join(HERE, "data", "cache")

# The NASA Exoplanet Archive TAP endpoint.
NASA_TAP_URL = "https://exoplanetarchive.ipac.caltech.edu/TAP/sync"

NASA_CITATION = (
    "NASA Exoplanet Archive, Planetary Systems table, "
    "operated by Caltech under contract with NASA "
    "(Exoplanet Exploration Program). DOI: 10.26133/NEA12"
)

# The query we send. Kept as a constant so it can be printed in the app and
# quoted in a write-up: anyone can paste it into the archive's own web form
# and get the same rows back.
CONFIRMED_TRANSITING_QUERY = """
select pl_name, hostname, disc_facility, disc_year,
       pl_orbper, pl_trandep, pl_trandur, pl_ratror, pl_rade, st_rad
from ps
where tran_flag = 1
  and default_flag = 1
  and pl_orbper is not null
  and pl_trandep is not null
  and pl_ratror is not null
order by pl_name
""".strip()


class DataSourceError(Exception):
    """Raised when real data cannot be fetched and no cache is available."""


def _ssl_context():
    """
    Build an SSL context with a certificate bundle that actually works.

    Python installed from python.org on macOS often has no system
    certificates, so HTTPS fails with CERTIFICATE_VERIFY_FAILED. The
    `certifi` package ships Mozilla's bundle and is already present as a
    dependency of requests (which TensorFlow pulls in). Fall back to the
    system default if it is somehow missing.
    """
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


def fetch_confirmed_transiting_planets(use_cache=True, timeout=90):
    """
    Download the real catalogue of confirmed transiting exoplanets.

    Returns a pandas DataFrame. Columns are documented at
    https://exoplanetarchive.ipac.caltech.edu/docs/API_PS_columns.html

      pl_orbper   orbital period, in days
      pl_trandep  transit depth, as a PERCENT (so 1.0 means 1%)
      pl_trandur  transit duration, in hours
      pl_ratror   planet radius / star radius
      pl_rade     planet radius, in Earth radii
      st_rad      star radius, in Solar radii

    If the download fails and a cached copy exists, the cache is used and a
    note is written into the provenance record.
    """
    os.makedirs(CACHE_DIR, exist_ok=True)
    csv_path = os.path.join(CACHE_DIR, "nasa_confirmed_transiting.csv")
    meta_path = os.path.join(CACHE_DIR, "nasa_confirmed_transiting.provenance.json")

    if use_cache and os.path.exists(csv_path):
        return pd.read_csv(csv_path)

    url = NASA_TAP_URL + "?" + urllib.parse.urlencode({
        "query": CONFIRMED_TRANSITING_QUERY,
        "format": "csv",
    })

    request = urllib.request.Request(
        url,
        headers={"User-Agent": "exoplanet-transit-detector/1.0 (student project)"},
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout,
                                    context=_ssl_context()) as response:
            body = response.read().decode("utf-8")
    except Exception as error:
        if os.path.exists(csv_path):
            # Better a slightly old catalogue than no catalogue.
            return pd.read_csv(csv_path)
        raise DataSourceError(
            "Could not download the NASA Exoplanet Archive catalogue and no "
            "cached copy exists. Check your internet connection. "
            "Underlying error: " + str(error)
        )

    with open(csv_path, "w") as handle:
        handle.write(body)

    table = pd.read_csv(csv_path)

    # --- write down exactly where this came from --------------------------
    provenance = {
        "source_name": "NASA Exoplanet Archive - Planetary Systems (ps) table",
        "endpoint": NASA_TAP_URL,
        "query": CONFIRMED_TRANSITING_QUERY,
        "full_url": url,
        "downloaded_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "n_rows": int(table.shape[0]),
        "columns": list(table.columns),
        "citation": NASA_CITATION,
        "column_docs": "https://exoplanetarchive.ipac.caltech.edu/docs/API_PS_columns.html",
        "notes": "Real, peer-reviewed measurements. Not simulated.",
    }
    with open(meta_path, "w") as handle:
        json.dump(provenance, handle, indent=2)

    return table


def cached_provenance():
    """
    Return the provenance record of the cached catalogue, or None.
    The web app shows this so the source is visible in the interface,
    not buried in the code.
    """
    meta_path = os.path.join(CACHE_DIR, "nasa_confirmed_transiting.provenance.json")
    if not os.path.exists(meta_path):
        return None
    with open(meta_path) as handle:
        return json.load(handle)


def describe_local_files():
    """
    Describe the CSV files that ship with the project, and say plainly that
    they are simulated. Returned to the web app so the warning appears in
    the interface too.
    """
    files = []
    for name, description in [
        ("exoTrain_data.csv", "Training set the CNN was fitted on"),
        ("sample_stars.csv", "Small demo set for trying the app"),
    ]:
        path = os.path.join(HERE, "data", "simulated", name)
        if not os.path.exists(path):
            continue
        files.append({
            "filename": name,
            "description": description,
            "origin": "SIMULATED - generated for this project, not telescope data",
            "size_mb": round(os.path.getsize(path) / (1024 * 1024), 2),
        })
    return files


# ---------------------------------------------------------------------------
# SOURCE 3 (real, external)  Kepler Objects of Interest - the KOI table
# ---------------------------------------------------------------------------
#   What it is : every transit-like signal Kepler's pipeline ever flagged,
#                roughly 9,500 of them, each one dispositioned by the Kepler
#                team as CONFIRMED, FALSE POSITIVE or CANDIDATE.
#   Why it is  : this is real, human- and pipeline-vetted ground truth for
#     gold       Idea 2. We do not have to simulate false positives - here
#                are nearly five thousand genuine ones.
#   Table      : `cumulative` on the same NASA TAP endpoint.
#   Columns    : https://exoplanetarchive.ipac.caltech.edu/docs/API_kepcandidate_columns.html
# ---------------------------------------------------------------------------

KOI_QUERY = """
select kepid, kepoi_name, kepler_name, koi_disposition, koi_pdisposition,
       koi_score, koi_period, koi_depth, koi_duration, koi_prad, koi_ror,
       koi_model_snr, koi_impact, koi_teq, koi_steff, koi_srad,
       koi_fpflag_nt, koi_fpflag_ss, koi_fpflag_co, koi_fpflag_ec
from cumulative
""".strip()

# The four flags the Kepler pipeline itself sets when it rejects a signal:
#   nt = not transit-like          ss = significant secondary eclipse
#   co = centroid offset           ec = ephemeris match / contamination
# These ARE the answer, so a classifier must never be given them as inputs.
# We keep them only to compare our own system against the official one.
KOI_FP_FLAGS = ["koi_fpflag_nt", "koi_fpflag_ss", "koi_fpflag_co", "koi_fpflag_ec"]


def fetch_koi_table(use_cache=True, timeout=180):
    """
    Download the real Kepler Objects of Interest table.

    Returns a pandas DataFrame of about 9,500 rows. `koi_disposition` is the
    label: CONFIRMED, FALSE POSITIVE or CANDIDATE.
    """
    os.makedirs(CACHE_DIR, exist_ok=True)
    csv_path = os.path.join(CACHE_DIR, "kepler_koi_cumulative.csv")
    meta_path = os.path.join(CACHE_DIR, "kepler_koi_cumulative.provenance.json")

    if use_cache and os.path.exists(csv_path):
        return pd.read_csv(csv_path)

    url = NASA_TAP_URL + "?" + urllib.parse.urlencode({
        "query": KOI_QUERY,
        "format": "csv",
    })
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "exoplanet-transit-detector/1.0 (student project)"},
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout,
                                    context=_ssl_context()) as response:
            body = response.read().decode("utf-8")
    except Exception as error:
        if os.path.exists(csv_path):
            return pd.read_csv(csv_path)
        raise DataSourceError(
            "Could not download the Kepler KOI table and no cached copy "
            "exists. Underlying error: " + str(error)
        )

    with open(csv_path, "w") as handle:
        handle.write(body)

    table = pd.read_csv(csv_path)

    counts = table["koi_disposition"].value_counts().to_dict()
    with open(meta_path, "w") as handle:
        json.dump({
            "source_name": "NASA Exoplanet Archive - Kepler cumulative KOI table",
            "endpoint": NASA_TAP_URL,
            "query": KOI_QUERY,
            "downloaded_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "n_rows": int(table.shape[0]),
            "disposition_counts": {str(k): int(v) for k, v in counts.items()},
            "citation": NASA_CITATION,
            "column_docs": ("https://exoplanetarchive.ipac.caltech.edu/docs/"
                            "API_kepcandidate_columns.html"),
            "notes": ("REAL vetted labels. koi_fpflag_* columns are the "
                      "pipeline's own verdict and must not be used as "
                      "classifier inputs."),
        }, handle, indent=2)

    return table
