"""
detrend.py
----------
IDEA 1: the noise-removal methods we are comparing.

A real light curve is the planet signal sitting on top of two nuisances:

  * a slow wander, caused by the star itself rotating and by the telescope
    warming and cooling. This is the "trend".
  * fast random scatter from counting a limited number of photons. This is
    the "noise".

Every method here does the same job - return a flat curve where 0 means
"normal brightness" and -0.01 means "1% of the light is missing" - but each
one removes the trend and the noise in a different way. Idea 1 asks which
of them lets us find the shallowest transits without also inventing
transits that are not there.
"""

import numpy as np
from scipy.ndimage import median_filter
from scipy.signal import savgol_filter

from research.wavelet import denoise as wavelet_denoise

# The names a caller may ask for. Keeping them in one list means the API,
# the tests and the experiment all agree on what exists.
METHODS = ["none", "median", "savgol", "wavelet"]

# Human-readable descriptions, shown in the web app.
METHOD_LABELS = {
    "none": "No detrending (baseline)",
    "median": "Running median (window 101)",
    "savgol": "Savitzky-Golay filter (window 101, order 2)",
    "wavelet": "Running median + Haar wavelet denoising",
}

# The width of the smoothing window, in data points. It must be a lot wider
# than a transit, or the filter will smooth the transit away along with the
# trend.
WINDOW = 101

# Savitzky-Golay fits a polynomial of this order inside each window.
POLY_ORDER = 2


def detrend(flux, method="median"):
    """
    Flatten one light curve.

    Input:  flux   - 1-D array of brightness values
            method - one of METHODS
    Output: 1-D array of the same length, where 0 is the normal level and
            negative numbers mean the star got fainter.

    We divide by the trend rather than subtracting it, so the result is a
    *fraction* of the star's light. That makes a depth of 0.01 mean "1% of
    the light was blocked" whatever the star's actual brightness was.
    """
    flux = np.asarray(flux, dtype=np.float64)

    if method not in METHODS:
        raise ValueError("Unknown method '" + str(method) +
                         "'. Choose one of: " + ", ".join(METHODS))

    if method == "none":
        # The simplest possible baseline: assume the star is already flat
        # and just express everything relative to the median.
        trend = np.full_like(flux, np.median(flux))

    elif method == "median":
        # A running median ignores short dips, so it follows the slow trend
        # without being dragged down by a transit. This is what the CNN's
        # own preprocessing uses.
        trend = median_filter(flux, size=WINDOW, mode="nearest")

    elif method == "savgol":
        # Savitzky-Golay fits a small polynomial inside a sliding window.
        # It follows a curving trend more closely than a median does, but
        # being a least-squares fit it IS pulled down a little by a transit.
        window = min(WINDOW, _make_odd(len(flux)))
        trend = savgol_filter(flux, window_length=window, polyorder=POLY_ORDER,
                              mode="nearest")

    else:  # "wavelet"
        # Remove the trend with a running median first, then attack the
        # remaining fast scatter with the wavelet denoiser.
        trend = median_filter(flux, size=WINDOW, mode="nearest")

    # Guard against dividing by zero on a dead or negative-valued curve.
    trend = np.where(np.abs(trend) < 1e-12, 1e-12, trend)

    flattened = flux / trend - 1.0

    if method == "wavelet":
        flattened = wavelet_denoise(flattened, levels=4)

    return flattened


def _make_odd(n):
    """Savitzky-Golay needs an odd window length that is not longer than the data."""
    if n % 2 == 0:
        n = n - 1
    return max(5, n)


def estimate_noise(flattened):
    """
    Estimate the point-to-point noise of an already-flattened curve.

    We use the difference between neighbouring points rather than the plain
    standard deviation, because the plain standard deviation would include
    the transit itself and any leftover trend.
    """
    differences = np.diff(flattened)
    mad = np.median(np.abs(differences - np.median(differences)))
    # 1.4826 converts a median absolute deviation into a standard deviation,
    # and sqrt(2) undoes the fact that a difference of two points is noisier
    # than one point.
    return float(1.4826 * mad / np.sqrt(2))
