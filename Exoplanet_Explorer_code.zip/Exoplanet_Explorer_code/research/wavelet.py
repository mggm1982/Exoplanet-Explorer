"""
wavelet.py
----------
A very small wavelet denoiser, written by hand so the project does not
need the PyWavelets package.

The idea in one paragraph: a wavelet transform splits a signal into a
smooth part and a series of "detail" parts, each describing wiggles at a
different scale. Random noise spreads itself thinly across all the detail
levels, while a real transit is a large coordinated feature. So if we set
all the small detail coefficients to zero and rebuild the signal, we throw
away mostly noise and keep mostly signal.

We use the Haar wavelet, which is the simplest one there is: it works on
pairs of neighbouring points, storing their average and their difference.
"""

import numpy as np


def _next_power_of_two(n):
    """The smallest power of two that is >= n. The Haar transform needs one."""
    power = 1
    while power < n:
        power = power * 2
    return power


def haar_forward(signal, levels):
    """
    Run the Haar transform `levels` times.

    Returns (smooth, details) where `details` is a list, finest level first.
    At each level the signal is replaced by the averages of its pairs, and
    the differences of those pairs are kept as that level's detail.
    """
    smooth = signal.astype(np.float64).copy()
    details = []

    for _ in range(levels):
        # Stop early if the signal has become too short to halve again.
        if len(smooth) < 2:
            break

        even = smooth[0::2]
        odd = smooth[1::2]

        # Divide by sqrt(2) so the transform preserves the total energy,
        # which is what makes the noise threshold below correct.
        details.append((even - odd) / np.sqrt(2))
        smooth = (even + odd) / np.sqrt(2)

    return smooth, details


def haar_inverse(smooth, details):
    """Rebuild the signal from the smooth part and the list of details."""
    # Work backwards: coarsest detail first.
    for detail in reversed(details):
        even = (smooth + detail) / np.sqrt(2)
        odd = (smooth - detail) / np.sqrt(2)

        # Interleave the two halves back into one array.
        rebuilt = np.empty(len(even) + len(odd))
        rebuilt[0::2] = even
        rebuilt[1::2] = odd
        smooth = rebuilt

    return smooth


def denoise(signal, levels=4):
    """
    Remove noise from a 1-D signal with Haar wavelet soft thresholding.

    The threshold is the "universal threshold" sigma * sqrt(2 * ln(n)),
    where sigma is estimated from the finest detail level. The finest level
    is almost entirely noise, so the median absolute deviation of its
    coefficients is a robust measure of the noise.
    """
    signal = np.asarray(signal, dtype=np.float64)
    original_length = len(signal)

    # The transform needs a length that can be halved `levels` times, so
    # pad the end by repeating the last value, then trim it off afterwards.
    padded_length = _next_power_of_two(original_length)
    padded = np.pad(signal, (0, padded_length - original_length), mode="edge")

    smooth, details = haar_forward(padded, levels)

    if len(details) == 0:
        return signal.copy()

    # --- estimate the noise from the finest detail level ------------------
    finest = details[0]
    mad = np.median(np.abs(finest - np.median(finest)))
    sigma = 1.4826 * mad  # convert a MAD into a standard deviation

    if sigma <= 0:
        # A perfectly clean signal. Nothing to remove.
        return signal.copy()

    threshold = sigma * np.sqrt(2.0 * np.log(padded_length))

    # --- soft thresholding -------------------------------------------------
    # Shrink every coefficient towards zero by `threshold`, and set to zero
    # anything smaller than that. Soft (rather than hard) thresholding avoids
    # the sharp jumps that hard cutting leaves behind.
    shrunk = []
    for detail in details:
        magnitude = np.maximum(np.abs(detail) - threshold, 0.0)
        shrunk.append(np.sign(detail) * magnitude)

    rebuilt = haar_inverse(smooth, shrunk)

    return rebuilt[:original_length]
