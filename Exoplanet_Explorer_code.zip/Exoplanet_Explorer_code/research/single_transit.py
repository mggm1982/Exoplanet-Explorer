"""
single_transit.py
-----------------
IDEA 3: finding planets that transit only once.

A long-period planet may cross its star just once while the telescope is
watching. BLS is useless here: it searches for a repeating box, and there
is nothing to repeat. Worse, with only one event you cannot measure the
orbital period at all - you can only put a lower limit on it, because if
the period were shorter you would have seen a second transit.

So the job changes. Instead of "what is the period?", the questions become:

    Is this dip real, or is it noise or a cosmic ray?
    How confident are we, and how should candidates be ranked for the
    limited amount of follow-up telescope time available?

HOW WE FIND THEM
A matched filter. If you know roughly what shape you are looking for, the
best way to find it in noise is to slide that shape along the data and ask
how well it fits at each position. We slide trapezoid transit templates of
several different durations and keep the positions that stand out.

HOW WE REJECT RUBBISH
A single dip has no repetition to confirm it, so shape is all we have:

  * a cosmic ray hits one or two cadences, not twenty - so we require a
    minimum number of points in the event
  * a real transit is symmetric - ingress and egress take the same time -
    so a lopsided dip is suspicious
  * a real transit has a flat-ish bottom; a sharp V usually means a grazing
    eclipsing binary
  * an event cut off by the start or end of the data has an unknown depth
  * a dip that is far deeper than any planet could cause is a binary star
"""

import numpy as np

from research.detrend import estimate_noise
from research.inject import trapezoid_transit

# Durations to try, in hours, for REAL data where `times` is in days.
# Long-period planets have long transits.
TEMPLATE_DURATIONS_HOURS = [2.0, 4.0, 6.0, 9.0, 13.0, 18.0, 24.0]

# A candidate must reach this signal-to-noise to be considered at all.
MIN_SNR = 7.0

# A candidate must contain at least this many measurements.
MIN_POINTS_IN_TRANSIT = 5

# Deeper than this and it is a star, not a planet (see vetting.py).
MAX_PLANET_DEPTH = 0.04

# How far apart two detections must be to count as separate events,
# as a multiple of the template duration.
SEPARATION_FACTOR = 1.5

# Below this shape score a V fits the dip better than a flat-bottomed
# transit does. The score is positive for box-like events and negative for
# pointed ones, so zero is the natural dividing line.
MIN_SHAPE_SCORE = 0.0

# Shape can only be judged when the event is well measured. Below this
# signal-to-noise the scatter swamps the difference between a flat bottom
# and a V, so we say we cannot tell rather than guessing. Measured on
# synthetic tests: a V scores about -0.81 at S/N 43 and -0.54 at S/N 21,
# but only -0.17 at S/N 10, where it is no longer separable from a transit.
MIN_SNR_FOR_SHAPE = 15.0


def matched_filter(times, flattened, duration_days):
    """
    Slide one trapezoid template along the light curve.

    At each point we compute the signal-to-noise of the best-fitting
    transit of this duration centred there. For a template `g` (negative
    inside the transit, zero outside) the optimal amplitude and its
    uncertainty give S/N = -sum(g*y) / (noise * sqrt(sum(g^2))).
    """
    times = np.asarray(times, dtype=np.float64)
    y = np.asarray(flattened, dtype=np.float64)

    noise = estimate_noise(y)
    if noise <= 0:
        noise = 1e-9

    snr = np.zeros(len(times))
    depth = np.zeros(len(times))
    n_in = np.zeros(len(times), dtype=int)

    half = duration_days / 2.0

    # The template is zero except within half a duration of its centre, so
    # we only ever need to look at the handful of points near each trial
    # position. Finding that slice with searchsorted keeps the whole search
    # fast instead of quadratic in the number of measurements.
    order = np.argsort(times)
    sorted_times = times[order]
    sorted_y = y[order]

    for i, centre in enumerate(times):
        low = np.searchsorted(sorted_times, centre - half)
        high = np.searchsorted(sorted_times, centre + half)

        local_times = sorted_times[low:high]
        local_y = sorted_y[low:high]

        if len(local_times) < MIN_POINTS_IN_TRANSIT:
            n_in[i] = len(local_times)
            continue

        # A period far longer than the data guarantees only one transit.
        template = trapezoid_transit(local_times, period=1e9, t0=centre,
                                     duration=duration_days, depth=1.0)

        count = int(np.sum(template < 0))
        n_in[i] = count

        if count < MIN_POINTS_IN_TRANSIT:
            continue

        denominator = float(np.sum(template ** 2))
        if denominator <= 0:
            continue

        # Best-fit depth and its signal-to-noise.
        #
        # The template is -1 inside the transit and 0 outside, and a real
        # dip makes y negative there too, so their product is POSITIVE.
        # The least-squares amplitude is therefore the depth itself.
        amplitude = float(np.sum(template * local_y)) / denominator
        depth[i] = amplitude
        snr[i] = amplitude * np.sqrt(denominator) / noise

    return snr, depth, n_in


def _v_template(times, centre, duration_days):
    """A V-shaped (grazing) eclipse: deepest at the centre, linear sides."""
    half = duration_days / 2.0
    offset = np.abs(times - centre)
    return -np.clip(1.0 - offset / half, 0.0, None)


def _fit_template(y, template):
    """
    Best-fit amplitude of one template, and the residual left over.
    Returns (amplitude, residual_sum_of_squares).
    """
    denominator = float(np.sum(template ** 2))
    if denominator <= 0:
        return 0.0, float(np.sum(y ** 2))

    amplitude = float(np.sum(template * y)) / denominator
    residual = y - amplitude * template
    return amplitude, float(np.sum(residual ** 2))


def _measure_shape(times, flattened, centre, duration_days):
    """
    Decide whether this event is shaped more like a planet transit or more
    like a grazing eclipsing binary, and how symmetric it is.

    Returns (symmetry, shape_score).

      symmetry     0 = ingress and egress match, 1 = completely lopsided.
      shape_score  runs from -1 to +1.
                   POSITIVE means a flat-bottomed trapezoid fits better,
                   which is what a real planet transit looks like: the
                   planet is entirely in front of the star for most of the
                   event, so the bottom is flat.
                   NEGATIVE means a V fits better. A grazing binary never
                   fully covers its companion, so its dip comes to a point.

    An earlier version of this just compared the depth at the centre with
    the depth at the edges. That failed, because the template duration is
    rarely the true duration, so the "edges" were often measured inside the
    event. Fitting two whole shapes and asking which explains the data
    better does not have that problem - and it searches a range of widths
    for each shape, so neither is handicapped by a bad width guess.
    """
    half_window = duration_days * 1.2
    near = np.abs(times - centre) < half_window

    if int(np.sum(near)) < 8:
        return float("nan"), float("nan")

    local_times = times[near]
    local_y = flattened[near]

    # Give each shape its best shot by trying several widths.
    widths = duration_days * np.array([0.6, 0.8, 1.0, 1.25, 1.6])

    best_trapezoid = None
    best_v = None

    for width in widths:
        trapezoid = trapezoid_transit(local_times, period=1e9, t0=centre,
                                      duration=width, depth=1.0)
        amplitude, residual = _fit_template(local_y, trapezoid)
        if amplitude > 0 and (best_trapezoid is None or residual < best_trapezoid):
            best_trapezoid = residual

        v_shape = _v_template(local_times, centre, width)
        amplitude, residual = _fit_template(local_y, v_shape)
        if amplitude > 0 and (best_v is None or residual < best_v):
            best_v = residual

    if best_trapezoid is None or best_v is None:
        return float("nan"), float("nan")

    total = best_trapezoid + best_v
    shape_score = (best_v - best_trapezoid) / total if total > 0 else 0.0

    # --- symmetry: compare the first half of the event with the second ---
    offset = local_times - centre
    left = (offset < 0) & (offset > -duration_days / 2.0)
    right = (offset > 0) & (offset < duration_days / 2.0)

    if int(left.sum()) < 2 or int(right.sum()) < 2:
        return float("nan"), float(shape_score)

    left_depth = -float(np.mean(local_y[left]))
    right_depth = -float(np.mean(local_y[right]))
    scale = abs(left_depth) + abs(right_depth)
    symmetry = abs(left_depth - right_depth) / scale if scale > 0 else float("nan")

    return symmetry, float(shape_score)


def find_single_transits(times, flattened, min_snr=MIN_SNR, max_candidates=10,
                         durations=None):
    """
    Search a flattened light curve for isolated transit-like events.

    `durations` must be in THE SAME UNITS AS `times`. This matters more than
    it sounds: real Kepler data has `times` in days, so the templates are
    hours converted to days, but a bare CSV has no time column at all and
    `times` is just the row index - there, a duration must be a number of
    data points. Mixing the two silently searches for transits a fraction
    of one measurement wide and finds nothing at all.

    Leave it as None for real data in days and the defaults are used.

    Returns a list of candidate dictionaries, best first.
    """
    times = np.asarray(times, dtype=np.float64)
    y = np.asarray(flattened, dtype=np.float64)

    baseline = float(times.max() - times.min())
    noise = estimate_noise(y)

    if durations is None:
        durations = [hours / 24.0 for hours in TEMPLATE_DURATIONS_HOURS]

    found = []

    for duration_days in durations:
        if duration_days > baseline / 4.0:
            # The template must be much shorter than the data.
            continue

        snr, depth, n_in = matched_filter(times, y, duration_days)

        # Walk down the peaks, strongest first, removing everything nearby
        # each time so one event is not reported several times over.
        working = snr.copy()
        for _ in range(max_candidates):
            best = int(np.argmax(working))
            if working[best] < min_snr:
                break

            centre = float(times[best])
            symmetry, shape_score = _measure_shape(times, y, centre, duration_days)

            found.append({
                "time": centre,
                "snr": float(snr[best]),
                "depth": float(depth[best]),
                "depth_percent": float(depth[best] * 100),
                "duration": float(duration_days),
                "n_points": int(n_in[best]),
                "symmetry": None if np.isnan(symmetry) else round(float(symmetry), 3),
                "shape_score": (None if np.isnan(shape_score)
                                else round(float(shape_score), 3)),
                "radius_ratio": float(np.sqrt(max(depth[best], 0.0))),
                "touches_edge": bool(
                    centre - duration_days / 2.0 <= times.min()
                    or centre + duration_days / 2.0 >= times.max()
                ),
                "min_period_days": round(
                    float(max(centre - times.min(), times.max() - centre)), 3),
            })

            # Blank out this event so the next loop finds a different one.
            near = np.abs(times - centre) < duration_days * SEPARATION_FACTOR
            working[near] = -np.inf

    merged = _merge_overlapping(found)
    ranked = [rank_candidate(c, noise, baseline) for c in merged]
    ranked.sort(key=lambda c: -c["score"])

    return ranked[:max_candidates]


def _merge_overlapping(candidates):
    """
    The same event is usually picked up by several template durations.
    Keep only the strongest detection of each distinct event.
    """
    candidates = sorted(candidates, key=lambda c: -c["snr"])
    kept = []

    for candidate in candidates:
        window = candidate["duration"] * SEPARATION_FACTOR
        clash = any(abs(candidate["time"] - other["time"]) < window
                    for other in kept)
        if not clash:
            kept.append(candidate)

    return kept


def rank_candidate(candidate, noise, baseline_days):
    """
    Turn the measurements into a single score and a plain-English verdict.

    With no repeat transit to confirm it, the ranking has to lean on signal
    strength and on how transit-like the shape is. The score exists to put
    the most promising candidates at the top of a follow-up list; it is not
    a probability.
    """
    reasons = []
    score = candidate["snr"]

    if candidate["touches_edge"]:
        reasons.append("Runs off the edge of the data, so its depth and "
                       "duration are lower limits only.")
        score *= 0.4

    if candidate["depth"] > MAX_PLANET_DEPTH:
        reasons.append("At %.1f%% deep this is too much light for a planet "
                       "to block; likely an eclipsing binary."
                       % candidate["depth_percent"])
        score *= 0.2

    if candidate["n_points"] < MIN_POINTS_IN_TRANSIT:
        reasons.append("Too few measurements inside the event to trust it.")
        score *= 0.3

    symmetry = candidate.get("symmetry")
    if symmetry is not None and symmetry > 0.5:
        reasons.append("Lopsided: ingress and egress look different, which a "
                       "real transit should not.")
        score *= 0.6

    shape_score = candidate.get("shape_score")
    shape_is_measurable = candidate["snr"] >= MIN_SNR_FOR_SHAPE

    if shape_score is not None and not shape_is_measurable:
        reasons.append("Too faint (S/N %.0f) to tell a flat-bottomed transit "
                       "from a V-shaped eclipse; shape is not evidence here."
                       % candidate["snr"])
        score *= 0.85

    if (shape_score is not None and shape_is_measurable
            and shape_score < MIN_SHAPE_SCORE):
        reasons.append("A V shape fits this dip better than a flat-bottomed "
                       "transit (shape score %+.2f), which is what a grazing "
                       "eclipsing binary looks like." % shape_score)
        score *= 0.7

    if candidate["snr"] < MIN_SNR:
        reasons.append("Signal-to-noise below %.0f." % MIN_SNR)

    if not reasons:
        verdict = "Promising single-transit candidate"
    elif score >= MIN_SNR:
        verdict = "Possible candidate, with caveats"
    else:
        verdict = "Probably not a transit"

    candidate = dict(candidate)
    candidate["score"] = round(float(score), 2)
    candidate["verdict"] = verdict
    candidate["caveats"] = reasons
    # With one transit the period is unknown; all we know is that a second
    # transit did not happen inside the data we have.
    candidate["period_note"] = (
        "Period unknown. A second transit did not occur within the data, so "
        "the period is longer than about %.0f days."
        % candidate["min_period_days"])

    return candidate
