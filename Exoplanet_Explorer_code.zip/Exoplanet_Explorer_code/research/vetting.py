"""
vetting.py
----------
IDEA 2, stage two: deciding whether a transit-like signal is really a planet.

Lots of things make a star dimmer for a few hours, and most of them are not
planets. The three common impostors:

  ECLIPSING BINARY  Two stars orbiting each other. One passes in front of
      the other and blocks a huge amount of light. Tell-tale signs: the dip
      is far too deep, the "planet" comes out bigger than any planet can be,
      and there is often a shallower *secondary* eclipse half an orbit later
      when the dimmer star goes behind the brighter one.

  BLENDED / BACKGROUND BINARY  An eclipsing binary that happens to sit close
      to our target on the sky. Its deep eclipse is diluted by the bright
      target star, so it arrives looking like a shallow planet transit. The
      give-away is that the centre of light shifts during the eclipse.

  INSTRUMENT ARTEFACT  Cosmic rays, thruster firings and detector problems.
      These rarely repeat on a clean period and rarely look like a transit.

A PHYSICAL NOTE ON WHY DEPTH IS SO POWERFUL
A transiting object blocks a fraction of the star equal to the ratio of
their areas, so depth = (Rp/Rs)^2. Planets stop growing in radius above
about one Jupiter radius - add more mass and gravity squashes it - so for a
Sun-like star Rp/Rs cannot exceed roughly 0.15 to 0.2, which caps a genuine
transit at about 3-4% deep. Anything much deeper is two stars.
"""

import numpy as np

# Above this radius ratio the "planet" is simply too large to be one.
MAX_PLAUSIBLE_ROR = 0.25

# Planet radius in Earth radii. Jupiter is 11.2; above ~25 nothing is a planet.
MAX_PLAUSIBLE_PRAD = 25.0

# A signal weaker than this is not worth believing.
MIN_TRUSTWORTHY_SNR = 7.1

# A transit should occupy a small slice of the orbit. An eclipsing binary
# on a close orbit spends a large fraction of its period in eclipse.
MAX_DUTY_CYCLE = 0.15

# The features the classifier is allowed to see. Deliberately all physical
# measurements of the signal itself.
FEATURE_NAMES = [
    "log_period",
    "log_depth",
    "duration_hours",
    "duty_cycle",
    "log_prad",
    "ror",
    "log_snr",
    "impact",
    "duration_ratio",
]


def expected_duration_hours(period_days):
    """
    Roughly how long should a transit last, for this period?

    For a planet crossing the centre of a Sun-like star on a circular orbit
    the transit lasts about 13 hours * (P in years)^(1/3). A signal lasting
    far longer than this is suspicious: it is the signature of two stars in
    a close orbit, or of something that is not a transit at all.
    """
    period_days = np.asarray(period_days, dtype=np.float64)
    years = np.clip(period_days, 1e-6, None) / 365.25
    return 13.0 * np.cbrt(years)


def build_features(table):
    """
    Turn the raw KOI columns into the feature matrix the classifier sees.

    IMPORTANT: the koi_fpflag_* columns are NOT used here. They are the
    Kepler team's own verdict, so feeding them in would be asking the model
    to copy the answer rather than work it out. They are kept aside purely
    as a baseline to compare against.
    """
    period = table["koi_period"].to_numpy(dtype=np.float64)
    depth_ppm = table["koi_depth"].to_numpy(dtype=np.float64)
    duration = table["koi_duration"].to_numpy(dtype=np.float64)
    prad = table["koi_prad"].to_numpy(dtype=np.float64)
    ror = table["koi_ror"].to_numpy(dtype=np.float64)
    snr = table["koi_model_snr"].to_numpy(dtype=np.float64)
    impact = table["koi_impact"].to_numpy(dtype=np.float64)

    # Fraction of the orbit spent in transit.
    duty_cycle = (duration / 24.0) / np.clip(period, 1e-6, None)

    # Observed duration compared with the physically expected one.
    duration_ratio = duration / expected_duration_hours(period)

    features = np.column_stack([
        _safe_log10(period),
        _safe_log10(depth_ppm),
        duration,
        duty_cycle,
        _safe_log10(prad),
        ror,
        _safe_log10(snr),
        impact,
        duration_ratio,
    ])

    return features


def _safe_log10(values):
    """log10 that does not blow up on zeros or negatives."""
    values = np.asarray(values, dtype=np.float64)
    return np.log10(np.clip(values, 1e-9, None))


def physical_rules(row):
    """
    The hand-written checks, applied to one signal.

    These need no training at all - they come straight from the physics -
    so they are a fair baseline to measure a learned classifier against.

    Returns (list_of_reasons, verdict). An empty reason list means nothing
    looked wrong.
    """
    reasons = []

    ror = row.get("koi_ror")
    prad = row.get("koi_prad")
    snr = row.get("koi_model_snr")
    period = row.get("koi_period")
    duration = row.get("koi_duration")

    if _is_number(ror) and ror > MAX_PLAUSIBLE_ROR:
        reasons.append(
            "Radius ratio %.2f is above %.2f: the object is star-sized, "
            "not planet-sized." % (ror, MAX_PLAUSIBLE_ROR))

    if _is_number(prad) and prad > MAX_PLAUSIBLE_PRAD:
        reasons.append(
            "Implied radius %.1f Earth radii is larger than any planet "
            "(Jupiter is 11.2)." % prad)

    if _is_number(snr) and snr < MIN_TRUSTWORTHY_SNR:
        reasons.append(
            "Signal-to-noise %.1f is below %.1f: too weak to trust."
            % (snr, MIN_TRUSTWORTHY_SNR))

    if _is_number(period) and _is_number(duration) and period > 0:
        duty = (duration / 24.0) / period
        if duty > MAX_DUTY_CYCLE:
            reasons.append(
                "The dip occupies %.0f%% of the orbit, far more than a "
                "planet transit should." % (duty * 100))

        expected = float(expected_duration_hours(period))
        if duration > 3.0 * expected:
            reasons.append(
                "Lasts %.1f h but a planet at this period should last about "
                "%.1f h." % (duration, expected))

    if not reasons:
        return [], "pass"

    # A weak signal alone means "do not know"; a physically impossible one
    # means "definitely not a planet".
    only_weak = all("too weak" in r for r in reasons)
    return reasons, "uncertain" if only_weak else "reject"


def _is_number(value):
    """True if value is a real number we can compare."""
    try:
        return value is not None and np.isfinite(float(value))
    except (TypeError, ValueError):
        return False
