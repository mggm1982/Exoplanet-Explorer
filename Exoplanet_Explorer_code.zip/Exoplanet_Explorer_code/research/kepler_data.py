"""
kepler_data.py
--------------
Real light curves from the Kepler space telescope.

SOURCE
  Archive  : MAST (Mikulski Archive for Space Telescopes), run by STScI.
  Mission  : NASA Kepler. Each star is identified by a KIC number
             (Kepler Input Catalog), e.g. KIC 6922244 is the star Kepler-8.
  Search   : https://mast.stsci.edu/api/v0/invoke  (the Mashup/CAOM API)
  Download : https://mast.stsci.edu/api/v0.1/Download/file?uri=...
  Docs     : https://mast.stsci.edu/api/v0/
  Format   : FITS. Each file is one quarter (~90 days) of one star.
  Access   : free, public, no account needed.
  Citation : "This paper includes data collected by the Kepler mission and
             obtained from the MAST data archive at the Space Telescope
             Science Institute (STScI)." Kepler was funded by the NASA
             Science Mission Directorate.

WHAT IS IN A FILE
  TIME            days (Barycentric Kepler Julian Date)
  SAP_FLUX        simple aperture photometry, electrons per second
  PDCSAP_FLUX     the same after NASA's pipeline removes known instrument
                  systematics. This is the one to use.
  SAP_QUALITY     a bit mask. Non-zero means something was wrong with that
                  cadence (cosmic ray, thruster firing, safe mode, ...).

This is genuinely messy data: roughly 6% of cadences are NaN and hundreds
more carry quality flags. That is the point. The simulated CSVs in this
project have no gaps at all, which is what makes them unrealistically easy.
"""

import json
import os
import ssl
import time as time_module
import urllib.parse
import urllib.request

import numpy as np

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CACHE_DIR = os.path.join(HERE, "data", "cache", "kepler")

MAST_API = "https://mast.stsci.edu/api/v0/invoke"
MAST_DOWNLOAD = "https://mast.stsci.edu/api/v0.1/Download/file?uri="

KEPLER_CITATION = (
    "Data collected by the NASA Kepler mission, obtained from the MAST "
    "archive at the Space Telescope Science Institute (STScI)."
)

# A few well studied stars, so the app has something to offer without the
# student needing to know any KIC numbers. The published values come from
# the NASA Exoplanet Archive and are only used to check our own answers.
KNOWN_TARGETS = {
    "Kepler-8": {
        "kic": 6922244,
        "published_period_days": 3.52254,
        "published_depth_percent": 0.9,
        "note": "Hot Jupiter, deep transit. Easy. Good first test.",
    },
    "Kepler-10": {
        "kic": 11904151,
        "published_period_days": 0.837495,
        "published_depth_percent": 0.0152,
        "note": "Kepler-10b, the first rocky planet Kepler confirmed. Very shallow.",
    },
    "Kepler-186": {
        "kic": 8120608,
        "published_period_days": 129.9444,
        "published_depth_percent": 0.0459,
        "note": "Hosts Kepler-186f, an Earth-sized planet in the habitable zone.",
    },
}


class KeplerDataError(Exception):
    """Raised when a real light curve cannot be obtained."""


def _ssl_context():
    """A certificate bundle that works on a python.org macOS install."""
    try:
        import certifi
        return ssl.create_default_context(cafile=certifi.where())
    except ImportError:
        return ssl.create_default_context()


def _mast_request(service, params, timeout=120):
    """Send one request to the MAST Mashup API and return the parsed JSON."""
    request_json = json.dumps({"service": service, "format": "json",
                               "params": params})
    body = urllib.parse.urlencode({"request": request_json}).encode()

    request = urllib.request.Request(
        MAST_API,
        data=body,
        headers={
            "User-Agent": "exoplanet-transit-detector/1.0 (student project)",
            "Content-type": "application/x-www-form-urlencoded",
        },
    )

    with urllib.request.urlopen(request, timeout=timeout,
                                context=_ssl_context()) as response:
        return json.loads(response.read().decode())


def list_light_curve_files(kic, timeout=120):
    """
    Ask MAST which quarterly light-curve files exist for one star.
    Returns a list of dictionaries with a filename and a dataURI.
    """
    target = "kplr%09d" % int(kic)

    observations = _mast_request("Mast.Caom.Filtered", {
        "columns": "obsid,target_name,t_exptime",
        "filters": [
            {"paramName": "obs_collection", "values": ["Kepler"]},
            {"paramName": "dataproduct_type", "values": ["timeseries"]},
            {"paramName": "target_name", "values": [target]},
        ],
    }, timeout=timeout)

    rows = observations.get("data", [])
    if not rows:
        raise KeplerDataError(
            "MAST has no Kepler light curves for KIC " + str(kic) + "."
        )

    # Prefer long cadence (30 minutes). There is far more of it, and it is
    # plenty for finding transits.
    rows.sort(key=lambda r: -(r.get("t_exptime") or 0))
    obsid = str(rows[0]["obsid"])

    products = _mast_request("Mast.Caom.Products", {"obsid": obsid},
                             timeout=timeout)

    files = []
    for product in products.get("data", []):
        # "LLC" is a long-cadence light curve file.
        if product.get("productSubGroupDescription") == "LLC":
            files.append({
                "filename": product["productFilename"],
                "uri": product["dataURI"],
                "size_bytes": product.get("size"),
            })

    if not files:
        raise KeplerDataError(
            "No long-cadence light curve files found for KIC " + str(kic) + "."
        )

    files.sort(key=lambda f: f["filename"])
    return files


def download_light_curve_file(uri, filename, timeout=300):
    """
    Download one FITS file, or reuse the cached copy if we already have it.
    Returns the path on disk.
    """
    os.makedirs(CACHE_DIR, exist_ok=True)
    path = os.path.join(CACHE_DIR, filename)

    if os.path.exists(path) and os.path.getsize(path) > 0:
        return path

    request = urllib.request.Request(
        MAST_DOWNLOAD + uri,
        headers={"User-Agent": "exoplanet-transit-detector/1.0 (student project)"},
    )

    try:
        with urllib.request.urlopen(request, timeout=timeout,
                                    context=_ssl_context()) as response:
            data = response.read()
    except Exception as error:
        raise KeplerDataError(
            "Could not download " + filename + " from MAST: " + str(error)
        )

    with open(path, "wb") as handle:
        handle.write(data)

    return path


def read_light_curve_file(path, use_pdcsap=True, drop_flagged=True):
    """
    Read one Kepler FITS file into plain numpy arrays.

    Returns (time_days, flux, header_info). Bad cadences are removed:
      * NaN times or fluxes (gaps in the data)
      * cadences with a non-zero SAP_QUALITY flag, if drop_flagged is on

    Removing flagged cadences is the single most important cleaning step on
    real Kepler data. Thruster firings and cosmic rays leave spikes that any
    transit search will happily mistake for signal.
    """
    # Imported here so the rest of the project does not need astropy.
    from astropy.io import fits

    with fits.open(path) as hdulist:
        primary = hdulist[0].header
        table = hdulist[1].data

        times = np.array(table["TIME"], dtype=np.float64)
        column = "PDCSAP_FLUX" if use_pdcsap else "SAP_FLUX"
        flux = np.array(table[column], dtype=np.float64)
        quality = np.array(table["SAP_QUALITY"], dtype=np.int64)

        info = {
            "kepler_id": primary.get("KEPLERID"),
            "object": primary.get("OBJECT"),
            "quarter": primary.get("QUARTER"),
            "flux_column": column,
            "n_raw": int(len(times)),
        }

    good = np.isfinite(times) & np.isfinite(flux)
    if drop_flagged:
        good = good & (quality == 0)

    info["n_removed_nan"] = int((~(np.isfinite(times) & np.isfinite(flux))).sum())
    info["n_removed_flagged"] = int(((quality != 0) & np.isfinite(flux)).sum())
    info["n_used"] = int(good.sum())

    return times[good], flux[good], info


def get_light_curve(kic, max_quarters=2, timeout=300):
    """
    The convenience function the rest of the project uses.

    Downloads up to `max_quarters` quarterly files for one star, stitches
    them together and returns (time_days, flux, provenance).

    Each quarter is divided by its own median before stitching. Kepler's
    quarters have different absolute flux levels because the spacecraft
    rotated every three months and the star landed on a different detector,
    so joining them without normalising would create a huge artificial step.
    """
    files = list_light_curve_files(kic, timeout=timeout)
    chosen = files[:max_quarters]

    all_times = []
    all_flux = []
    quarters = []
    total_raw = 0
    total_nan = 0
    total_flagged = 0

    for entry in chosen:
        path = download_light_curve_file(entry["uri"], entry["filename"],
                                         timeout=timeout)
        times, flux, info = read_light_curve_file(path)

        if len(flux) < 100:
            continue

        # Normalise this quarter to its own median before stitching.
        median_flux = float(np.median(flux))
        if median_flux <= 0:
            continue

        all_times.append(times)
        all_flux.append(flux / median_flux)

        quarters.append({
            "filename": entry["filename"],
            "quarter": info["quarter"],
            "n_used": info["n_used"],
        })
        total_raw += info["n_raw"]
        total_nan += info["n_removed_nan"]
        total_flagged += info["n_removed_flagged"]

    if not all_times:
        raise KeplerDataError("No usable data for KIC " + str(kic) + ".")

    times = np.concatenate(all_times)
    flux = np.concatenate(all_flux)

    order = np.argsort(times)
    times = times[order]
    flux = flux[order]

    provenance = {
        "source": "MAST / NASA Kepler",
        "kic": int(kic),
        "files": quarters,
        "n_raw_cadences": total_raw,
        "n_removed_nan": total_nan,
        "n_removed_quality_flagged": total_flagged,
        "n_used": int(len(times)),
        "time_span_days": float(times.max() - times.min()),
        "cadence_minutes": float(np.median(np.diff(times)) * 24 * 60),
        "citation": KEPLER_CITATION,
        "downloaded_utc": time_module.strftime("%Y-%m-%dT%H:%M:%SZ",
                                               time_module.gmtime()),
        "note": "REAL telescope photometry, with real gaps and systematics.",
    }

    return times, flux, provenance
