"""
bls.py
------
Box Least Squares (BLS), written by hand with numpy.

BLS is the standard way to search a light curve for a repeating transit.
The idea is simple: a transit looks like a box cut out of a flat line, so
try every plausible combination of

    period  (how often the box repeats)
    phase   (where in the cycle the box sits)
    duration(how wide the box is)

and keep whichever box explains the most of the dip in the data.

Trying all three at once would be far too slow, so for each trial period we
fold the light curve - wrap it round so that every cycle lies on top of the
others - and then only have to search phase and duration in that folded
curve. Folding is done by binning, which makes each period cost almost
nothing.

There is no time column in our data, so "time" is just the index of the
measurement. Periods and durations are therefore in *cadences* (data
points), not in days.
"""

import numpy as np

# How many bins the folded light curve is chopped into. More bins means
# finer phase resolution but slower searching.
N_BINS = 200

# The narrowest and widest box we look for, as a fraction of the period.
# A real transit lasts roughly 1-10% of its orbit.
MIN_DURATION_FRACTION = 0.01
MAX_DURATION_FRACTION = 0.12


def bls_search(flattened, times=None, min_period=None, max_period=None,
               n_periods=1500):
    """
    Search a flattened light curve for a repeating box-shaped dip.

    Input:  flattened - output of detrend(), where 0 is the normal level
            times     - optional array of observation times. Give this for
                        real telescope data, where the points are unevenly
                        spaced and there are gaps. Leave it out for the
                        simulated CSVs and the index is used instead.
    Output: a dictionary describing the best box found, plus the power
            spectrum so it can be plotted.

    The units of `period` and `duration` in the result are whatever the
    units of `times` are: days for real Kepler data, cadences otherwise.
    """
    y = np.asarray(flattened, dtype=np.float64)
    n = len(y)

    if times is None:
        times = np.arange(n, dtype=np.float64)
    else:
        times = np.asarray(times, dtype=np.float64)
        if len(times) != n:
            raise ValueError("times and flattened must be the same length.")

    baseline = float(times.max() - times.min())

    if min_period is None:
        # Shortest period worth trying: long enough that a transit covers
        # several points, given how often the star was measured.
        cadence = float(np.median(np.diff(np.sort(times))))
        min_period = max(10.0 * cadence, baseline / 500.0)

    if max_period is None:
        # We need the transit to repeat at least twice inside the data,
        # so the longest period worth trying is half the total span.
        max_period = baseline / 2.0

    if max_period <= min_period or n < 50:
        raise ValueError("The light curve is too short to search for a period.")

    # BLS assumes the curve has zero mean. Subtracting the mean here means
    # the formula below measures the dip relative to the overall level.
    y = y - np.mean(y)

    # --- the grid of periods to try ---------------------------------------
    # Evenly spaced in frequency rather than period, because that spaces the
    # trials evenly in terms of how much the folded curve actually changes.
    frequencies = np.linspace(1.0 / max_period, 1.0 / min_period, n_periods)
    periods = 1.0 / frequencies

    # The widths of box to try, measured in bins of the folded curve.
    min_width = max(1, int(MIN_DURATION_FRACTION * N_BINS))
    max_width = max(min_width + 1, int(MAX_DURATION_FRACTION * N_BINS))
    widths = np.arange(min_width, max_width + 1)

    power = np.zeros(n_periods)

    best = {
        "power": -np.inf,
        "period": None,
        "duration": None,
        "depth": None,
        "t0": None,
    }

    # Measure phase from the first observation, so t0 comes out as a real
    # time rather than an offset from an arbitrary zero.
    time_origin = float(times.min())
    shifted_times = times - time_origin

    for index, period in enumerate(periods):
        # --- fold: which bin of the cycle does each point fall into? ------
        phase = np.mod(shifted_times, period) / period
        bin_index = np.minimum((phase * N_BINS).astype(np.int64), N_BINS - 1)

        # Total flux and number of points in each bin.
        bin_sum = np.bincount(bin_index, weights=y, minlength=N_BINS)
        bin_count = np.bincount(bin_index, minlength=N_BINS).astype(np.float64)

        # A transit can straddle the wrap-around point, so lay two copies of
        # the folded curve end to end and let the box slide across the join.
        doubled_sum = np.concatenate([bin_sum, bin_sum])
        doubled_count = np.concatenate([bin_count, bin_count])

        # Running totals let us add up any window in constant time.
        cumulative_sum = np.concatenate([[0.0], np.cumsum(doubled_sum)])
        cumulative_count = np.concatenate([[0.0], np.cumsum(doubled_count)])

        total_count = float(n)

        best_power_here = 0.0
        best_width_here = 0
        best_start_here = 0
        best_in_sum = 0.0
        best_in_count = 0.0

        for width in widths:
            # Sum inside every possible window of this width, all at once.
            in_sum = cumulative_sum[width:width + N_BINS] - cumulative_sum[:N_BINS]
            in_count = cumulative_count[width:width + N_BINS] - cumulative_count[:N_BINS]
            out_count = total_count - in_count

            # A window is only usable if it has points inside and outside.
            usable = (in_count > 0) & (out_count > 0)
            if not np.any(usable):
                continue

            # The BLS signal residue. Because y has zero mean this reduces
            # to a very short formula. A deep box covering few points scores
            # highly; a shallow box covering half the curve does not.
            residue = np.zeros(N_BINS)
            residue[usable] = (in_sum[usable] ** 2) / (in_count[usable] * out_count[usable])

            peak = int(np.argmax(residue))
            if residue[peak] > best_power_here:
                best_power_here = float(residue[peak])
                best_width_here = int(width)
                best_start_here = peak
                best_in_sum = float(in_sum[peak])
                best_in_count = float(in_count[peak])

        power[index] = best_power_here

        if best_power_here > best["power"]:
            # Convert the winning bin window back into real units.
            in_mean = best_in_sum / best_in_count
            out_mean = (0.0 - best_in_sum) / (total_count - best_in_count)

            best = {
                "power": best_power_here,
                "period": float(period),
                "duration": float(best_width_here / N_BINS * period),
                "depth": float(out_mean - in_mean),
                # The middle of the transit, in the same units as `times`.
                "t0": float(time_origin
                            + (best_start_here + best_width_here / 2.0)
                            / N_BINS * period),
            }

    # --- how convincing is the winning peak? ------------------------------
    # SDE (signal detection efficiency) asks how far the peak sticks out of
    # the rest of the spectrum. A real transit gives a lone tall spike; noise
    # gives a spectrum of similar-sized bumps.
    spectrum_mean = float(np.mean(power))
    spectrum_std = float(np.std(power))
    if spectrum_std > 0:
        sde = (best["power"] - spectrum_mean) / spectrum_std
    else:
        sde = 0.0

    best["sde"] = float(sde)
    best["periods"] = periods
    best["power_spectrum"] = power

    return best


def fold(flattened, period, t0=0.0, times=None):
    """
    Wrap a light curve onto one cycle of the given period.

    Returns (phase, flux) sorted by phase, where phase runs -0.5 to +0.5 and
    0 is the middle of the transit. Useful for drawing the folded curve.
    """
    y = np.asarray(flattened, dtype=np.float64)
    if times is None:
        times = np.arange(len(y), dtype=np.float64)
    else:
        times = np.asarray(times, dtype=np.float64)

    phase = np.mod(times - t0 + period / 2.0, period) / period - 0.5

    order = np.argsort(phase)
    return phase[order], y[order]
