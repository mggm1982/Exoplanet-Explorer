/* ------------------------------------------------------------------
   main.js - all the browser-side code for the Exoplanet Transit Detector.

   Three jobs:
     1. switch between the two tabs
     2. send the uploaded file to the server and show the answer
     3. draw the light-curve charts with Chart.js
   ------------------------------------------------------------------ */

/* Chart colours. These match the CSS variables in style.css, but Chart.js
   draws onto a canvas and cannot read CSS variables, so they are repeated
   here. If you change the palette, change both places. */
const CHART_ACCENT = "#FF9B66";              /* the bright orange line */
const CHART_FAINT  = "rgba(180, 172, 214, 0.55)";  /* the raw, noisy line */
const CHART_DIM    = "#B4ACD6";              /* axis labels */
const CHART_GRID   = "rgba(58, 47, 107, 0.7)"; /* grid lines */
const DIP_SHADE    = "rgba(251, 191, 36, 0.20)"; /* amber band behind a dip */

// Chart objects are stored here so we can destroy the old chart before
// drawing a new one. Chart.js complains if we reuse a canvas otherwise.
let csvChart = null;
let videoChart = null;

// The results of the last CSV upload, kept so the star picker can redraw.
let csvData = null;


/* ============================== TABS ============================== */

document.querySelectorAll(".tab-button").forEach(function (button) {
  button.addEventListener("click", function () {
    const wanted = button.dataset.tab;

    // Highlight the clicked button and un-highlight the others.
    document.querySelectorAll(".tab-button").forEach(function (other) {
      other.classList.toggle("active", other === button);
    });

    // Show the matching panel and hide the others.
    ["csv", "research", "composition"].forEach(function (name) {
      const panel = document.getElementById("tab-" + name);
      if (panel) {
        panel.hidden = (name !== wanted);
      }
    });
  });
});


/* ========================= DRAG AND DROP ========================== */

/**
 * Wire up one dropzone: clicking it opens the file picker, and a file can
 * also be dragged onto it. Calls onFile(file) when a file arrives.
 */
function setupDropzone(zoneId, inputId, onFile) {
  const zone = document.getElementById(zoneId);
  const input = document.getElementById(inputId);

  // Click the box -> open the normal file chooser.
  zone.addEventListener("click", function () {
    input.click();
  });

  input.addEventListener("change", function () {
    if (input.files.length > 0) {
      onFile(input.files[0]);
    }
  });

  // Dragging a file over the box highlights it.
  zone.addEventListener("dragover", function (event) {
    event.preventDefault();
    zone.classList.add("dragover");
  });

  zone.addEventListener("dragleave", function () {
    zone.classList.remove("dragover");
  });

  zone.addEventListener("drop", function (event) {
    event.preventDefault();
    zone.classList.remove("dragover");
    if (event.dataTransfer.files.length > 0) {
      onFile(event.dataTransfer.files[0]);
    }
  });
}


/* ========================= STATUS MESSAGES ======================== */

/**
 * Show the thinking sphere with a message while the server works.
 * The sphere itself is built entirely in CSS, so all we do here is
 * put the right boxes on the page. See style.css for the animation.
 */
function showLoading(elementId, title, detail) {
  const element = document.getElementById(elementId);
  element.className = "status";
  element.innerHTML =
    "<div class='thinking'>" +
      "<div class='sphere'>" +
        "<div class='sphere-halo'></div>" +
        "<div class='sphere-core'></div>" +
        "<div class='sphere-ring ring-1'></div>" +
        "<div class='sphere-ring ring-2'></div>" +
        "<div class='sphere-ring ring-3'></div>" +
      "</div>" +
      "<div class='thinking-text'>" +
        "<p class='thinking-title'>" + escapeHtml(title) + "</p>" +
        "<p class='thinking-sub'>" + escapeHtml(detail) + "</p>" +
      "</div>" +
    "</div>";
}

function showError(elementId, message) {
  const element = document.getElementById(elementId);
  element.className = "status error";
  // textContent also wipes the thinking sphere that was there before.
  element.textContent = message;
}

function clearStatus(elementId) {
  const element = document.getElementById(elementId);
  element.className = "status";
  element.textContent = "";
}


/* =========================== CSV TAB ============================== */

setupDropzone("csv-dropzone", "csv-input", uploadCsv);

// Ask the server which light-curve models are loaded and fill the dropdown.
// The server's default (real, if that model exists) is selected.
async function fillModelPicker() {
  const names = {
    real: "Trained on real Kepler/K2 data (Kaggle)",
    simulated: "Trained on simulated data (1500 points)",
  };
  try {
    const response = await fetch("/health");
    const health = await response.json();
    const picker = document.getElementById("csv-model");
    picker.innerHTML = "";
    (health.lightcurve_models || ["simulated"]).forEach(function (name) {
      const option = document.createElement("option");
      option.value = name;
      option.textContent = names[name] || name;
      picker.appendChild(option);
    });
    picker.value = health.default_lightcurve_model || "simulated";
  } catch (problem) {
    // Keep the built-in "simulated" option if the server cannot be reached.
  }
}
fillModelPicker();

/*
 * The upload animation in the banner. It has three looks:
 *   uploading  - a real progress bar (the browser reports how many bytes are sent)
 *   analysing  - the file has arrived; a planet crosses a star while the server
 *                cleans the curves and runs the CNN (no percentage exists, so the
 *                bar shimmers and the step text changes every 1.5 s)
 *   done       - a green full bar and how many stars were analysed
 */
function showUploadAnimation(elementId, fileName, fileSize) {
  const element = document.getElementById(elementId);
  element.className = "status";
  element.innerHTML =
    "<div class='upload-anim uploading'>" +
      "<div class='ua-transit'><div class='ua-star'></div><div class='ua-planet'></div></div>" +
      "<div class='ua-text'>" +
        "<p class='ua-title'>Uploading " + escapeHtml(fileName) + "</p>" +
        "<p class='ua-sub'>0% of " + formatMegabytes(fileSize) + "</p>" +
        "<div class='ua-bar'><div class='ua-fill'></div></div>" +
        "<svg class='ua-curve' viewBox='0 0 120 34' aria-hidden='true'>" +
          "<path d='M0 8 H44 L50 26 H70 L76 8 H120'></path></svg>" +
      "</div>" +
    "</div>";

  const box = element.querySelector(".upload-anim");
  const title = element.querySelector(".ua-title");
  const sub = element.querySelector(".ua-sub");
  const fill = element.querySelector(".ua-fill");
  let stepTimer = null;

  return {
    progress: function (loaded, total) {
      const percent = Math.round(100 * loaded / total);
      fill.style.width = percent + "%";
      sub.textContent = percent + "% of " + formatMegabytes(total);
    },
    analysing: function () {
      box.className = "upload-anim analysing";
      title.textContent = "Looking for transits...";
      const steps = [
        "Cleaning each light curve (5 steps)",
        "Running the 1-D neural network",
        "Scoring every star",
      ];
      let i = 0;
      sub.textContent = steps[0];
      stepTimer = setInterval(function () {
        i = (i + 1) % steps.length;
        sub.textContent = steps[i];
      }, 1500);
    },
    done: function (starCount) {
      clearInterval(stepTimer);
      box.className = "upload-anim done";
      title.textContent = "Done - " + starCount + " stars analysed";
      sub.textContent = "Results are below";
    },
    stop: function () {
      clearInterval(stepTimer);
    },
  };
}

function formatMegabytes(bytes) {
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

/*
 * Send the CSV to the server. XMLHttpRequest is used instead of fetch()
 * only because it reports upload progress, which drives the progress bar.
 */
function uploadCsv(file) {
  document.getElementById("csv-results").hidden = true;

  // The upload box is in the banner; make sure the CSV results tab is the
  // one showing below it, even if the Research tab was open.
  document.querySelector('.tab-button[data-tab="csv"]').click();

  const anim = showUploadAnimation("csv-status", file.name, file.size);

  const form = new FormData();
  form.append("file", file);
  form.append("model", document.getElementById("csv-model").value);

  return new Promise(function (resolve) {
    const request = new XMLHttpRequest();
    request.open("POST", "/api/predict-csv");

    request.upload.onprogress = function (event) {
      if (event.lengthComputable) {
        anim.progress(event.loaded, event.total);
      }
    };
    // Every byte has been sent: now the server is doing the work.
    request.upload.onload = function () {
      anim.analysing();
    };

    request.onload = function () {
      let data = {};
      try {
        data = JSON.parse(request.responseText);
      } catch (problem) {
        data = { error: "The server sent back something unexpected." };
      }
      // The server sends {"error": "..."} when something is wrong.
      if (request.status !== 200 || data.error) {
        anim.stop();
        showError("csv-status", data.error || "The server could not read that file.");
        resolve();
        return;
      }
      anim.done(data.results.length);
      csvData = data;
      showCsvResults(data);
      resolve();
    };

    request.onerror = function () {
      anim.stop();
      showError("csv-status", "Could not reach the server. Is it still running?");
      resolve();
    };

    request.send(form);
  });
}

function showCsvResults(data) {
  document.getElementById("csv-results").hidden = false;
  document.getElementById("csv-empty").hidden = true;

  // The results are below the banner, so scroll down to them (after a
  // short pause, so the green "Done" message in the banner can be seen).
  setTimeout(function () {
    document.getElementById("tools").scrollIntoView({ behavior: "smooth" });
  }, 700);

  // --- the one-line summary above the chart --------------------------
  let planetCount = 0;
  data.results.forEach(function (row) {
    if (row.verdict === "Planet likely") {
      planetCount += 1;
    }
  });

  // Always say which model produced these numbers.
  document.getElementById("csv-model-label").textContent =
    "Model trained on: " + data.model_trained_on +
    " (expects " + data.model_length + " points per star)";

  document.getElementById("csv-summary").innerHTML =
    "<span>File: <b>" + escapeHtml(data.filename) + "</b></span>" +
    "<span>Stars: <b>" + data.n_stars + "</b></span>" +
    "<span>Flux columns: <b>" + data.n_flux_columns + "</b></span>" +
    "<span>Planet likely: <b>" + planetCount + "</b></span>";

  // --- fill the table ------------------------------------------------
  const body = document.querySelector("#csv-table tbody");
  body.innerHTML = "";

  data.results.forEach(function (row) {
    const tr = document.createElement("tr");

    // Turn the numeric label into words.
    let labelText = "-";
    if (row.true_label === 2) {
      labelText = "Planet";
    } else if (row.true_label === 1) {
      labelText = "No planet";
    }

    // Mark rows where the model disagrees with the true label.
    if (row.true_label === 2 && row.probability < 0.5) {
      tr.className = "mismatch";
    }
    if (row.true_label === 1 && row.probability >= 0.5) {
      tr.className = "mismatch";
    }

    tr.innerHTML =
      "<td>Star " + row.star_index + "</td>" +
      "<td>" + row.probability.toFixed(4) + "</td>" +
      "<td><span class='pill " + pillClassForVerdict(row.verdict) + "'>" +
        row.verdict + "</span></td>" +
      "<td>" + labelText + "</td>";

    // Clicking a row shows that star in the chart.
    tr.style.cursor = "pointer";
    tr.addEventListener("click", function () {
      document.getElementById("csv-star-picker").value = row.star_index;
      drawCsvChart(row.star_index);
    });

    body.appendChild(tr);
  });

  // --- fill the star picker ------------------------------------------
  const picker = document.getElementById("csv-star-picker");
  picker.innerHTML = "";

  data.results.forEach(function (row) {
    const option = document.createElement("option");
    option.value = row.star_index;
    option.textContent = "Star " + row.star_index +
      "  (p = " + row.probability.toFixed(3) + ")";
    picker.appendChild(option);
  });

  picker.onchange = function () {
    drawCsvChart(parseInt(picker.value, 10));
  };

  // Show the first star to begin with.
  drawCsvChart(data.results[0].star_index);
}

function pillClassForVerdict(verdict) {
  if (verdict === "Planet likely") {
    return "pill-good";
  }
  if (verdict === "Borderline") {
    return "pill-unsure";
  }
  return "pill-bad";
}

function drawCsvChart(starIndex) {
  // Find the star that was asked for.
  let star = null;
  csvData.results.forEach(function (row) {
    if (row.star_index === starIndex) {
      star = row;
    }
  });
  if (star === null) {
    return;
  }

  // Chart.js needs an x value for every y value.
  const xValues = star.curve.map(function (value, index) {
    return index;
  });

  if (csvChart !== null) {
    csvChart.destroy();
  }

  csvChart = new Chart(document.getElementById("csv-chart"), {
    type: "line",
    data: {
      labels: xValues,
      datasets: [{
        label: "Star " + star.star_index + " (cleaned flux)",
        data: star.curve,
        borderColor: CHART_ACCENT,
        borderWidth: 1,
        pointRadius: 0,
        tension: 0,
      }],
    },
    options: baseChartOptions("Time step", "Cleaned flux"),
  });
}


/* ========================= SHARED HELPERS ========================= */

/** The Chart.js settings that both charts share. */
function baseChartOptions(xTitle, yTitle) {
  return {
    responsive: true,
    maintainAspectRatio: false,
    animation: false,
    interaction: { intersect: false, mode: "index" },
    plugins: {
      legend: { display: false },
    },
    scales: {
      x: {
        type: "linear",
        title: { display: true, text: xTitle, color: CHART_DIM },
        ticks: { color: CHART_DIM, maxTicksLimit: 10 },
        grid: { color: CHART_GRID },
      },
      y: {
        title: { display: true, text: yTitle, color: CHART_DIM },
        ticks: { color: CHART_DIM },
        grid: { color: CHART_GRID },
      },
    },
  };
}

/** Escape text before putting it inside HTML, so a file name cannot break the page. */
function escapeHtml(text) {
  const holder = document.createElement("div");
  holder.textContent = text === null || text === undefined ? "" : String(text);
  return holder.innerHTML;
}


/* ========================== RESEARCH TAB ==========================
   Three studies that run on real NASA data. Each one loads from its own
   endpoint and draws its own summary. See research/ for the science.
   ================================================================== */

let idea1Chart = null;
let idea2Chart = null;
let idea3Chart = null;

// Earth crossing the Sun blocks 0.0084% of its light. It is the standard
// yardstick for "how good is this pipeline really".
const EARTH_DEPTH_PERCENT = 0.0084;


/* ---------------------------- data sources ---------------------------- */

document.getElementById("run-sources").addEventListener("click", async function () {
  showLoading("sources-status", "Thinking...", "Collecting data provenance");
  try {
    const response = await fetch("/api/research/sources");
    const data = await response.json();
    if (!response.ok || data.error) {
      showError("sources-status", data.error || "Could not load the sources.");
      return;
    }
    clearStatus("sources-status");

    let html = "<div class='summary'><b>Real data</b></div>";
    data.real_sources.forEach(function (source) {
      html +=
        "<div class='source-card'>" +
          "<h4>" + escapeHtml(source.name) + "</h4>" +
          "<p>" + escapeHtml(source.what) + "</p>" +
          "<p class='source-meta'>Used for: " + escapeHtml(source.used_for) + "</p>" +
          "<p class='source-meta'>Endpoint: <code>" + escapeHtml(source.endpoint) + "</code></p>" +
          "<p class='source-cite'>" + escapeHtml(source.citation) + "</p>" +
        "</div>";
    });

    html += "<div class='summary' style='margin-top:18px'><b>Simulated data (in this folder)</b></div>";
    data.simulated_sources.forEach(function (source) {
      html +=
        "<div class='source-card simulated'>" +
          "<h4>" + escapeHtml(source.filename) + " <span class='pill pill-unsure'>simulated</span></h4>" +
          "<p>" + escapeHtml(source.description) + "</p>" +
          "<p class='source-meta'>" + escapeHtml(source.origin) + "</p>" +
        "</div>";
    });

    html += "<div class='warning' style='margin-top:18px'>" +
            escapeHtml(data.warning) + "</div>";

    const box = document.getElementById("sources-out");
    box.hidden = false;
    box.innerHTML = html;
  } catch (problem) {
    showError("sources-status", "Could not reach the server.");
  }
});


/* ------------------------------- idea 1 ------------------------------- */

document.getElementById("run-idea1").addEventListener("click", async function () {
  showLoading("idea1-status", "Thinking...",
              "Loading the injection-recovery experiment");
  try {
    const response = await fetch("/api/research/idea1");
    const data = await response.json();
    if (!response.ok || data.error) {
      showError("idea1-status", data.error || "Could not load the experiment.");
      return;
    }
    clearStatus("idea1-status");
    showIdea1(data);
  } catch (problem) {
    showError("idea1-status", "Could not reach the server.");
  }
});

function showIdea1(data) {
  document.getElementById("idea1-out").hidden = false;

  const host = data.host;
  const provenance = data.host_provenance || {};
  document.getElementById("idea1-summary").innerHTML =
    "<span>Host star: <b>KIC " + (provenance.kic || "?") + "</b> (real Kepler)</span>" +
    "<span>Points: <b>" + host.n_points + "</b></span>" +
    "<span>Baseline: <b>" + host.baseline_days + " d</b></span>" +
    "<span>Noise: <b>" + host.noise_percent + "%</b></span>" +
    "<span>Injections per cell: <b>" + data.settings.n_trials_per_depth + "</b></span>";

  // --- the table ---
  const body = document.querySelector("#idea1-table tbody");
  body.innerHTML = "";
  Object.keys(data.methods).forEach(function (name) {
    const method = data.methods[name];
    const deepest = method.by_depth[0];
    const tr = document.createElement("tr");
    tr.innerHTML =
      "<td>" + name + "</td>" +
      "<td>" + (method.sensitivity_limit_percent !== null
                ? method.sensitivity_limit_percent + "%" : "not reached") + "</td>" +
      "<td>" + Math.round(method.false_alarm.false_alarm_rate * 100) + "%</td>" +
      "<td>" + method.false_alarm.median_null_sde + "</td>" +
      "<td>" + (deepest.median_depth_preserved !== null
                ? deepest.median_depth_preserved : "-") + "</td>";
    body.appendChild(tr);
  });

  // --- the chart ---
  const colours = {
    none: "#B4ACD6", median: "#FF9B66", savgol: "#5AA9FF", wavelet: "#FBBF24",
  };
  // The depths actually tested, smallest first, used for the axis labels.
  const firstMethod = data.methods[Object.keys(data.methods)[0]];
  const testedDepths = firstMethod.by_depth
    .map(function (entry) { return entry.depth_percent; })
    .sort(function (a, b) { return a - b; });

  const datasets = Object.keys(data.methods).map(function (name) {
    return {
      label: name,
      data: data.methods[name].by_depth.map(function (entry) {
        return { x: entry.depth_percent, y: entry.recovery_rate * 100 };
      }),
      borderColor: colours[name] || CHART_ACCENT,
      backgroundColor: colours[name] || CHART_ACCENT,
      borderWidth: 2,
      pointRadius: 3,
      tension: 0.1,
    };
  });

  if (idea1Chart !== null) { idea1Chart.destroy(); }
  idea1Chart = new Chart(document.getElementById("idea1-chart"), {
    type: "line",
    data: { datasets: datasets },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      plugins: {
        legend: { display: true, labels: { color: CHART_DIM, boxWidth: 14 } },
        earthLine: {},
      },
      scales: {
        x: {
          type: "logarithmic",
          title: { display: true, text: "Injected transit depth (%)", color: CHART_DIM },
          // Chart.js puts its own ticks on a log axis and they collide at
          // the crowded end. We only ever tested a handful of depths, so
          // label exactly those and nothing else.
          afterBuildTicks: function (axis) {
            axis.ticks = testedDepths.map(function (depth) {
              return { value: depth };
            });
          },
          ticks: {
            color: CHART_DIM,
            autoSkip: false,
            callback: function (value) { return value + "%"; },
          },
          grid: { color: CHART_GRID },
        },
        y: {
          min: 0, max: 105,
          title: { display: true, text: "Recovered (%)", color: CHART_DIM },
          ticks: { color: CHART_DIM },
          grid: { color: CHART_GRID },
        },
      },
    },
    plugins: [earthLinePlugin],
  });
}

/* Draws the dashed "Earth across the Sun" marker on the Idea 1 chart. */
const earthLinePlugin = {
  id: "earthLine",
  afterDatasetsDraw: function (chart) {
    const xAxis = chart.scales.x;
    const area = chart.chartArea;
    const x = xAxis.getPixelForValue(EARTH_DEPTH_PERCENT);
    if (x < area.left || x > area.right) { return; }

    const pen = chart.ctx;
    pen.save();
    pen.setLineDash([5, 4]);
    pen.strokeStyle = "rgba(251, 191, 36, 0.8)";
    pen.lineWidth = 1.5;
    pen.beginPath();
    pen.moveTo(x, area.top);
    pen.lineTo(x, area.bottom);
    pen.stroke();
    pen.setLineDash([]);
    pen.fillStyle = "rgba(251, 191, 36, 0.9)";
    pen.font = "11px sans-serif";
    pen.fillText("Earth", x + 4, area.top + 12);
    pen.restore();
  },
};


/* ------------------------------- idea 2 ------------------------------- */

document.getElementById("run-idea2").addEventListener("click", async function () {
  showLoading("idea2-status", "Thinking...",
              "Training on real Kepler Objects of Interest");
  try {
    const response = await fetch("/api/research/idea2");
    const data = await response.json();
    if (!response.ok || data.error) {
      showError("idea2-status", data.error || "Could not run the study.");
      return;
    }
    clearStatus("idea2-status");
    showIdea2(data);
  } catch (problem) {
    showError("idea2-status", "Could not reach the server.");
  }
});

function showIdea2(data) {
  document.getElementById("idea2-out").hidden = false;

  const set = data.dataset;
  document.getElementById("idea2-summary").innerHTML =
    "<span>Real signals: <b>" + set.n_labelled_signals + "</b></span>" +
    "<span>Confirmed: <b>" + set.n_confirmed + "</b></span>" +
    "<span>False positives: <b>" + set.n_false_positive + "</b></span>" +
    "<span>Test set: <b>" + set.n_test + "</b> signals / " + set.n_test_stars + " stars</span>" +
    "<span>Threshold: <b>" + data.threshold + "</b></span>";

  const labels = {
    rules_only: "Physical rules only",
    model_only: "Learned model only",
    two_stage: "Two-stage (rules + model)",
    official_kepler_flags: "Official Kepler flags (reference)",
  };

  const body = document.querySelector("#idea2-table tbody");
  body.innerHTML = "";
  Object.keys(data.results).forEach(function (key) {
    const r = data.results[key];
    const tr = document.createElement("tr");
    if (key === "two_stage") { tr.style.fontWeight = "600"; }
    tr.innerHTML =
      "<td>" + (labels[key] || key) + "</td>" +
      "<td>" + r.precision.toFixed(3) + "</td>" +
      "<td>" + r.recall.toFixed(3) + "</td>" +
      "<td>" + r.fp_rejection_rate.toFixed(3) + "</td>" +
      "<td>" + r.accuracy.toFixed(3) + "</td>" +
      "<td>" + r.confusion.planets_lost + "</td>";
    body.appendChild(tr);
  });

  const weights = data.feature_weights;
  if (idea2Chart !== null) { idea2Chart.destroy(); }
  idea2Chart = new Chart(document.getElementById("idea2-chart"), {
    type: "bar",
    data: {
      labels: weights.map(function (w) { return w.feature; }),
      datasets: [{
        data: weights.map(function (w) { return w.weight; }),
        backgroundColor: weights.map(function (w) {
          return w.weight >= 0 ? "#4ADE80" : "#F87171";
        }),
      }],
    },
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      animation: false,
      plugins: { legend: { display: false } },
      scales: {
        x: { title: { display: true, text: "weight", color: CHART_DIM },
             ticks: { color: CHART_DIM }, grid: { color: CHART_GRID } },
        y: { ticks: { color: CHART_DIM }, grid: { display: false } },
      },
    },
  });
}


/* ------------------------------- idea 3 ------------------------------- */

setupDropzone("idea3-dropzone", "idea3-input", uploadIdea3);

async function uploadIdea3(file) {
  document.getElementById("idea3-out").hidden = true;
  showLoading("idea3-status", "Thinking...",
              "Sliding transit templates along " + file.name);

  const form = new FormData();
  form.append("file", file);
  form.append("detrend_method", "median");

  try {
    const response = await fetch("/api/research/idea3", {
      method: "POST", body: form,
    });
    const data = await response.json();
    if (!response.ok || data.error) {
      showError("idea3-status", data.error || "Could not search that file.");
      return;
    }
    clearStatus("idea3-status");
    showIdea3(data);
  } catch (problem) {
    showError("idea3-status", "Could not reach the server.");
  }
}

function showIdea3(data) {
  document.getElementById("idea3-out").hidden = false;

  document.getElementById("idea3-summary").innerHTML =
    "<span>File: <b>" + escapeHtml(data.filename) + "</b></span>" +
    "<span>Points: <b>" + data.n_points + "</b></span>" +
    "<span>Candidates: <b>" + data.n_candidates + "</b></span>" +
    "<span>Detrending: <b>" + escapeHtml(data.detrend_method) + "</b></span>";

  // cards, one per candidate
  let html = "";
  if (data.candidates.length === 0) {
    html = "<div class='summary'>No single-transit candidates found.</div>";
  }
  data.candidates.forEach(function (candidate, index) {
    let cls = "verdict-unsure";
    if (candidate.verdict.indexOf("Promising") === 0) { cls = "verdict-good"; }
    if (candidate.verdict.indexOf("Probably not") === 0) { cls = "verdict-bad"; }

    let caveats = "";
    candidate.caveats.forEach(function (reason) {
      caveats += "<li>" + escapeHtml(reason) + "</li>";
    });

    html +=
      "<div class='verdict-box " + cls + "'>" +
        "<h2>#" + (index + 1) + " &middot; " + escapeHtml(candidate.verdict) +
          " <span class='score'>score " + candidate.score + "</span></h2>" +
        "<div class='summary' style='margin-top:10px'>" +
          "<span>At point: <b>" + Math.round(candidate.time) + "</b></span>" +
          "<span>Depth: <b>" + candidate.depth_percent.toFixed(4) + "%</b></span>" +
          "<span>SNR: <b>" + candidate.snr.toFixed(1) + "</b></span>" +
          "<span>Duration: <b>" + candidate.duration.toFixed(0) + " " +
            escapeHtml(data.duration_units || "") + "</b></span>" +
          "<span>Rp/Rs: <b>" + candidate.radius_ratio.toFixed(3) + "</b></span>" +
          "<span>Shape: <b>" + candidate.shape_score + "</b></span>" +
          "<span>Symmetry: <b>" + candidate.symmetry + "</b></span>" +
        "</div>" +
        "<p class='period-note'>" + escapeHtml(candidate.period_note) + "</p>" +
        (caveats ? "<ul class='caveats'>" + caveats + "</ul>" : "") +
      "</div>";
  });
  document.getElementById("idea3-cards").innerHTML = html;

  // the curve, with each candidate marked
  if (idea3Chart !== null) { idea3Chart.destroy(); }
  idea3Chart = new Chart(document.getElementById("idea3-chart"), {
    type: "line",
    data: {
      labels: data.curve.map(function (value, index) { return index; }),
      datasets: [{
        label: "Detrended flux",
        data: data.curve,
        borderColor: CHART_ACCENT,
        borderWidth: 1,
        pointRadius: 0,
      }],
    },
    options: Object.assign(
      baseChartOptions("Data point", "Relative brightness"),
      { plugins: { legend: { display: false },
                   markCandidates: { candidates: data.candidates } } }
    ),
    plugins: [markCandidatesPlugin],
  });
}

/* Shades where each single-transit candidate was found. */
const markCandidatesPlugin = {
  id: "markCandidates",
  beforeDatasetsDraw: function (chart, args, options) {
    const candidates = (options && options.candidates) || [];
    const xAxis = chart.scales.x;
    const area = chart.chartArea;
    const pen = chart.ctx;

    pen.save();
    candidates.forEach(function (candidate) {
      // duration is already in the same units as the x axis.
      const halfWidth = candidate.duration / 2;
      const left = xAxis.getPixelForValue(candidate.time - halfWidth);
      const right = xAxis.getPixelForValue(candidate.time + halfWidth);
      const width = Math.max(right - left, 3);

      pen.fillStyle = candidate.verdict.indexOf("Promising") === 0
        ? "rgba(255, 155, 102, 0.25)" : "rgba(251, 191, 36, 0.22)";
      pen.fillRect(left, area.top, width, area.bottom - area.top);
    });
    pen.restore();
  },
};


/* ======================= SCROLL ANIMATIONS ======================== */

/*
 * Sections, cards and figures slide in the first time they scroll into
 * view. The .reveal class is added here (not in the HTML) so that, if
 * JavaScript is off, nothing stays invisible.
 */
(function () {
  const targets = document.querySelectorAll(
    ".site-section > .eyebrow, .site-section > h2, .site-section > .lead, " +
    ".card, .stat, .figures figure, .honest, .tools-title"
  );
  if (!("IntersectionObserver" in window)) {
    return;
  }
  const observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        const element = entry.target;
        element.classList.add("in");
        observer.unobserve(element);
        // Once it has arrived, drop the delay so hover effects feel instant.
        setTimeout(function () { element.style.transitionDelay = ""; }, 1200);
      }
    });
  }, { threshold: 0.15 });

  targets.forEach(function (element, index) {
    element.classList.add("reveal");
    // Cards in the same row arrive one after another.
    element.style.transitionDelay = ((index % 4) * 0.08) + "s";
    observer.observe(element);
  });
})();


/* ===================== MOLECULAR COMPOSITION TAB ===================== */

let compChart = null;

// Colours for the band strips and pills, by verdict.
const VERDICT_STYLE = {
  "Strong feature":   { pill: "pill-good",   band: "rgba(255, 122, 61, 0.30)" },
  "Possible feature": { pill: "pill-unsure", band: "rgba(251, 191, 36, 0.22)" },
  "No feature":       { pill: "pill-muted",  band: "rgba(180, 172, 214, 0.12)" },
  "Not covered":      { pill: "pill-muted",  band: null },
  "Not enough data":  { pill: "pill-muted",  band: null },
};

setupDropzone("comp-dropzone", "comp-input", function (file) {
  const form = new FormData();
  form.append("file", file);
  runComposition(fetch("/api/composition", { method: "POST", body: form }),
                 "Reading " + file.name);
});

// One button per bundled example spectrum.
(async function () {
  try {
    const data = await (await fetch("/api/composition/examples")).json();
    const row = document.getElementById("comp-examples");
    data.examples.forEach(function (example) {
      const button = document.createElement("button");
      button.className = "chip";
      button.textContent = example.label;
      button.addEventListener("click", function () {
        runComposition(fetch("/api/composition/example/" + example.id), example.label);
      });
      row.appendChild(button);
    });
  } catch (problem) {
    // The examples are optional; the upload box still works.
  }
})();

async function runComposition(request, detail) {
  document.getElementById("comp-results").hidden = true;
  showLoading("comp-status", "Checking absorption bands...", detail);
  try {
    const response = await request;
    const data = await response.json();
    if (!response.ok || data.error) {
      showError("comp-status", data.error || "The server could not read that spectrum.");
      return;
    }
    clearStatus("comp-status");
    showComposition(data);
  } catch (problem) {
    showError("comp-status", "Could not reach the server. Is it still running?");
  }
}

function formatSigma(value) {
  return (value === null || value === undefined) ? "-" : value.toFixed(1) + " σ";
}

function showComposition(data) {
  document.getElementById("comp-results").hidden = false;

  const strong = data.molecules.filter(function (m) { return m.verdict === "Strong feature"; });
  document.getElementById("comp-summary").innerHTML =
    "<b>" + escapeHtml(data.filename) + "</b> &middot; " + data.n_points + " points, " +
    data.range_um[0].toFixed(2) + "&ndash;" + data.range_um[1].toFixed(2) + " µm &middot; noise " +
    data.noise_per_point.toPrecision(2) + " (" + escapeHtml(data.noise_source) + ")<br>" +
    "<span class='comp-headline'>" + escapeHtml(data.summary) + "</span>" +
    (data.data_warning ? "<br><span class='comp-warning'>" + escapeHtml(data.data_warning) + "</span>" : "");

  // One card per molecule.
  const grid = document.getElementById("comp-molecules");
  grid.innerHTML = "";
  data.molecules.forEach(function (m, index) {
    const style = VERDICT_STYLE[m.verdict] || VERDICT_STYLE["No feature"];
    const card = document.createElement("div");
    card.className = "molecule-card" + (m.verdict === "Strong feature" ? " strong" : "");
    card.style.animationDelay = (index * 0.06) + "s";
    card.innerHTML =
      "<div class='mol-top'><span class='mol-formula'>" + escapeHtml(m.molecule) + "</span>" +
      "<span class='pill " + style.pill + "'>" + escapeHtml(m.verdict) + "</span></div>" +
      "<p class='mol-name'>" + escapeHtml(m.name) + "</p>" +
      "<p class='mol-stat'>" + (m.significance === null ? "Band at " + m.best_band_um + " µm" :
        formatSigma(m.significance) + " at " + m.best_band_um + " µm") + "</p>" +
      (m.note && (m.verdict === "Strong feature" || m.verdict === "Possible feature") ? "<p class='mol-note'>" + escapeHtml(m.note) + "</p>" : "");
    grid.appendChild(card);
  });
  document.getElementById("comp-caveat").textContent = data.caveat;

  drawCompositionChart(data);
}

function drawCompositionChart(data) {
  // Every band strip to shade, with its colour.
  const strips = [];
  data.molecules.forEach(function (m) {
    m.bands.forEach(function (band) {
      const style = VERDICT_STYLE[band.verdict];
      if (band.covered && style && style.band) {
        strips.push({ from: band.centre_um - band.half_width_um,
                      to: band.centre_um + band.half_width_um,
                      colour: style.band, label: m.molecule });
      }
    });
  });

  // A tiny Chart.js plugin that paints the strips behind the data.
  const bandPlugin = {
    id: "bands",
    beforeDatasetsDraw: function (chart) {
      const pen = chart.ctx, area = chart.chartArea, x = chart.scales.x;
      pen.save();
      strips.forEach(function (strip) {
        const left = Math.max(x.getPixelForValue(strip.from), area.left);
        const right = Math.min(x.getPixelForValue(strip.to), area.right);
        if (right <= left) { return; }
        pen.fillStyle = strip.colour;
        pen.fillRect(left, area.top, right - left, area.bottom - area.top);
        pen.fillStyle = CHART_DIM;
        pen.font = "11px sans-serif";
        pen.textAlign = "center";
        pen.fillText(strip.label, (left + right) / 2, area.top + 12);
      });
      pen.restore();
    },
  };

  const points = data.wavelength_um.map(function (w, i) { return { x: w, y: data.depth[i] }; });
  if (compChart) { compChart.destroy(); }
  const options = baseChartOptions("wavelength (µm)", "transit depth (" + data.depth_column + ")");
  options.scales.x.min = data.range_um[0];
  options.scales.x.max = data.range_um[1];
  compChart = new Chart(document.getElementById("comp-chart"), {
    type: "line",
    data: { datasets: [{ data: points, borderColor: CHART_ACCENT, backgroundColor: CHART_ACCENT,
                         borderWidth: 2, pointRadius: points.length > 60 ? 0 : 3, tension: 0.2 }] },
    options: options,
    plugins: [bandPlugin],
  });
}
