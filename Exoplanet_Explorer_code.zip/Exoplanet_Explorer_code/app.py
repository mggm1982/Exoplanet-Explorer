"""
app.py
------
The web server. It does two things:
  1. serves the website in static/
  2. scores light curves using the trained 1-D CNN
  3. serves astrophysical research vetting endpoints (noise-removal, false positives, single transits)

All preprocessing and CNN inference live in preprocess.py and cnn_predict.py.
"""

import io
import json
import os
import tempfile
from contextlib import asynccontextmanager

import numpy as np
import pandas as pd
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from detector import cnn_predict

# Upload size limits, in bytes.
MAX_CSV_BYTES = 50 * 1024 * 1024    # 50 MB

# File endings we accept.
CSV_EXTENSIONS = (".csv",)

HERE = os.path.dirname(os.path.abspath(__file__))

# Set to a message if the model could not be loaded at startup.
model_error = None


@asynccontextmanager
async def lifespan(_app):
    """
    Runs once when the server starts. We load the CNN here so that it is
    loaded a single time, not once per request, and so the first user does
    not have to wait for it.
    """
    global model_error
    try:
        loaded = cnn_predict.load_models()
        print("Light-curve models loaded:", ", ".join(loaded))
    except Exception as error:
        model_error = str(error)
        print("WARNING: the model could not be loaded:", model_error)

    yield  # the server runs here

    # Nothing to clean up when the server stops.


app = FastAPI(title="Exoplanet Transit Detector", lifespan=lifespan)


def error_response(message, status_code=400):
    """Send a friendly error back to the browser instead of a stack trace."""
    return JSONResponse(status_code=status_code, content={"error": message})


@app.get("/health")
def health():
    """A quick check that the server is up and whether the model is ready."""
    return {
        "status": "ok",
        "model_loaded": model_error is None,
        "model_error": model_error,
        "lightcurve_models": cnn_predict.available_models(),
        "default_lightcurve_model": cnn_predict.default_model_name(),
    }


@app.post("/api/predict-csv")
async def predict_csv(file: UploadFile = File(...), model: str = Form("")):
    """
    Score every row of an uploaded CSV with the CNN.
    One star per row; flux values in the columns.
    model = "real" or "simulated". Empty means the default
    (real if exoplanet_model_real.keras was found, otherwise simulated).
    """
    if model_error is not None:
        return error_response(
            "The model is not available: " + model_error, status_code=503
        )

    # --- which light-curve model? -----------------------------------------
    model_name = model.strip().lower() or cnn_predict.default_model_name()
    if model_name not in cnn_predict.available_models():
        return error_response(
            "Unknown or unavailable model '" + model + "'. Choose one of: "
            + ", ".join(cnn_predict.available_models()) + "."
        )

    # --- check the file name ---------------------------------------------
    filename = (file.filename or "").lower()
    if not filename.endswith(CSV_EXTENSIONS):
        return error_response(
            "Please upload a .csv file. You uploaded '" + (file.filename or "?") + "'."
        )

    # --- read it and check the size --------------------------------------
    contents = await file.read()

    if len(contents) == 0:
        return error_response("That file is empty.")

    if len(contents) > MAX_CSV_BYTES:
        return error_response(
            "That CSV is too large (limit is 50 MB)."
        )

    # --- parse the CSV ----------------------------------------------------
    try:
        table = pd.read_csv(io.BytesIO(contents))
    except Exception:
        return error_response(
            "That file could not be read as a CSV. Check it is a real "
            "comma-separated file with a header row."
        )

    if table.shape[0] == 0:
        return error_response("That CSV has a header but no rows of data.")

    # --- separate the optional LABEL column -------------------------------
    labels = None
    flux_table = table

    # Find a LABEL column whatever its capitalisation.
    for column in table.columns:
        if str(column).strip().upper() == "LABEL":
            labels = [_clean_label(v) for v in table[column].tolist()]
            flux_table = table.drop(columns=[column])
            break

    # --- keep only numeric columns ----------------------------------------
    flux_table = flux_table.select_dtypes(include="number")

    if flux_table.shape[1] == 0:
        return error_response(
            "No flux columns found. The CSV needs numeric columns of "
            "brightness values, one star per row."
        )

    if flux_table.shape[1] < 10:
        return error_response(
            "Only " + str(flux_table.shape[1]) + " numeric column(s) found. "
            "A light curve needs many brightness measurements per star."
        )

    # --- run the model ----------------------------------------------------
    try:
        flux = flux_table.to_numpy(dtype=float)
        results = cnn_predict.predict_stars(flux, labels, model_name)
    except Exception as error:
        return error_response(
            "Something went wrong while analysing that CSV: " + str(error),
            status_code=500,
        )

    return {
        "filename": file.filename,
        "n_stars": len(results),
        "n_flux_columns": int(flux_table.shape[1]),
        "model": model_name,
        "model_trained_on": cnn_predict.MODEL_TRAINED_ON[model_name],
        "model_length": cnn_predict.expected_length(model_name),
        "has_labels": labels is not None,
        "results": results,
    }


def _clean_label(value):
    """Turn a label cell into an int, or None if it is missing or odd."""
    try:
        if value is None or (isinstance(value, float) and np.isnan(value)):
            return None
        return int(value)
    except (TypeError, ValueError):
        return None





# ===================================================================
# RESEARCH ENDPOINTS
#
# These serve the three studies in research/. Every one of them reports
# where its data came from, because a result without a source is not a
# result. See data_provenance.md.
#
# The Idea 1 experiment takes minutes to run, so it is computed ahead of
# time by `python -m research.run_all` and served from data/cache/results/.
# ===================================================================

RESULTS_DIR = os.path.join(HERE, "data", "cache", "results")


def _load_saved_result(name):
    """Read one pre-computed result file, or None if it has not been made."""
    path = os.path.join(RESULTS_DIR, name + ".json")
    if not os.path.exists(path):
        return None
    try:
        with open(path) as handle:
            return json.load(handle)
    except (ValueError, OSError):
        return None


@app.get("/api/research/sources")
def research_sources():
    """
    Where every piece of data in this project comes from.
    Shown in the app so the provenance is visible, not buried in a file.
    """
    from research.datasources import (NASA_CITATION, NASA_TAP_URL,
                                      cached_provenance, describe_local_files)
    from research.kepler_data import KEPLER_CITATION

    return {
        "real_sources": [
            {
                "name": "NASA Exoplanet Archive - Planetary Systems",
                "what": "Confirmed exoplanets with published periods, depths "
                        "and radius ratios.",
                "endpoint": NASA_TAP_URL,
                "citation": NASA_CITATION,
                "used_for": "Checking our measurements against reality.",
                "cached": cached_provenance(),
            },
            {
                "name": "NASA Exoplanet Archive - Kepler KOI table",
                "what": "~9,500 transit-like signals, each vetted as "
                        "CONFIRMED, FALSE POSITIVE or CANDIDATE.",
                "endpoint": NASA_TAP_URL,
                "citation": NASA_CITATION.replace(
                    "Planetary Systems table",
                    "Kepler cumulative KOI table"),
                "used_for": "Idea 2: real labelled false positives.",
            },
            {
                "name": "MAST - Kepler light curves",
                "what": "Real photometry, with real gaps and systematics.",
                "endpoint": "https://mast.stsci.edu/api/v0/",
                "citation": KEPLER_CITATION,
                "used_for": "Ideas 1 and 3: a real test bed.",
            },
        ],
        "simulated_sources": describe_local_files(),
        "warning": (
            "The CNN on the CSV tab was trained on simulated light curves "
            "whose transits are about three times deeper than the median "
            "real planet. Its accuracy is an optimistic upper bound."
        ),
    }


@app.get("/api/research/idea1")
def research_idea1():
    """
    IDEA 1 - which noise-removal method finds the shallowest transits
    without inventing ones that are not there?
    """
    saved = _load_saved_result("idea1")
    if saved is None:
        return error_response(
            "The Idea 1 experiment has not been run yet. Run "
            "`python -m research.run_all` first - it takes a few minutes.",
            status_code=503,
        )
    return saved


@app.get("/api/research/idea2")
def research_idea2():
    """
    IDEA 2 - can we reject false positives while keeping real planets?
    Runs on the real Kepler KOI table.
    """
    saved = _load_saved_result("idea2")
    if saved is not None:
        return saved

    # Fast enough to compute on demand if the cache is missing.
    try:
        from research.datasources import fetch_koi_table
        from research.pipeline import run_idea2
        return run_idea2(fetch_koi_table())
    except Exception as error:
        return error_response(
            "Could not run the false-positive study: " + str(error),
            status_code=503,
        )


@app.post("/api/research/idea3")
async def research_idea3(file: UploadFile = File(...),
                         detrend_method: str = Form("median")):
    """
    IDEA 3 - find and rank transits that happen only once.

    Takes a CSV with ONE star per row (or a single row of flux values) and
    looks for isolated transit-like events, with no period required.
    """
    from research.detrend import METHODS, detrend
    from research.single_transit import find_single_transits

    filename = (file.filename or "").lower()
    if not filename.endswith(CSV_EXTENSIONS):
        return error_response("Please upload a .csv file of flux values.")

    if detrend_method not in METHODS:
        return error_response(
            "Unknown detrending method. Choose one of: " + ", ".join(METHODS))

    contents = await file.read()
    if len(contents) == 0:
        return error_response("That file is empty.")
    if len(contents) > MAX_CSV_BYTES:
        return error_response("That CSV is too large (limit is 50 MB).")

    try:
        table = pd.read_csv(io.BytesIO(contents))
    except Exception:
        return error_response("That file could not be read as a CSV.")

    for column in list(table.columns):
        if str(column).strip().upper() == "LABEL":
            table = table.drop(columns=[column])

    table = table.select_dtypes(include="number")
    if table.shape[0] == 0 or table.shape[1] < 50:
        return error_response(
            "Need one star per row with at least 50 brightness values.")

    try:
        # Only the first star, because this search is about one light curve.
        flux = table.iloc[0].to_numpy(dtype=float)
        flux = np.where(np.isfinite(flux), flux, np.nanmedian(flux))

        flattened = detrend(flux, detrend_method)

        # A plain CSV carries no time column, so "time" is the row index and
        # every duration must be expressed in data points, not hours.
        times = np.arange(len(flattened), dtype=float)
        durations_in_points = [4.0, 7.0, 11.0, 17.0, 25.0, 40.0, 60.0]
        durations_in_points = [d for d in durations_in_points
                               if d < len(flattened) / 8.0]

        candidates = find_single_transits(times, flattened,
                                          durations=durations_in_points)
    except Exception as error:
        return error_response(
            "Something went wrong during the search: " + str(error),
            status_code=500)

    return {
        "filename": file.filename,
        "detrend_method": detrend_method,
        "n_points": int(len(flattened)),
        "n_candidates": len(candidates),
        "candidates": candidates,
        "curve": [round(float(v), 6) for v in flattened],
        "note": ("Times and durations are in cadences (data points), not "
                 "days, because a plain CSV carries no time column."),
        "duration_units": "data points",
        "data_warning": ("If this is one of the bundled CSVs, remember it is "
                         "simulated. See data_provenance.md."),
    }


# ======================= MOLECULAR COMPOSITION =======================
# Physical band matching on a transmission spectrum (research/composition.py).
# No neural network: see that file for what this can and cannot tell you.

SPECTRA_DIR = os.path.join(HERE, "data", "simulated", "spectra")

# The example spectra that ship with the project. Only these names can be
# requested, so a user cannot ask the server to read any other file.
EXAMPLE_SPECTRA = {
    "flat_cloudy": ("spectrum_flat_cloudy.csv", "Flat, cloudy (simulated)"),
    "hst_H2O": ("spectrum_hst_like_H2O.csv", "HST-like, water (simulated)"),
    "jwst_H2O_CO2": ("spectrum_jwst_like_H2O_CO2.csv", "JWST-like, water + CO2 (simulated)"),
    "jwst_CH4_CO": ("spectrum_jwst_like_CH4_CO.csv", "JWST-like, methane + CO (simulated)"),
}


def composition_from_table(table, source_name, simulated):
    """Run the band check on a table: column 1 wavelength (um), column 2 depth,
    optional column 3 uncertainty."""
    from research.composition import analyse_spectrum

    table = table.select_dtypes(include="number").dropna(how="all")
    if table.shape[1] < 2:
        return error_response(
            "Need at least two number columns: wavelength (um) and transit depth.")
    if table.shape[0] < 5:
        return error_response("Need at least 5 rows (wavelength points).")

    uncertainty = table.iloc[:, 2].to_numpy(float) if table.shape[1] >= 3 else None
    try:
        report = analyse_spectrum(table.iloc[:, 0].to_numpy(float),
                                  table.iloc[:, 1].to_numpy(float), uncertainty)
    except ValueError as problem:
        return error_response(str(problem))

    report["filename"] = source_name
    report["depth_column"] = str(table.columns[1])
    report["data_warning"] = (
        "This example spectrum is SIMULATED, made for testing this tool."
        if simulated else "")
    return report


@app.get("/api/composition/examples")
def composition_examples():
    """The bundled example spectra a user can try with one click."""
    return {"examples": [{"id": key, "label": label}
                         for key, (_, label) in EXAMPLE_SPECTRA.items()]}


@app.get("/api/composition/example/{example_id}")
def composition_example(example_id: str):
    """Run the composition report on one bundled example spectrum."""
    if example_id not in EXAMPLE_SPECTRA:
        return error_response("Unknown example.", status_code=404)
    filename, _ = EXAMPLE_SPECTRA[example_id]
    table = pd.read_csv(os.path.join(SPECTRA_DIR, filename))
    return composition_from_table(table, filename, simulated=True)


@app.post("/api/composition")
async def composition_upload(file: UploadFile = File(...)):
    """Run the composition report on an uploaded spectrum CSV."""
    filename = (file.filename or "").lower()
    if not filename.endswith(CSV_EXTENSIONS):
        return error_response("Please upload a .csv file.")
    contents = await file.read()
    if len(contents) == 0:
        return error_response("That file is empty.")
    if len(contents) > MAX_CSV_BYTES:
        return error_response("That CSV is too large (limit is 50 MB).")
    try:
        table = pd.read_csv(io.BytesIO(contents))
    except Exception:
        return error_response("That file could not be read as a CSV.")
    return composition_from_table(table, file.filename, simulated=False)


# Serve the website. This must come last so it does not swallow the API paths.
app.mount("/", StaticFiles(directory=os.path.join(HERE, "static"), html=True),
          name="static")
